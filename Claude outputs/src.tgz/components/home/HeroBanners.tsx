import Image from 'next/image';
import Link from 'next/link';
import HeroSlider, { type Slide } from './HeroSlider';

// ---- Edit banners here -------------------------------------------------------------
// Center slider. Swap `image` for a designed banner any time (wide, dark images work best).
const SLIDES: Slide[] = [
  {
    image: '/images/HeroSection.png',
    alt: 'Heavy-duty truck with replacement parts',
    eyebrow: 'Shipped across the USA',
    title: 'Heavy-Duty Truck Parts, Shipped Fast',
    cta: 'Shop all parts',
    href: '/products',
  },
  {
    image: '/images/filter-cat.jpg',
    alt: 'FleetX oil, fuel and air filters',
    eyebrow: 'Filtration',
    title: 'Oil, Fuel & Air Filters',
    text: 'Keep engines clean and running longer.',
    cta: 'Shop filters',
    href: '/products/filters',
  },
  {
    image: '/images/banner1.jpg',
    alt: 'Heavy-duty truck parts for fleet orders',
    eyebrow: 'Fleets & repair shops',
    title: 'Bulk Orders for Your Fleet',
    text: 'Send your parts list — we’ll quote the whole order.',
    cta: 'Request a quote',
    href: '/contact',
  },
];

// Side product banners (left column stacks two, right is one tall banner).
const LEFT = [
  { title: 'Silicone Hoses', text: 'Coolant & charge-air', image: '/images/Hoses/01-33096-000.JPG', href: '/products/hoses' },
  { title: 'V-Band Clamps', text: 'V-band, T-bolt & exhaust', image: '/images/Clamps/20592783.JPG', href: '/products/clamps' },
];
// -------------------------------------------------------------------------------------

const ShopLink = ({ children }: { children: React.ReactNode }) => (
  <span className="inline-flex items-center gap-1.5 rounded-md bg-black px-4 py-2 text-xs font-bold uppercase tracking-wide text-white transition-colors group-hover:bg-[#00a550]">
    {children} <span aria-hidden="true">&rarr;</span>
  </span>
);

// Home hero: 3 banner columns — product promos | slider | engine-diagram promo.
const HeroBanners = () => (
  <section className="w-full bg-[#f5f5f4] py-4 md:py-6" aria-label="Featured offers">
    <div className="mx-auto grid max-w-[1320px] gap-4 px-4 lg:h-[540px] lg:grid-cols-[1fr_2fr_1fr]">
      {/* Center slider (first on mobile) */}
      <div className="lg:order-2">
        <HeroSlider slides={SLIDES} />
      </div>

      {/* Left: two stacked product banners */}
      <div className="grid grid-cols-2 gap-4 lg:order-1 lg:grid-cols-1 lg:grid-rows-2">
        {LEFT.map((b) => (
          <Link
            key={b.href}
            href={b.href}
            className="group relative flex flex-col overflow-hidden rounded-xl border border-gray-200 bg-white p-4 transition-shadow hover:shadow-xl sm:p-5 lg:flex-row lg:items-center"
          >
            <div className="relative z-10 order-2 mt-3 lg:order-1 lg:mt-0 lg:w-1/2">
              <h2 className="text-lg font-bold leading-tight text-[#1d1d1b] sm:text-xl">{b.title}</h2>
              <p className="mt-1 text-xs text-gray-500 sm:text-sm">{b.text}</p>
              <div className="mt-3">
                <ShopLink>Shop</ShopLink>
              </div>
            </div>
            <div className="relative order-1 aspect-square w-full lg:order-2 lg:aspect-auto lg:h-full lg:w-1/2">
              <Image src={b.image} alt={b.title} fill sizes="(min-width: 1024px) 160px, 45vw" className="object-contain transition-transform duration-300 group-hover:scale-105" />
            </div>
          </Link>
        ))}
      </div>

      {/* Right: tall engine-diagram banner */}
      <div className="flex flex-col overflow-hidden rounded-xl bg-black lg:order-3">
        <div className="relative aspect-[4/3] bg-white lg:aspect-auto lg:flex-1">
          <Image
            src="/images/cummins-engine-parts/cylinder-head.jpg"
            alt="Engine cylinder head exploded-view parts diagram"
            fill
            sizes="(min-width: 1024px) 320px, 100vw"
            className="object-contain p-4"
          />
          <span className="absolute left-4 top-4 rounded bg-gradient-to-r from-[#e9e611] to-[#00a34f] px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-black">
            Parts by diagram
          </span>
        </div>
        <div className="p-5 text-center">
          <h2 className="text-xl font-bold leading-tight text-white">Engine Parts by Diagram</h2>
          <p className="mt-1 text-sm text-gray-400">Click the callout, add the exact part.</p>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Link href="/detroit-engine-parts" className="rounded-md bg-white px-3 py-2.5 text-sm font-bold text-black transition-colors hover:bg-[#00a550] hover:text-white">
              Detroit DD15
            </Link>
            <Link href="/cummins-engine-parts" className="rounded-md border border-white/40 px-3 py-2.5 text-sm font-bold text-white transition-colors hover:bg-white hover:text-black">
              Cummins
            </Link>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default HeroBanners;

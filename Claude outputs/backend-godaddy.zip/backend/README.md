# Fleet X Parts — PHP REST API + Admin Panel

Backend for the Next.js store (`fleetxusa-frontend`).

```
Next.js frontend  ──HTTP/JSON──▶  PHP REST API (this folder)  ──PDO──▶  MySQL
                                   └─ /admin  (admin panel, uses the same API)
```

No Composer or framework needed — plain PHP 8.1+, PDO, MySQL 5.7+/MariaDB 10.4+. Runs on XAMPP, cPanel, Hostinger, GoDaddy.

---

## 1. Local setup (XAMPP)

1. Copy this folder to `C:\xampp\htdocs\fleetxusa-backend`.
2. Start **Apache** and **MySQL** in the XAMPP control panel.
3. Open phpMyAdmin → create a database **`fleetxusa`** (collation `utf8mb4_unicode_ci`).
4. Import, in this order:
   1. `database/schema.sql` — tables
   2. `database/seed.sql` — 6 categories, 288 demo products (the catalog the site showed before), 3 coupons, 1 admin user
5. Config: with XAMPP defaults (MySQL user `root`, no password, database `fleetxusa`) it runs **without a `.env` file** —
   a JWT secret is generated automatically in `storage/`. To change anything (DB login, mail, Stripe, shipping rate…),
   copy `.env.example` to `.env` and edit it. **On a live server always create `.env`.**
6. Check it: <http://localhost/fleetxusa-backend/api> should return `{"success":true, ... "database":"ok"}`.
7. Admin panel: <http://localhost/fleetxusa-backend/admin/>
   - **Email:** `admin@fleetxparts.com`  **Password:** `Admin@12345` → change it right away (Customers → your user, or reset flow).

Frontend: it already points to `http://localhost/fleetxusa-backend/api` by default — just `npm run dev`.
(For another URL, set `NEXT_PUBLIC_API_BASE_URL` in `fleetxusa-frontend/.env.local`.)

> No Apache? Run `php -S localhost:8000 dev-router.php` in this folder and use `http://localhost:8000/api`
> (URLs are detected automatically; set `APP_URL` in `.env` if images show the wrong host).

**Re-seed** from the command line: `php scripts/seed.php --run` (regenerates `database/seed.sql` without `--run`).

---

## 2. Folder structure

```
fleetxusa-backend/
├── api/index.php          front controller (every /api/* request) + .htaccess rewrite
├── admin/                 admin panel (HTML/CSS/JS, talks to the API)
├── bootstrap.php          autoloader, .env loader, error handling
├── src/
│   ├── routes.php         ALL endpoints in one place
│   ├── Core/              Router, Request, Response, Database (PDO), Validator,
│   │                      Jwt, Auth, RateLimiter, Uploader, Mailer, Env, Helpers
│   ├── Controllers/       Auth, Product, Category, Cart, Order, Coupon, User, Payment, Admin
│   └── Services/          CartService, OrderService, CouponService, Inventory,
│                          Payment/ (PaymentGateway interface, Stripe, Manual)
├── database/              schema.sql, seed.sql
├── scripts/seed.php       demo data generator (CLI only)
├── uploads/               product & category images (PHP execution disabled)
├── storage/logs/          php-error.log, mail.log (debug)
├── .env / .env.example    configuration
└── dev-router.php         router for `php -S`
```

`src/`, `database/`, `storage/`, `scripts/` and `.env` are blocked from the web by `.htaccess`.

---

## 3. API reference

Base URL: `{APP_URL}/api` · JSON in / JSON out.

Every response: `{ "success": true, "data": …, "meta"?: {…}, "message"?: "…" }`
Errors: `{ "success": false, "message": "…", "errors"?: { "field": "message" } }` with the right HTTP status
(400, 401, 403, 404, 405, 409 conflict/stock, 422 validation, 429 rate limit, 500).

Auth: `Authorization: Bearer <token>` (JWT, 7 days). Guest carts: `X-Cart-Token: <token>` (returned by the cart endpoints).

| Access | Meaning |
|---|---|
| public | anyone |
| auth | logged-in user |
| admin | user with role `admin` |

### Auth — `/api/auth`
| Method | Path | Access | Body / notes |
|---|---|---|---|
| POST | `/auth/register` | public | `name, email, mobile, password, password_confirmation, role (user\|dealer\|vendor), newsletter?` → `{token, user}` |
| POST | `/auth/login` | public | `email, password` → `{token, user}` or `{requires_otp:true}` when `AUTH_REQUIRE_OTP=true` |
| POST | `/auth/verify-otp` | public | `email, code` |
| POST | `/auth/resend-otp` | public | `email` |
| POST | `/auth/forgot-password` | public | `email` (emails a link to `{FRONTEND_URL}/reset-password`) |
| POST | `/auth/reset-password` | public | `email, token, password, password_confirmation` |
| GET | `/auth/me` | auth | current user |
| POST | `/auth/logout` | auth | `?all=1` signs out every device |

### Products — `/api/products`
| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/products` | public | Filters: `category` (slug/id, includes sub-categories), `categories=a,b`, `q`, `type=a,b`, `color=a,b`, `brand=a,b`, `min_price`, `max_price`, `in_stock=1`, `featured=1`, `ids=1,2` · `sort=best\|newest\|price-asc\|price-desc\|name` · `page`, `per_page` (max 100). Returns `data`, `meta` (pagination) and `facets` (categories, types, colors, brands, price range with counts). Admin: `status=draft\|active\|archived\|all` |
| GET | `/products/{id\|slug}` | public | full product: images, variants, specifications, related |
| POST | `/products` | admin | `name, sku, category_id, brand, product_type, description, warranty, specifications[{label,value}], status, is_featured, variants[{sku,name,size,color,price,compare_at_price,stock,low_stock_threshold,is_active}]` (or just `price` + `stock` for a single-variant product) |
| PUT | `/products/{id}` | admin | same fields; `variants` array is synced (missing ones are deleted) |
| DELETE | `/products/{id}` | admin | `?archive=1` hides instead of deleting |
| POST | `/products/{id}/images` | admin | multipart `images[]` (JPG/PNG/WEBP/GIF/AVIF, `UPLOAD_MAX_MB`) |
| PUT / DELETE | `/products/{id}/images/{imageId}` | admin | `{is_primary, alt, sort_order}` |
| POST | `/products/{id}/variants` | admin | add one variant |
| PUT / DELETE | `/products/variants/{variantId}` | admin | |
| PATCH | `/products/variants/{variantId}/stock` | admin | `{mode: set\|adjust, quantity, reason: manual\|restock\|return, note}` |
| GET | `/products/variants/{variantId}/stock-history` | admin | stock movement log |
| GET | `/products/low-stock` | admin | variants at/below their alert level |

### Categories — `/api/categories`
| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/categories` | public | active categories with `product_count` (admin: `?all=1`) |
| GET | `/categories/{id\|slug}` | public | + `children` |
| POST / PUT / DELETE | `/categories[/{id}]` | admin | `name, slug?, parent_id, description, image_url, sort_order, is_active, meta_title, meta_description` (delete refuses while products exist) |
| POST | `/categories/{id}/image` | admin | multipart `image` |

### Cart — `/api/cart`
Works for guests (`X-Cart-Token`) and users (Bearer). Prices and stock are always read live from the database.

| Method | Path | Body |
|---|---|---|
| GET | `/cart` | → `{token, items[], count, subtotal, issues[], totals}` |
| POST | `/cart/items` | `{variant_id, quantity}` (409 if not enough stock) |
| PATCH | `/cart/items/{id}` | `{quantity}` |
| DELETE | `/cart/items/{id}` | |
| DELETE | `/cart` | clear |
| POST | `/cart/merge` | auth — moves the guest cart (`X-Cart-Token`) into the user's cart after login |

### Orders — `/api/orders`
| Method | Path | Access | Notes |
|---|---|---|---|
| POST | `/orders` | public | Checkout from the current cart: `email, shipping_address{full_name, phone, address_line1, address_line2, city, state, zip_code, country}, billing_same_as_shipping, billing_address?, payment_method, coupon_code?, customer_note?, newsletter?` → `{order (with access_key), payment{redirect_url?}}`. Totals are recalculated on the server; stock is locked + decremented in one transaction. |
| GET | `/orders` | auth | customer: own orders · admin: all, filters `status, payment_status, q, user_id, from, to` |
| GET | `/orders/{number}` | owner / admin / guest with `?key=` | full order with items + history |
| POST | `/orders/{number}/cancel` | owner / guest key | only while pending & unpaid (restocks) |
| PATCH | `/orders/{id}/status` | admin | `{status, note?, tracking_number?, carrier?}` — emails the customer; cancel restocks |
| PATCH | `/orders/{id}/payment` | admin | `{payment_status: paid\|unpaid\|failed\|refunded, reference?}` |

Status flow: `pending → processing → shipped → delivered → refunded`, `cancelled` from pending/processing/shipped.

### Coupons — `/api/coupons`
| Method | Path | Access | Notes |
|---|---|---|---|
| POST | `/coupons/validate` | public | `{code, email?}` → discount + recalculated totals for the current cart |
| GET / POST / PUT / DELETE | `/coupons[/{id}]` | admin | `code, type (percent\|fixed\|free_shipping), value, min_order_amount, max_discount_amount, usage_limit, usage_limit_per_user, starts_at, expires_at, is_active` |

Demo codes: `WELCOME10` (10% off, once per customer), `SAVE25` ($25 off $200+), `FREESHIP` (free shipping on $100+).

### Users — `/api/users`
| Method | Path | Access |
|---|---|---|
| GET / PUT | `/users/me` | auth (`name, mobile, newsletter`) |
| PUT | `/users/me/password` | auth (`current_password, password, password_confirmation`) — returns a new token, other sessions are signed out |
| GET / POST | `/users/me/addresses` | auth |
| PUT / DELETE | `/users/me/addresses/{id}` | auth |
| GET | `/users` | admin — customers with order count & total spent (`q, role, status`) |
| GET / PUT | `/users/{id}` | admin — `role, status (active\|blocked)` |

### Payments — `/api/payments`
| Method | Path | Notes |
|---|---|---|
| GET | `/payments/methods` | enabled methods for checkout |
| POST | `/payments/{number}/retry` | new payment link for an unpaid order |
| POST | `/payments/stripe/webhook` | Stripe webhook (signature verified) |

### Admin
`GET /api/admin/dashboard` — revenue today / month / all-time, 30-day chart, pending orders, low stock, recent orders, top products.

---

## 4. Payments

* **Manual (Pay by invoice / phone)** — on by default (`PAYMENT_MANUAL_ENABLED`). Order is placed as *pending / unpaid*; mark it paid in the admin panel.
* **Stripe Checkout** — set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` in `.env`. In the Stripe dashboard add a webhook to
  `{APP_URL}/api/payments/stripe/webhook` with events `checkout.session.completed`, `checkout.session.expired`, `checkout.session.async_payment_failed`.
  The customer is redirected to Stripe and back to `/orders/{number}`; the webhook marks the order paid (or cancels and restocks if the session expires).
* **Another provider** (PayPal, Authorize.net…): implement `src/Services/Payment/PaymentGateway.php` and add it to `PaymentManager::gateways()`.

---

## 5. Security built in

* PDO prepared statements everywhere (no string-built SQL with user input), `utf8mb4`.
* Passwords hashed with `password_hash()` (bcrypt), auto-rehash.
* JWT (HS256) with `token_version` → password change / block / "log out everywhere" revokes old tokens.
* Rate limiting (login, register, OTP, password reset, checkout) stored in MySQL.
* Server-side validation on every input; money and stock are never trusted from the client.
* Stock decremented inside a transaction with `SELECT … FOR UPDATE` → no overselling.
* CORS allow-list (`CORS_ALLOWED_ORIGINS`), security headers, JSON-only errors (no stack traces when `APP_DEBUG=false`).
* Uploads: real MIME check (finfo), size limit, random file names, PHP execution disabled in `uploads/`.
* Guest orders are only visible with their secret `access_key` link.

---

## 6. Going live (cPanel / Hostinger / GoDaddy)

1. Upload the folder (e.g. `public_html/backend` or a subdomain like `api.yourdomain.com`).
2. Create the MySQL database + user in cPanel, import `schema.sql` then `seed.sql` (or only the categories/admin you need).
3. Edit `.env`:
   * `APP_ENV=production`, `APP_DEBUG=false`
   * `APP_URL=https://yourdomain.com/backend`, `FRONTEND_URL=https://yourdomain.com`
   * `CORS_ALLOWED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com`
   * DB credentials, a **new** `JWT_SECRET` (`php -r "echo bin2hex(random_bytes(32));"`), `MAIL_FROM` on your domain, `ADMIN_NOTIFY_EMAIL`
4. Make `uploads/` and `storage/logs/` writable (755/775).
5. Log into `/admin`, change the admin password, add your real products.
6. Use HTTPS only.

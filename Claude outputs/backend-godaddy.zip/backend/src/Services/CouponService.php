<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Helpers;
use App\Core\HttpException;

final class CouponService
{
    /**
     * Validate a code for a subtotal and return the coupon + discount.
     * Throws 422 with a friendly message when the code can't be used.
     */
    public static function apply(string $code, float $subtotal, ?int $userId, ?string $email): array
    {
        $coupon = Database::fetch('SELECT * FROM coupons WHERE code = ?', [strtoupper(trim($code))]);
        $fail = fn (string $m) => throw HttpException::validation(['coupon_code' => $m], $m);

        if (!$coupon || !$coupon['is_active']) {
            $fail('This code isn’t valid.');
        }
        $now = time();
        if ($coupon['starts_at'] && strtotime($coupon['starts_at'] . ' UTC') > $now) {
            $fail('This code isn’t active yet.');
        }
        if ($coupon['expires_at'] && strtotime($coupon['expires_at'] . ' UTC') < $now) {
            $fail('This code has expired.');
        }
        if ($coupon['usage_limit'] !== null && (int) $coupon['used_count'] >= (int) $coupon['usage_limit']) {
            $fail('This code has reached its usage limit.');
        }
        if ($coupon['min_order_amount'] !== null && $subtotal < (float) $coupon['min_order_amount']) {
            $fail('This code requires a minimum order of $' . number_format((float) $coupon['min_order_amount'], 2) . '.');
        }
        if ($coupon['usage_limit_per_user'] !== null && ($userId || $email)) {
            $used = (int) Database::value(
                'SELECT COUNT(*) FROM coupon_usages WHERE coupon_id = ? AND (user_id = ? OR email = ?)',
                [$coupon['id'], $userId ?? 0, strtolower((string) $email)]
            );
            if ($used >= (int) $coupon['usage_limit_per_user']) {
                $fail('You have already used this code.');
            }
        }

        $discount = match ($coupon['type']) {
            'percent'       => $subtotal * min(100, (float) $coupon['value']) / 100,
            'fixed'         => (float) $coupon['value'],
            'free_shipping' => 0.0,
        };
        if ($coupon['max_discount_amount'] !== null) {
            $discount = min($discount, (float) $coupon['max_discount_amount']);
        }
        $discount = Helpers::money(min($discount, $subtotal));

        return [
            'coupon'        => $coupon,
            'discount'      => $discount,
            'free_shipping' => $coupon['type'] === 'free_shipping',
        ];
    }

    public static function format(array $c): array
    {
        return [
            'id'                   => (int) $c['id'],
            'code'                 => $c['code'],
            'description'          => $c['description'],
            'type'                 => $c['type'],
            'value'                => Helpers::money($c['value']),
            'min_order_amount'     => $c['min_order_amount'] !== null ? Helpers::money($c['min_order_amount']) : null,
            'max_discount_amount'  => $c['max_discount_amount'] !== null ? Helpers::money($c['max_discount_amount']) : null,
            'usage_limit'          => $c['usage_limit'] !== null ? (int) $c['usage_limit'] : null,
            'usage_limit_per_user' => $c['usage_limit_per_user'] !== null ? (int) $c['usage_limit_per_user'] : null,
            'used_count'           => (int) $c['used_count'],
            'starts_at'            => $c['starts_at'],
            'expires_at'           => $c['expires_at'],
            'is_active'            => (bool) $c['is_active'],
            'created_at'           => $c['created_at'],
        ];
    }
}

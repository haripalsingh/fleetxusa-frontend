<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\HttpException;

/**
 * All stock changes go through here so every change is logged in stock_movements.
 * Call inside a transaction when combined with other writes.
 */
final class Inventory
{
    /**
     * Change stock by $delta. With $guard=true a decrease never goes below zero
     * (the row is locked with SELECT ... FOR UPDATE so two checkouts can't oversell).
     */
    public static function adjust(int $variantId, int $delta, string $reason, ?int $orderId = null, ?int $userId = null, ?string $note = null, bool $guard = true): int
    {
        $row = Database::fetch('SELECT id, stock, sku FROM product_variants WHERE id = ? FOR UPDATE', [$variantId]);
        if (!$row) {
            throw HttpException::notFound('Variant not found.');
        }
        $new = (int) $row['stock'] + $delta;
        if ($guard && $delta < 0 && $new < 0) {
            throw HttpException::conflict("Not enough stock for SKU {$row['sku']}. Only {$row['stock']} left.");
        }
        $new = max(0, $new);
        Database::query('UPDATE product_variants SET stock = ? WHERE id = ?', [$new, $variantId]);
        Database::insert('stock_movements', [
            'variant_id'  => $variantId,
            'change_qty'  => $new - (int) $row['stock'],
            'stock_after' => $new,
            'reason'      => $reason,
            'order_id'    => $orderId,
            'user_id'     => $userId,
            'note'        => $note,
        ]);
        return $new;
    }

    public static function set(int $variantId, int $stock, string $reason, ?int $userId = null, ?string $note = null): int
    {
        $current = (int) Database::value('SELECT stock FROM product_variants WHERE id = ? FOR UPDATE', [$variantId]);
        return self::adjust($variantId, max(0, $stock) - $current, $reason, null, $userId, $note, false);
    }
}

<?php
declare(strict_types=1);

namespace App\Services\Payment;

/**
 * Add a new provider (PayPal, Authorize.net, Razorpay...) by implementing this
 * interface and registering it in PaymentManager::gateways().
 */
interface PaymentGateway
{
    /** Machine name stored in orders.payment_method, e.g. "stripe". */
    public function code(): string;

    /** Label + description shown at checkout. */
    public function describe(): array;

    public function isEnabled(): bool;

    /**
     * Start payment for a freshly created order.
     * Return ['redirect_url' => '...'] for hosted pages, or [] when nothing else is needed.
     */
    public function start(array $order, array $items): array;
}

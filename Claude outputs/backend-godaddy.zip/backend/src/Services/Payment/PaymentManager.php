<?php
declare(strict_types=1);

namespace App\Services\Payment;

use App\Core\HttpException;

final class PaymentManager
{
    /** @return PaymentGateway[] */
    public static function gateways(): array
    {
        return [
            new StripeGateway(),
            new ManualGateway(),
            // new PayPalGateway(),  <- add more here
        ];
    }

    /** @return PaymentGateway[] */
    public static function enabled(): array
    {
        return array_values(array_filter(self::gateways(), fn (PaymentGateway $g) => $g->isEnabled()));
    }

    public static function get(string $code): PaymentGateway
    {
        foreach (self::enabled() as $g) {
            if ($g->code() === $code) {
                return $g;
            }
        }
        throw HttpException::validation(['payment_method' => 'Please choose a valid payment method.']);
    }
}

<?php
declare(strict_types=1);

namespace App\Services\Payment;

use App\Core\Env;

/** Offline payment: order is placed as "pending / unpaid"; staff invoice or call the customer. */
final class ManualGateway implements PaymentGateway
{
    public function code(): string
    {
        return 'manual';
    }

    public function describe(): array
    {
        return [
            'code'        => $this->code(),
            'label'       => 'Pay by Invoice / Phone',
            'description' => 'Place your order now - our team will contact you to confirm and collect payment.',
        ];
    }

    public function isEnabled(): bool
    {
        return Env::bool('PAYMENT_MANUAL_ENABLED', true);
    }

    public function start(array $order, array $items): array
    {
        return [];
    }
}

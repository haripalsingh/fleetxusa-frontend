<?php
declare(strict_types=1);

namespace App\Services\Payment;

use App\Core\Database;
use App\Core\Env;
use App\Core\HttpException;

/**
 * Stripe Checkout (hosted payment page) via the REST API - no SDK required.
 * Enable by setting STRIPE_SECRET_KEY + STRIPE_WEBHOOK_SECRET in .env and adding a webhook
 * in the Stripe dashboard pointing to  {APP_URL}/api/payments/stripe/webhook  with events:
 *   checkout.session.completed, checkout.session.expired, checkout.session.async_payment_failed
 */
final class StripeGateway implements PaymentGateway
{
    public function code(): string
    {
        return 'stripe';
    }

    public function describe(): array
    {
        return [
            'code'        => $this->code(),
            'label'       => 'Credit / Debit Card',
            'description' => 'Pay securely with Stripe. You will be redirected to complete payment.',
        ];
    }

    public function isEnabled(): bool
    {
        return (string) Env::get('STRIPE_SECRET_KEY', '') !== '';
    }

    public function start(array $order, array $items): array
    {
        $front = rtrim((string) Env::get('FRONTEND_URL', 'http://localhost:3000'), '/');
        $orderUrl = $front . '/orders/' . $order['order_number'] . '?key=' . $order['access_key'];
        $currency = strtolower($order['currency']);

        // One line for the whole order keeps totals exact (discounts, shipping, tax included).
        $params = [
            'mode'                 => 'payment',
            'customer_email'       => $order['email'],
            'client_reference_id'  => $order['order_number'],
            'success_url'          => $orderUrl . '&payment=success',
            'cancel_url'           => $orderUrl . '&payment=cancelled',
            'metadata[order_number]' => $order['order_number'],
            'payment_intent_data[metadata][order_number]' => $order['order_number'],
            'line_items[0][quantity]' => 1,
            'line_items[0][price_data][currency]' => $currency,
            'line_items[0][price_data][unit_amount]' => (int) round((float) $order['grand_total'] * 100),
            'line_items[0][price_data][product_data][name]' => 'Order ' . $order['order_number'],
            'line_items[0][price_data][product_data][description]' => mb_substr(implode(', ', array_map(
                fn ($i) => $i['quantity'] . ' x ' . $i['product_name'], $items
            )), 0, 500),
            'expires_at' => time() + 3600,
        ];

        $session = $this->request('POST', '/v1/checkout/sessions', $params);

        Database::insert('payments', [
            'order_id'     => $order['id'],
            'provider'     => 'stripe',
            'provider_ref' => $session['id'],
            'amount'       => $order['grand_total'],
            'currency'     => $order['currency'],
            'status'       => 'pending',
        ]);
        Database::query('UPDATE orders SET payment_reference = ? WHERE id = ?', [$session['id'], $order['id']]);

        return ['redirect_url' => $session['url']];
    }

    /** Verify the Stripe-Signature header and return the decoded event. */
    public static function verifyWebhook(string $payload, string $header): array
    {
        $secret = (string) Env::get('STRIPE_WEBHOOK_SECRET', '');
        if ($secret === '') {
            throw HttpException::badRequest('Stripe webhook secret not configured.');
        }
        $parts = [];
        foreach (explode(',', $header) as $kv) {
            [$k, $v] = array_pad(explode('=', trim($kv), 2), 2, '');
            $parts[$k][] = $v;
        }
        $ts = (int) ($parts['t'][0] ?? 0);
        if (!$ts || abs(time() - $ts) > 300) {
            throw HttpException::badRequest('Webhook timestamp outside tolerance.');
        }
        $expected = hash_hmac('sha256', $ts . '.' . $payload, $secret);
        $valid = false;
        foreach ($parts['v1'] ?? [] as $sig) {
            if (hash_equals($expected, $sig)) {
                $valid = true;
            }
        }
        if (!$valid) {
            throw HttpException::badRequest('Invalid webhook signature.');
        }
        $event = json_decode($payload, true);
        if (!is_array($event)) {
            throw HttpException::badRequest('Invalid webhook payload.');
        }
        return $event;
    }

    private function request(string $method, string $path, array $params): array
    {
        $ch = curl_init('https://api.stripe.com' . $path);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERPWD        => Env::get('STRIPE_SECRET_KEY') . ':',
            CURLOPT_POSTFIELDS     => http_build_query($params),
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => ['Stripe-Version: 2024-06-20'],
        ]);
        $body = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        $data = is_string($body) ? json_decode($body, true) : null;
        if ($status >= 400 || !is_array($data)) {
            error_log('[Stripe] ' . ($err ?: $body));
            throw new HttpException(502, 'Payment provider error: ' . ($data['error']['message'] ?? 'could not start payment.'));
        }
        return $data;
    }
}

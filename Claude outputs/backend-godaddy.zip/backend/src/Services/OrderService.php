<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Env;
use App\Core\Helpers;
use App\Core\HttpException;
use App\Core\Mailer;

final class OrderService
{
    /** Allowed admin status changes. */
    public const TRANSITIONS = [
        'pending'    => ['processing', 'shipped', 'cancelled'],
        'processing' => ['shipped', 'delivered', 'cancelled'],
        'shipped'    => ['delivered', 'cancelled'],
        'delivered'  => ['refunded'],
        'cancelled'  => [],
        'refunded'   => [],
    ];

    /** Price breakdown used by cart, coupon preview and checkout (single source of truth). */
    public static function totals(float $subtotal, float $discount = 0.0, bool $freeShipping = false, bool $hasItems = true): array
    {
        $afterDiscount = max(0.0, $subtotal - $discount);
        $flat = Env::float('SHIPPING_FLAT_RATE', 15);
        $threshold = Env::float('FREE_SHIPPING_THRESHOLD', 0);
        $shipping = (!$hasItems || $freeShipping || ($threshold > 0 && $afterDiscount >= $threshold)) ? 0.0 : $flat;
        $tax = Helpers::money($afterDiscount * Env::float('TAX_RATE_PERCENT', 0) / 100);

        return [
            'subtotal'       => Helpers::money($subtotal),
            'discount_total' => Helpers::money($discount),
            'shipping_total' => Helpers::money($shipping),
            'tax_total'      => $tax,
            'grand_total'    => Helpers::money($afterDiscount + $shipping + $tax),
            'currency'       => Env::get('CURRENCY', 'USD'),
            'free_shipping_threshold' => $threshold > 0 ? Helpers::money($threshold) : null,
        ];
    }

    /**
     * Turn the cart into an order. Stock is decremented inside the transaction with row
     * locks, so two customers can't buy the last unit at the same time.
     */
    public static function place(array $cart, array $data, ?array $user): array
    {
        $summary = CartService::summary($cart);
        $items = array_values(array_filter($summary['items'], fn ($i) => $i['available']));
        if (!$items) {
            throw HttpException::badRequest('Your cart is empty.');
        }
        if ($summary['issues']) {
            throw HttpException::conflict('Some items in your cart changed. Please review your cart.', ['cart' => $summary['issues']]);
        }

        $email = strtolower($data['email']);
        $couponResult = null;
        if (!empty($data['coupon_code'])) {
            $couponResult = CouponService::apply($data['coupon_code'], $summary['subtotal'], $user['id'] ?? null, $email);
        }
        $totals = self::totals(
            $summary['subtotal'],
            $couponResult['discount'] ?? 0.0,
            $couponResult['free_shipping'] ?? false
        );

        $orderId = Database::transaction(function () use ($cart, $data, $user, $email, $items, $totals, $couponResult) {
            $number = self::newOrderNumber();
            $orderId = Database::insert('orders', [
                'order_number'     => $number,
                'user_id'          => $user['id'] ?? null,
                'email'            => $email,
                'access_key'       => bin2hex(random_bytes(20)),
                'status'           => 'pending',
                'payment_status'   => 'unpaid',
                'payment_method'   => $data['payment_method'],
                'currency'         => $totals['currency'],
                'subtotal'         => $totals['subtotal'],
                'discount_total'   => $totals['discount_total'],
                'shipping_total'   => $totals['shipping_total'],
                'tax_total'        => $totals['tax_total'],
                'grand_total'      => $totals['grand_total'],
                'coupon_id'        => $couponResult['coupon']['id'] ?? null,
                'coupon_code'      => $couponResult['coupon']['code'] ?? null,
                'shipping_address' => json_encode($data['shipping_address']),
                'billing_address'  => json_encode($data['billing_address'] ?? $data['shipping_address']),
                'customer_note'    => $data['customer_note'] ?? null,
            ]);

            foreach ($items as $item) {
                Inventory::adjust($item['variant_id'], -$item['quantity'], 'order', $orderId, $user['id'] ?? null);
                Database::insert('order_items', [
                    'order_id'      => $orderId,
                    'product_id'    => $item['product_id'],
                    'variant_id'    => $item['variant_id'],
                    'product_name'  => $item['name'],
                    'product_slug'  => $item['slug'],
                    'category_slug' => $item['category_slug'],
                    'variant_name'  => $item['option'],
                    'sku'           => $item['sku'],
                    'image_url'     => $item['image_url'],
                    'unit_price'    => $item['price'],
                    'quantity'      => $item['quantity'],
                    'line_total'    => $item['line_total'],
                ]);
            }

            if ($couponResult) {
                $ok = Database::query(
                    'UPDATE coupons SET used_count = used_count + 1 WHERE id = ? AND (usage_limit IS NULL OR used_count < usage_limit)',
                    [$couponResult['coupon']['id']]
                )->rowCount();
                if (!$ok) {
                    throw HttpException::validation(['coupon_code' => 'This code has reached its usage limit.']);
                }
                Database::insert('coupon_usages', [
                    'coupon_id' => $couponResult['coupon']['id'], 'order_id' => $orderId,
                    'user_id' => $user['id'] ?? null, 'email' => $email,
                ]);
            }

            self::history($orderId, 'pending', 'Order placed', $user['id'] ?? null);
            Database::query('DELETE FROM cart_items WHERE cart_id = ?', [$cart['id']]);

            if (!empty($data['newsletter'])) {
                Database::query('INSERT IGNORE INTO newsletter_subscribers (email) VALUES (?)', [$email]);
            }
            return $orderId;
        });

        $order = Database::fetch('SELECT * FROM orders WHERE id = ?', [$orderId]);
        self::sendConfirmation($order);
        return $order;
    }

    public static function changeStatus(array $order, string $status, ?string $note, ?int $userId, array $extra = []): array
    {
        if ($status === $order['status']) {
            if ($extra) {
                Database::update('orders', (int) $order['id'], $extra);
            }
            return Database::fetch('SELECT * FROM orders WHERE id = ?', [$order['id']]);
        }
        if (!in_array($status, self::TRANSITIONS[$order['status']] ?? [], true)) {
            throw HttpException::conflict("An order that is {$order['status']} can't be changed to $status.");
        }

        Database::transaction(function () use ($order, $status, $note, $userId, $extra) {
            $update = $extra + ['status' => $status];
            if ($status === 'cancelled') {
                $update['cancelled_at'] = gmdate('Y-m-d H:i:s');
                self::restock($order, $userId);
                if ($order['coupon_id']) {
                    Database::query('UPDATE coupons SET used_count = GREATEST(used_count - 1, 0) WHERE id = ?', [$order['coupon_id']]);
                    Database::query('DELETE FROM coupon_usages WHERE order_id = ?', [$order['id']]);
                }
                if ($order['payment_status'] === 'unpaid') {
                    Database::query("UPDATE payments SET status = 'cancelled' WHERE order_id = ? AND status = 'pending'", [$order['id']]);
                }
            }
            if ($status === 'refunded') {
                $update['payment_status'] = 'refunded';
            }
            Database::update('orders', (int) $order['id'], $update);
            self::history((int) $order['id'], $status, $note, $userId);
        });

        $fresh = Database::fetch('SELECT * FROM orders WHERE id = ?', [$order['id']]);
        self::sendStatusEmail($fresh, $note);
        return $fresh;
    }

    public static function markPaid(array $order, ?string $reference, ?int $userId = null, string $note = 'Payment received'): void
    {
        if ($order['payment_status'] === 'paid') {
            return;
        }
        Database::transaction(function () use ($order, $reference, $userId, $note) {
            Database::query(
                "UPDATE orders SET payment_status = 'paid', paid_at = UTC_TIMESTAMP(), payment_reference = COALESCE(?, payment_reference),
                    status = IF(status = 'pending', 'processing', status) WHERE id = ?",
                [$reference, $order['id']]
            );
            self::history((int) $order['id'], 'processing', $note, $userId);
        });
    }

    public static function restock(array $order, ?int $userId): void
    {
        foreach (Database::fetchAll('SELECT variant_id, quantity FROM order_items WHERE order_id = ? AND variant_id IS NOT NULL', [$order['id']]) as $i) {
            Inventory::adjust((int) $i['variant_id'], (int) $i['quantity'], 'cancel', (int) $order['id'], $userId, 'Order cancelled', false);
        }
    }

    public static function history(int $orderId, string $status, ?string $note, ?int $userId): void
    {
        Database::insert('order_status_history', ['order_id' => $orderId, 'status' => $status, 'note' => $note, 'user_id' => $userId]);
    }

    public static function format(array $o, bool $withItems = true, bool $includeKey = false): array
    {
        $out = [
            'id'               => (int) $o['id'],
            'order_number'     => $o['order_number'],
            'user_id'          => $o['user_id'] !== null ? (int) $o['user_id'] : null,
            'email'            => $o['email'],
            'status'           => $o['status'],
            'payment_status'   => $o['payment_status'],
            'payment_method'   => $o['payment_method'],
            'currency'         => $o['currency'],
            'subtotal'         => Helpers::money($o['subtotal']),
            'discount_total'   => Helpers::money($o['discount_total']),
            'shipping_total'   => Helpers::money($o['shipping_total']),
            'tax_total'        => Helpers::money($o['tax_total']),
            'grand_total'      => Helpers::money($o['grand_total']),
            'coupon_code'      => $o['coupon_code'],
            'shipping_address' => json_decode($o['shipping_address'], true),
            'billing_address'  => json_decode($o['billing_address'], true),
            'customer_note'    => $o['customer_note'],
            'tracking_number'  => $o['tracking_number'],
            'carrier'          => $o['carrier'],
            'paid_at'          => $o['paid_at'],
            'cancelled_at'     => $o['cancelled_at'],
            'created_at'       => $o['created_at'],
            'updated_at'       => $o['updated_at'],
            'can_cancel'       => $o['status'] === 'pending' && $o['payment_status'] !== 'paid',
            'can_pay'          => $o['status'] === 'pending' && $o['payment_status'] !== 'paid' && $o['payment_method'] === 'stripe',
            'item_count'       => isset($o['item_count']) ? (int) $o['item_count'] : null,
        ];
        if (isset($o['customer_name'])) {
            $out['customer_name'] = $o['customer_name'];
        }
        if ($includeKey) {
            $out['access_key'] = $o['access_key'];
        }
        if ($withItems) {
            $out['items'] = array_map(fn ($i) => [
                'id'            => (int) $i['id'],
                'product_id'    => $i['product_id'] !== null ? (int) $i['product_id'] : null,
                'variant_id'    => $i['variant_id'] !== null ? (int) $i['variant_id'] : null,
                'name'          => $i['product_name'],
                'slug'          => $i['product_slug'],
                'category_slug' => $i['category_slug'],
                'option'        => $i['variant_name'],
                'sku'           => $i['sku'],
                'image_url'     => $i['image_url'],
                'unit_price'    => Helpers::money($i['unit_price']),
                'quantity'      => (int) $i['quantity'],
                'line_total'    => Helpers::money($i['line_total']),
            ], Database::fetchAll('SELECT * FROM order_items WHERE order_id = ? ORDER BY id', [$o['id']]));
            $out['history'] = array_map(fn ($h) => [
                'status' => $h['status'], 'note' => $h['note'], 'created_at' => $h['created_at'],
            ], Database::fetchAll('SELECT * FROM order_status_history WHERE order_id = ? ORDER BY id', [$o['id']]));
        }
        return $out;
    }

    // ------------------------------------------------------------------------------
    private static function newOrderNumber(): string
    {
        do {
            $n = 'FX' . gmdate('ymd') . random_int(1000, 9999);
        } while (Database::fetch('SELECT id FROM orders WHERE order_number = ?', [$n]));
        return $n;
    }

    private static function orderUrl(array $o): string
    {
        return rtrim((string) Env::get('FRONTEND_URL', 'http://localhost:3000'), '/') . '/orders/' . $o['order_number'] . '?key=' . $o['access_key'];
    }

    private static function sendConfirmation(array $o): void
    {
        $rows = '';
        foreach (Database::fetchAll('SELECT * FROM order_items WHERE order_id = ?', [$o['id']]) as $i) {
            $rows .= '<tr><td style="padding:6px 0">' . (int) $i['quantity'] . ' × ' . htmlspecialchars($i['product_name'])
                . ($i['variant_name'] ? ' (' . htmlspecialchars($i['variant_name']) . ')' : '')
                . '</td><td align="right">$' . number_format((float) $i['line_total'], 2) . '</td></tr>';
        }
        $html = '<p>Thanks for your order!</p><p><strong>Order ' . htmlspecialchars($o['order_number']) . '</strong></p>'
            . '<table width="100%">' . $rows
            . '<tr><td style="border-top:1px solid #ddd;padding-top:8px">Total</td><td align="right" style="border-top:1px solid #ddd;padding-top:8px"><strong>$'
            . number_format((float) $o['grand_total'], 2) . '</strong></td></tr></table>'
            . '<p><a href="' . htmlspecialchars(self::orderUrl($o)) . '">View your order</a></p>';
        Mailer::send($o['email'], 'Order confirmation ' . $o['order_number'], $html);

        if ($admin = Env::get('ADMIN_NOTIFY_EMAIL')) {
            Mailer::send($admin, 'New order ' . $o['order_number'] . ' - $' . number_format((float) $o['grand_total'], 2), $html);
        }
    }

    private static function sendStatusEmail(array $o, ?string $note): void
    {
        $labels = ['processing' => 'is being processed', 'shipped' => 'has shipped', 'delivered' => 'was delivered',
                   'cancelled' => 'was cancelled', 'refunded' => 'was refunded'];
        if (!isset($labels[$o['status']])) {
            return;
        }
        $html = '<p>Your order <strong>' . htmlspecialchars($o['order_number']) . '</strong> ' . $labels[$o['status']] . '.</p>'
            . ($o['tracking_number'] ? '<p>Tracking: ' . htmlspecialchars(trim(($o['carrier'] ?? '') . ' ' . $o['tracking_number'])) . '</p>' : '')
            . ($note ? '<p>' . nl2br(htmlspecialchars($note)) . '</p>' : '')
            . '<p><a href="' . htmlspecialchars(self::orderUrl($o)) . '">View your order</a></p>';
        Mailer::send($o['email'], 'Order ' . $o['order_number'] . ' update', $html);
    }
}

<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Helpers;
use App\Core\HttpException;
use App\Core\Request;

/**
 * Carts live in MySQL. Logged-in users have one cart (user_id); guests are identified
 * by a random token the frontend keeps and sends in the X-Cart-Token header.
 */
final class CartService
{
    public const MAX_QTY = 99;

    /** Find the current cart (optionally creating it). Returns null if none and !$create. */
    public static function resolve(Request $r, bool $create = false): ?array
    {
        if ($r->user) {
            $cart = Database::fetch('SELECT * FROM carts WHERE user_id = ?', [$r->user['id']]);
            if (!$cart && $create) {
                $id = Database::insert('carts', ['user_id' => $r->user['id']]);
                $cart = Database::fetch('SELECT * FROM carts WHERE id = ?', [$id]);
            }
            return $cart;
        }

        $token = self::guestToken($r);
        if ($token) {
            $cart = Database::fetch('SELECT * FROM carts WHERE token = ? AND user_id IS NULL', [$token]);
            if ($cart) {
                return $cart;
            }
        }
        if (!$create) {
            return null;
        }
        $token = bin2hex(random_bytes(32));
        $id = Database::insert('carts', ['token' => $token]);
        return Database::fetch('SELECT * FROM carts WHERE id = ?', [$id]);
    }

    public static function guestToken(Request $r): ?string
    {
        $t = $r->header('x-cart-token');
        return ($t && preg_match('/^[a-f0-9]{64}$/', $t)) ? $t : null;
    }

    /** Full cart payload with live prices and stock. */
    public static function summary(?array $cart): array
    {
        if (!$cart) {
            return ['token' => null, 'items' => [], 'count' => 0, 'subtotal' => 0.0, 'issues' => []];
        }
        $rows = Database::fetchAll(
            "SELECT ci.id, ci.quantity, ci.variant_id,
                    v.sku AS variant_sku, v.name AS variant_name, v.size, v.color, v.price, v.compare_at_price, v.stock, v.is_active AS variant_active,
                    p.id AS product_id, p.name AS product_name, p.slug AS product_slug, p.sku AS product_sku, p.status,
                    c.slug AS category_slug,
                    (SELECT url FROM product_images i WHERE i.product_id = p.id ORDER BY i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS image
             FROM cart_items ci
             JOIN product_variants v ON v.id = ci.variant_id
             JOIN products p ON p.id = v.product_id
             LEFT JOIN categories c ON c.id = p.category_id
             WHERE ci.cart_id = ? ORDER BY ci.id",
            [$cart['id']]
        );

        $items = [];
        $issues = [];
        $subtotal = 0.0;
        $count = 0;
        foreach ($rows as $row) {
            $available = $row['status'] === 'active' && $row['variant_active'];
            $stock = max(0, (int) $row['stock']);
            if (!$available) {
                $issues[] = "{$row['product_name']} is no longer available.";
            } elseif ($stock < (int) $row['quantity']) {
                $issues[] = $stock === 0
                    ? "{$row['product_name']} is out of stock."
                    : "Only $stock of {$row['product_name']} available.";
            }
            $line = Helpers::money((float) $row['price'] * (int) $row['quantity']);
            if ($available) {
                $subtotal += $line;
                $count += (int) $row['quantity'];
            }
            $items[] = [
                'id'            => (int) $row['id'],
                'variant_id'    => (int) $row['variant_id'],
                'product_id'    => (int) $row['product_id'],
                'name'          => $row['product_name'],
                'slug'          => $row['product_slug'],
                'category_slug' => $row['category_slug'],
                'sku'           => $row['variant_sku'],
                'option'        => $row['variant_name'] === 'Default' ? null : $row['variant_name'],
                'size'          => $row['size'],
                'color'         => $row['color'],
                'price'         => Helpers::money($row['price']),
                'compare_at_price' => $row['compare_at_price'] !== null ? Helpers::money($row['compare_at_price']) : null,
                'quantity'      => (int) $row['quantity'],
                'line_total'    => $line,
                'stock'         => $stock,
                'available'     => (bool) $available,
                'image_url'     => Helpers::mediaUrl($row['image']),
            ];
        }

        return [
            'token'    => $cart['user_id'] ? null : $cart['token'],
            'items'    => $items,
            'count'    => $count,
            'subtotal' => Helpers::money($subtotal),
            'issues'   => $issues,
        ];
    }

    public static function addItem(int $cartId, int $variantId, int $qty): void
    {
        $variant = Database::fetch(
            "SELECT v.*, p.status, p.name FROM product_variants v JOIN products p ON p.id = v.product_id WHERE v.id = ?",
            [$variantId]
        );
        if (!$variant || $variant['status'] !== 'active' || !$variant['is_active']) {
            throw HttpException::notFound('This product is not available.');
        }
        $existing = (int) Database::value('SELECT quantity FROM cart_items WHERE cart_id = ? AND variant_id = ?', [$cartId, $variantId]);
        $newQty = min(self::MAX_QTY, $existing + $qty);
        self::assertStock($variant, $newQty);

        Database::query(
            'INSERT INTO cart_items (cart_id, variant_id, quantity) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE quantity = VALUES(quantity)',
            [$cartId, $variantId, $newQty]
        );
        Database::query('UPDATE carts SET updated_at = UTC_TIMESTAMP() WHERE id = ?', [$cartId]);
    }

    public static function assertStock(array $variant, int $qty): void
    {
        $stock = max(0, (int) $variant['stock']);
        if ($stock < $qty) {
            throw HttpException::conflict($stock === 0
                ? 'Sorry, this item is out of stock.'
                : "Only $stock in stock for this item.");
        }
    }

    /** Move a guest cart's items into the user's cart (called right after login). */
    public static function merge(string $guestToken, int $userId): void
    {
        $guest = Database::fetch('SELECT * FROM carts WHERE token = ? AND user_id IS NULL', [$guestToken]);
        if (!$guest) {
            return;
        }
        Database::transaction(function () use ($guest, $userId) {
            $userCart = Database::fetch('SELECT * FROM carts WHERE user_id = ?', [$userId]);
            if (!$userCart) {
                // just adopt the guest cart
                Database::query('UPDATE carts SET user_id = ?, token = NULL WHERE id = ?', [$userId, $guest['id']]);
                return;
            }
            foreach (Database::fetchAll('SELECT ci.*, v.stock FROM cart_items ci JOIN product_variants v ON v.id = ci.variant_id WHERE ci.cart_id = ?', [$guest['id']]) as $item) {
                $existing = (int) Database::value('SELECT quantity FROM cart_items WHERE cart_id = ? AND variant_id = ?', [$userCart['id'], $item['variant_id']]);
                $qty = min(self::MAX_QTY, max(1, min((int) $item['stock'], $existing + (int) $item['quantity'])));
                Database::query(
                    'INSERT INTO cart_items (cart_id, variant_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = VALUES(quantity)',
                    [$userCart['id'], $item['variant_id'], $qty]
                );
            }
            Database::query('DELETE FROM carts WHERE id = ?', [$guest['id']]);
        });
    }
}

<?php
declare(strict_types=1);

namespace App\Core;

final class Request
{
    public array $params = [];      // route params, e.g. {id}
    public ?array $user = null;     // set by Auth when a valid token is sent
    private ?array $json = null;

    public function __construct(
        public readonly string $method,
        public readonly string $path,
        public readonly array $query,
        private readonly array $headers
    ) {
    }

    public static function capture(): self
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $uri = rawurldecode($uri);

        // Strip everything up to and including "/api" so the app works in any sub-folder
        // (http://localhost/fleetxusa-backend/api/products -> /products)
        $pos = strpos($uri, '/api/');
        if ($pos !== false) {
            $path = substr($uri, $pos + 4);
        } elseif (str_ends_with($uri, '/api')) {
            $path = '/';
        } else {
            $path = $uri;
        }
        $path = '/' . trim($path, '/');

        $headers = [];
        foreach ($_SERVER as $k => $v) {
            if (str_starts_with($k, 'HTTP_')) {
                $headers[strtolower(str_replace('_', '-', substr($k, 5)))] = $v;
            }
        }
        // Apache sometimes hides the Authorization header
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;
        if (!$auth && function_exists('apache_request_headers')) {
            foreach (apache_request_headers() as $k => $v) {
                if (strtolower($k) === 'authorization') {
                    $auth = $v;
                }
            }
        }
        if ($auth) {
            $headers['authorization'] = $auth;
        }
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $headers['content-type'] = $_SERVER['CONTENT_TYPE'];
        }

        return new self($method, $path, $_GET, $headers);
    }

    public function header(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }

    public function bearerToken(): ?string
    {
        $h = $this->header('authorization');
        if ($h && preg_match('/^Bearer\s+(\S+)$/i', $h, $m)) {
            return $m[1];
        }
        return null;
    }

    /** JSON body (or form fields for multipart requests). */
    public function body(): array
    {
        if ($this->json !== null) {
            return $this->json;
        }
        $type = $this->header('content-type') ?? '';
        if (str_contains($type, 'multipart/form-data') || str_contains($type, 'application/x-www-form-urlencoded')) {
            return $this->json = $_POST;
        }
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') {
            return $this->json = [];
        }
        if (strlen($raw) > 2_000_000) {
            throw HttpException::badRequest('Request body too large.');
        }
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            throw HttpException::badRequest('Request body must be valid JSON.');
        }
        return $this->json = $data;
    }

    public function input(string $key, mixed $default = null): mixed
    {
        return $this->body()[$key] ?? $default;
    }

    public function queryParam(string $key, mixed $default = null): mixed
    {
        return $this->query[$key] ?? $default;
    }

    /** Accepts ?type=a,b  or  ?type[]=a&type[]=b */
    public function queryList(string $key): array
    {
        $v = $this->query[$key] ?? [];
        if (is_string($v)) {
            $v = $v === '' ? [] : explode(',', $v);
        }
        return array_values(array_filter(array_map(fn ($x) => trim((string) $x), (array) $v), fn ($x) => $x !== ''));
    }

    public function param(string $key): ?string
    {
        return $this->params[$key] ?? null;
    }

    public function ip(): string
    {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}

<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Tiny router: $router->get('/products/{id}', [Controller::class, 'show'], 'admin');
 * Access levels: 'public' | 'optional' (user attached if token present) | 'auth' | 'admin'
 */
final class Router
{
    private array $routes = [];

    public function add(string $method, string $pattern, array $handler, string $access = 'public'): void
    {
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[^/]+)', rtrim($pattern, '/') ?: '/') . '$#';
        $this->routes[] = compact('method', 'pattern', 'regex', 'handler', 'access');
    }

    public function get(string $p, array $h, string $a = 'public'): void    { $this->add('GET', $p, $h, $a); }
    public function post(string $p, array $h, string $a = 'public'): void   { $this->add('POST', $p, $h, $a); }
    public function put(string $p, array $h, string $a = 'public'): void    { $this->add('PUT', $p, $h, $a); }
    public function patch(string $p, array $h, string $a = 'public'): void  { $this->add('PATCH', $p, $h, $a); }
    public function delete(string $p, array $h, string $a = 'public'): void { $this->add('DELETE', $p, $h, $a); }

    public function dispatch(Request $request): void
    {
        $allowed = [];
        foreach ($this->routes as $route) {
            if (!preg_match($route['regex'], $request->path, $m)) {
                continue;
            }
            if ($route['method'] !== $request->method) {
                $allowed[] = $route['method'];
                continue;
            }
            $request->params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);

            match ($route['access']) {
                'public'   => null,
                'optional' => Auth::attempt($request),
                'auth'     => Auth::require($request),
                'admin'    => Auth::requireAdmin($request),
            };

            [$class, $method] = $route['handler'];
            (new $class())->$method($request);
            return;
        }

        if ($allowed) {
            header('Allow: ' . implode(', ', array_unique($allowed)));
            throw new HttpException(405, 'Method not allowed');
        }
        throw HttpException::notFound('Endpoint not found: ' . $request->method . ' ' . $request->path);
    }
}

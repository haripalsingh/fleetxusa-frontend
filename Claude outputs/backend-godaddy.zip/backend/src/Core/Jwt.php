<?php
declare(strict_types=1);

namespace App\Core;

/** HS256 JSON Web Tokens without external libraries. */
final class Jwt
{
    private static function secret(): string
    {
        $secret = (string) Env::get('JWT_SECRET', '');
        if (strlen($secret) >= 32) {
            return $secret;
        }
        // No JWT_SECRET in .env yet: generate one once and keep it in storage/ (never web-accessible).
        $file = BASE_PATH . '/storage/jwt_secret.key';
        if (is_file($file) && strlen($stored = trim((string) file_get_contents($file))) >= 32) {
            return $stored;
        }
        $generated = bin2hex(random_bytes(32));
        if (@file_put_contents($file, $generated, LOCK_EX) === false) {
            throw new \RuntimeException('Set JWT_SECRET in .env (at least 32 characters) or make storage/ writable.');
        }
        @chmod($file, 0600);
        return $generated;
    }

    private static function b64(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function unb64(string $data): string
    {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4)) ?: '';
    }

    public static function encode(array $claims, int $ttlSeconds): string
    {
        $now = time();
        $claims += ['iat' => $now, 'exp' => $now + $ttlSeconds, 'iss' => Env::get('APP_URL', 'fleetx')];
        $header = self::b64(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $payload = self::b64(json_encode($claims));
        $sig = self::b64(hash_hmac('sha256', "$header.$payload", self::secret(), true));
        return "$header.$payload.$sig";
    }

    /** Returns the claims or null when invalid/expired. */
    public static function decode(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return null;
        }
        [$h, $p, $s] = $parts;
        $header = json_decode(self::unb64($h), true);
        if (($header['alg'] ?? '') !== 'HS256') {
            return null;
        }
        $expected = self::b64(hash_hmac('sha256', "$h.$p", self::secret(), true));
        if (!hash_equals($expected, $s)) {
            return null;
        }
        $claims = json_decode(self::unb64($p), true);
        if (!is_array($claims) || ($claims['exp'] ?? 0) < time()) {
            return null;
        }
        return $claims;
    }
}

<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/** Throw anywhere to return a JSON error with the given HTTP status. */
class HttpException extends RuntimeException
{
    public function __construct(
        public readonly int $status,
        string $message,
        public readonly array $errors = []
    ) {
        parent::__construct($message, $status);
    }

    public static function badRequest(string $m = 'Bad request', array $errors = []): self { return new self(400, $m, $errors); }
    public static function unauthorized(string $m = 'Please log in to continue.'): self { return new self(401, $m); }
    public static function forbidden(string $m = 'You do not have permission to do that.'): self { return new self(403, $m); }
    public static function notFound(string $m = 'Not found'): self { return new self(404, $m); }
    public static function conflict(string $m, array $errors = []): self { return new self(409, $m, $errors); }
    public static function validation(array $errors, string $m = 'Please correct the highlighted fields.'): self { return new self(422, $m, $errors); }
    public static function tooMany(string $m = 'Too many attempts. Please try again later.'): self { return new self(429, $m); }
}

<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Validator::make($data, [
 *   'email' => 'required|email|max:190',
 *   'price' => 'required|numeric|min:0',
 *   'role'  => 'in:user,dealer,vendor',
 * ]);
 * Returns only the validated keys (strings trimmed). Throws 422 with per-field messages.
 *
 * Rules: required, nullable, string, email, numeric, integer, boolean, array,
 *        min:n, max:n (length for strings, value for numbers), in:a,b, regex:/.../,
 *        date, confirmed (expects <field>_confirmation), password (8+ chars, letter + number)
 */
final class Validator
{
    public static function make(array $data, array $rules, array $labels = []): array
    {
        $errors = [];
        $clean = [];

        foreach ($rules as $field => $ruleString) {
            $rules = is_array($ruleString) ? $ruleString : explode('|', $ruleString);
            $label = $labels[$field] ?? ucfirst(str_replace('_', ' ', $field));
            $present = array_key_exists($field, $data);
            $value = $data[$field] ?? null;
            if (is_string($value)) {
                $value = trim($value);
            }
            $empty = $value === null || $value === '' || (is_array($value) && !$value);

            if (in_array('required', $rules, true) && $empty) {
                $errors[$field] = "$label is required.";
                continue;
            }
            if ($empty) {
                if ($present) {
                    $clean[$field] = in_array('array', $rules, true) ? [] : null;
                }
                continue;
            }

            $isNumeric = in_array('numeric', $rules, true) || in_array('integer', $rules, true);

            foreach ($rules as $rule) {
                [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);
                $error = match ($name) {
                    'required', 'nullable' => null,
                    'string'   => is_string($value) ? null : "$label must be text.",
                    'email'    => filter_var($value, FILTER_VALIDATE_EMAIL) ? null : 'Please enter a valid email address.',
                    'numeric'  => is_numeric($value) ? null : "$label must be a number.",
                    'integer'  => filter_var($value, FILTER_VALIDATE_INT) !== false ? null : "$label must be a whole number.",
                    'boolean'  => in_array($value, [true, false, 0, 1, '0', '1', 'true', 'false'], true) ? null : "$label must be true or false.",
                    'array'    => is_array($value) ? null : "$label must be a list.",
                    'min'      => $isNumeric
                        ? ((float) $value >= (float) $arg ? null : "$label must be at least $arg.")
                        : (mb_strlen((string) $value) >= (int) $arg ? null : "$label must be at least $arg characters."),
                    'max'      => $isNumeric
                        ? ((float) $value <= (float) $arg ? null : "$label may not be greater than $arg.")
                        : (is_array($value)
                            ? (count($value) <= (int) $arg ? null : "$label may not have more than $arg items.")
                            : (mb_strlen((string) $value) <= (int) $arg ? null : "$label may not be longer than $arg characters.")),
                    'in'       => in_array((string) $value, explode(',', (string) $arg), true) ? null : "$label is not a valid option.",
                    'regex'    => preg_match((string) $arg, (string) $value) ? null : "$label format is invalid.",
                    'date'     => strtotime((string) $value) !== false ? null : "$label must be a valid date.",
                    'confirmed'=> ($data[$field . '_confirmation'] ?? null) === $data[$field] ? null : "$label confirmation does not match.",
                    'password' => (mb_strlen((string) $value) >= 8 && preg_match('/[A-Za-z]/', (string) $value) && preg_match('/\d/', (string) $value))
                        ? null : 'Password must be at least 8 characters and include a letter and a number.',
                    default    => throw new \LogicException("Unknown validation rule: $name"),
                };
                if ($error !== null) {
                    $errors[$field] = $error;
                    break;
                }
            }

            if (!isset($errors[$field])) {
                $clean[$field] = match (true) {
                    in_array('integer', $rules, true) => (int) $value,
                    in_array('numeric', $rules, true) => round((float) $value, 4),
                    in_array('boolean', $rules, true) => in_array($value, [true, 1, '1', 'true'], true),
                    default => $value,
                };
            }
        }

        if ($errors) {
            throw HttpException::validation($errors);
        }
        return $clean;
    }
}

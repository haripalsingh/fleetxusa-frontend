<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Every API response has the same envelope:
 *   { "success": true,  "data": ..., "meta": {...}?, "message": "..."? }
 *   { "success": false, "message": "...", "errors": { field: "msg" }? }
 */
final class Response
{
    public static function json(mixed $payload, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION);
        exit;
    }

    public static function ok(mixed $data = null, ?string $message = null, array $meta = [], int $status = 200): never
    {
        $out = ['success' => true, 'data' => $data];
        if ($message !== null) {
            $out['message'] = $message;
        }
        if ($meta) {
            $out['meta'] = $meta;
        }
        self::json($out, $status);
    }

    public static function created(mixed $data = null, ?string $message = null): never
    {
        self::ok($data, $message, [], 201);
    }

    public static function error(string $message, int $status = 400, array $errors = []): never
    {
        $out = ['success' => false, 'message' => $message];
        if ($errors) {
            $out['errors'] = $errors;
        }
        self::json($out, $status);
    }
}

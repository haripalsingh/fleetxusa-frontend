<?php
declare(strict_types=1);

namespace App\Core;

final class Helpers
{
    /** "Air Spring & Shocks" -> "air-spring-shocks" (same rule as the Next.js slugify) */
    public static function slugify(string $text): string
    {
        $text = strtolower(str_replace('&', ' ', $text));
        $text = preg_replace('/[^a-z0-9]+/', '-', $text);
        return trim((string) $text, '-') ?: 'item';
    }

    /** Make a slug unique in a table by appending -2, -3... */
    public static function uniqueSlug(string $table, string $base, ?int $ignoreId = null): string
    {
        $slug = self::slugify($base);
        $candidate = $slug;
        $i = 2;
        while (true) {
            $params = [$candidate];
            $sql = "SELECT id FROM `$table` WHERE slug = ?";
            if ($ignoreId) {
                $sql .= ' AND id <> ?';
                $params[] = $ignoreId;
            }
            if (!Database::fetch($sql, $params)) {
                return $candidate;
            }
            $candidate = $slug . '-' . $i++;
        }
    }

    /**
     * Stored image paths are either absolute URLs, frontend paths ("/images/..")
     * or files uploaded to this backend ("uploads/..."), which get the APP_URL prefix.
     */
    public static function mediaUrl(?string $path): ?string
    {
        if (!$path) {
            return null;
        }
        if (str_starts_with($path, 'http') || str_starts_with($path, '/')) {
            return $path;
        }
        return self::appUrl() . '/' . ltrim($path, '/');
    }

    /** APP_URL from .env, or detected from the current request (…/fleetxusa-backend). */
    public static function appUrl(): string
    {
        $url = (string) Env::get('APP_URL', '');
        if ($url !== '') {
            return rtrim($url, '/');
        }
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/api/index.php', 2)), '/');
        return ($https ? 'https' : 'http') . '://' . $host . $dir;
    }

    public static function money(float|string|null $v): float
    {
        return round((float) $v, 2);
    }

    /** page / per_page from the query string with sane bounds. */
    public static function pagination(Request $r, int $default = 24, int $max = 100): array
    {
        $perPage = max(1, min($max, (int) $r->queryParam('per_page', $default)));
        $page = max(1, (int) $r->queryParam('page', 1));
        return [$page, $perPage, ($page - 1) * $perPage];
    }

    public static function meta(int $total, int $page, int $perPage): array
    {
        return [
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => max(1, (int) ceil($total / $perPage)),
        ];
    }

    /** Escape user text going into LIKE patterns. */
    public static function like(string $term): string
    {
        return '%' . addcslashes($term, '%_\\') . '%';
    }
}

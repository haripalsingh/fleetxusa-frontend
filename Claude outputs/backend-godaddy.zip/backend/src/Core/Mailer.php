<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Sends plain HTML email with PHP mail(). On shared hosting (cPanel/Hostinger) this works
 * out of the box. For SMTP, swap the body of send() for PHPMailer.
 * With APP_DEBUG=true every mail is also written to storage/logs/mail.log (handy on XAMPP).
 */
final class Mailer
{
    public static function send(string $to, string $subject, string $html): bool
    {
        $from = Env::get('MAIL_FROM', 'no-reply@localhost');
        $fromName = Env::get('MAIL_FROM_NAME', Env::get('APP_NAME', 'Store'));

        if (Env::bool('APP_DEBUG')) {
            @file_put_contents(
                BASE_PATH . '/storage/logs/mail.log',
                sprintf("[%s] To: %s | Subject: %s\n%s\n\n", gmdate('c'), $to, $subject, self::plain($html)),
                FILE_APPEND
            );
        }

        $headers = implode("\r\n", [
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            sprintf('From: %s <%s>', mb_encode_mimeheader((string) $fromName), $from),
        ]);
        try {
            return @mail($to, mb_encode_mimeheader($subject), self::layout($html), $headers);
        } catch (\Throwable) {
            return false;
        }
    }

    /** Readable text version for the debug log (keeps link targets). */
    private static function plain(string $html): string
    {
        $html = preg_replace('#<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>#i', '$2: $1', $html);
        $html = preg_replace('#</(p|tr|div)>|<br\s*/?>#i', "\n", (string) $html);
        return trim(html_entity_decode(strip_tags((string) $html)));
    }

    private static function layout(string $body): string
    {
        $name = htmlspecialchars((string) Env::get('APP_NAME', 'Fleet X Parts'));
        return <<<HTML
<!doctype html><html><body style="margin:0;background:#f3f4f6;font-family:Arial,sans-serif;color:#111">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;max-width:600px">
<tr><td style="background:#000;color:#fff;padding:18px 24px;font-size:20px;font-weight:bold">{$name}</td></tr>
<tr><td style="padding:24px;font-size:14px;line-height:1.6">{$body}</td></tr>
</table></td></tr></table></body></html>
HTML;
    }
}

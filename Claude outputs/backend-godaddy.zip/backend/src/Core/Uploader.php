<?php
declare(strict_types=1);

namespace App\Core;

/** Safe image uploads: checks real MIME type, size, and uses random file names. */
final class Uploader
{
    private const TYPES = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
        'image/avif' => 'avif',
    ];

    /** @return string[] relative paths like "uploads/products/2026/09/abc.jpg" */
    public static function images(string $field, string $folder): array
    {
        if (empty($_FILES[$field])) {
            throw HttpException::validation([$field => 'Please choose at least one image.']);
        }
        $files = self::normalize($_FILES[$field]);
        $maxBytes = Env::int('UPLOAD_MAX_MB', 5) * 1024 * 1024;
        $finfo = new \finfo(FILEINFO_MIME_TYPE);

        // Validate everything first so a bad file doesn't leave half an upload behind
        foreach ($files as $f) {
            if ($f['error'] !== UPLOAD_ERR_OK) {
                throw HttpException::validation([$field => "Upload failed for {$f['name']} (code {$f['error']})."]);
            }
            if ($f['size'] > $maxBytes) {
                throw HttpException::validation([$field => "{$f['name']} is larger than " . Env::int('UPLOAD_MAX_MB', 5) . 'MB.']);
            }
            $mime = $finfo->file($f['tmp_name']);
            if (!isset(self::TYPES[$mime])) {
                throw HttpException::validation([$field => "{$f['name']} is not a supported image (JPG, PNG, WEBP, GIF, AVIF)."]);
            }
        }

        $relDir = 'uploads/' . trim($folder, '/') . '/' . gmdate('Y/m');
        $absDir = BASE_PATH . '/' . $relDir;
        if (!is_dir($absDir) && !mkdir($absDir, 0755, true) && !is_dir($absDir)) {
            throw new \RuntimeException('Could not create upload directory.');
        }

        $paths = [];
        foreach ($files as $f) {
            $ext = self::TYPES[$finfo->file($f['tmp_name'])];
            $name = bin2hex(random_bytes(12)) . '.' . $ext;
            $ok = is_uploaded_file($f['tmp_name'])
                ? move_uploaded_file($f['tmp_name'], "$absDir/$name")
                : rename($f['tmp_name'], "$absDir/$name");
            if (!$ok) {
                throw new \RuntimeException('Could not save uploaded file.');
            }
            @chmod("$absDir/$name", 0644);
            $paths[] = "$relDir/$name";
        }
        return $paths;
    }

    public static function delete(?string $relPath): void
    {
        if (!$relPath || !str_starts_with($relPath, 'uploads/') || str_contains($relPath, '..')) {
            return; // only ever delete files inside uploads/
        }
        $abs = BASE_PATH . '/' . $relPath;
        if (is_file($abs)) {
            @unlink($abs);
        }
    }

    private static function normalize(array $file): array
    {
        if (!is_array($file['name'])) {
            return [$file];
        }
        $out = [];
        foreach ($file['name'] as $i => $name) {
            $out[] = [
                'name'     => $name,
                'type'     => $file['type'][$i],
                'tmp_name' => $file['tmp_name'][$i],
                'error'    => $file['error'][$i],
                'size'     => $file['size'][$i],
            ];
        }
        return $out;
    }
}

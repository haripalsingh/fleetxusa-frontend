<?php
declare(strict_types=1);

namespace App\Core;

/** Fixed-window rate limiter stored in MySQL (works on shared hosting, no Redis). */
final class RateLimiter
{
    public static function hit(string $key, int $maxAttempts, int $windowSeconds): void
    {
        $key = substr($key, 0, 190);
        $row = Database::fetch('SELECT hits, reset_at FROM rate_limits WHERE rl_key = ?', [$key]);
        $now = time();

        if (!$row || strtotime($row['reset_at'] . ' UTC') <= $now) {
            Database::query(
                'REPLACE INTO rate_limits (rl_key, hits, reset_at) VALUES (?, 1, ?)',
                [$key, gmdate('Y-m-d H:i:s', $now + $windowSeconds)]
            );
            return;
        }
        if ((int) $row['hits'] >= $maxAttempts) {
            $wait = max(1, (int) ceil((strtotime($row['reset_at'] . ' UTC') - $now) / 60));
            throw HttpException::tooMany("Too many attempts. Please try again in $wait minute" . ($wait > 1 ? 's' : '') . '.');
        }
        Database::query('UPDATE rate_limits SET hits = hits + 1 WHERE rl_key = ?', [$key]);
    }

    public static function clear(string $key): void
    {
        Database::query('DELETE FROM rate_limits WHERE rl_key = ?', [substr($key, 0, 190)]);
    }
}

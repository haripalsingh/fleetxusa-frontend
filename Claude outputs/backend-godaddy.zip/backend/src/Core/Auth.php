<?php
declare(strict_types=1);

namespace App\Core;

final class Auth
{
    public static function issueToken(array $user): string
    {
        return Jwt::encode([
            'sub'  => (int) $user['id'],
            'role' => $user['role'],
            'ver'  => (int) $user['token_version'],
        ], Env::int('JWT_TTL_HOURS', 168) * 3600);
    }

    /** Attach the user if a valid token is present; never fails. */
    public static function attempt(Request $request): ?array
    {
        $token = $request->bearerToken();
        if (!$token) {
            return null;
        }
        $claims = Jwt::decode($token);
        if (!$claims) {
            return null;
        }
        $user = Database::fetch(
            'SELECT id, name, email, mobile, role, status, token_version, newsletter, created_at FROM users WHERE id = ?',
            [(int) $claims['sub']]
        );
        // token_version lets us revoke all tokens (password change / logout everywhere)
        if (!$user || $user['status'] !== 'active' || (int) $user['token_version'] !== (int) ($claims['ver'] ?? 0)) {
            return null;
        }
        return $request->user = $user;
    }

    public static function require(Request $request): array
    {
        $user = self::attempt($request);
        if (!$user) {
            throw HttpException::unauthorized('Your session has expired. Please log in again.');
        }
        return $user;
    }

    public static function requireAdmin(Request $request): array
    {
        $user = self::require($request);
        if ($user['role'] !== 'admin') {
            throw HttpException::forbidden();
        }
        return $user;
    }

    public static function isAdmin(Request $request): bool
    {
        return ($request->user['role'] ?? null) === 'admin';
    }

    /** Public shape of a user (never includes the password hash). */
    public static function publicUser(array $u): array
    {
        return [
            'id'         => (int) $u['id'],
            'name'       => $u['name'],
            'email'      => $u['email'],
            'mobile'     => $u['mobile'] ?? null,
            'role'       => $u['role'],
            'newsletter' => (bool) ($u['newsletter'] ?? false),
            'created_at' => $u['created_at'] ?? null,
        ];
    }
}

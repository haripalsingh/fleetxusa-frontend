<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Helpers;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;

final class UserController
{
    private const ADDRESS_RULES = [
        'label'         => 'string|max:50',
        'full_name'     => 'required|string|max:120',
        'phone'         => 'required|string|regex:/^[0-9+\-\s().]{7,20}$/',
        'address_line1' => 'required|string|max:190',
        'address_line2' => 'string|max:190',
        'city'          => 'required|string|max:100',
        'state'         => 'required|string|max:100',
        'zip_code'      => 'required|string|regex:/^[A-Za-z0-9\-\s]{3,10}$/',
        'country'       => 'string|max:100',
        'is_default'    => 'boolean',
    ];

    // ---- My account ---------------------------------------------------------------

    /** GET /api/users/me  (profile + quick stats) */
    public function me(Request $r): void
    {
        $stats = Database::fetch(
            "SELECT COUNT(*) AS orders, COALESCE(SUM(CASE WHEN status NOT IN ('cancelled','refunded') THEN grand_total END), 0) AS spent
             FROM orders WHERE user_id = ?",
            [$r->user['id']]
        );
        Response::ok(Auth::publicUser($r->user) + [
            'stats' => ['orders' => (int) $stats['orders'], 'total_spent' => Helpers::money($stats['spent'])],
        ]);
    }

    /** PUT /api/users/me  {name, mobile, newsletter} */
    public function updateMe(Request $r): void
    {
        $data = Validator::make($r->body(), [
            'name'       => 'string|min:2|max:120',
            'mobile'     => 'string|regex:/^[0-9+\-\s()]{10,20}$/',
            'newsletter' => 'boolean',
        ], ['mobile' => 'Mobile number']);
        if (array_key_exists('newsletter', $data)) {
            $data['newsletter'] = (int) $data['newsletter'];
        }
        $data = array_filter($data, fn ($v) => $v !== null);
        Database::update('users', (int) $r->user['id'], $data);
        $user = Database::fetch('SELECT * FROM users WHERE id = ?', [$r->user['id']]);
        Response::ok(Auth::publicUser($user), 'Profile updated.');
    }

    /** PUT /api/users/me/password  {current_password, password, password_confirmation} */
    public function changePassword(Request $r): void
    {
        $data = Validator::make($r->body(), [
            'current_password' => 'required|string',
            'password'         => 'required|password|max:72|confirmed',
        ]);
        $user = Database::fetch('SELECT * FROM users WHERE id = ?', [$r->user['id']]);
        if (!password_verify($data['current_password'], $user['password_hash'])) {
            throw HttpException::validation(['current_password' => 'Your current password is incorrect.']);
        }
        // bump token_version: every other session is logged out
        Database::query(
            'UPDATE users SET password_hash = ?, token_version = token_version + 1 WHERE id = ?',
            [password_hash($data['password'], PASSWORD_DEFAULT), $user['id']]
        );
        $user = Database::fetch('SELECT * FROM users WHERE id = ?', [$user['id']]);
        Response::ok(['token' => Auth::issueToken($user), 'user' => Auth::publicUser($user)], 'Password changed.');
    }

    /** GET /api/users/me/addresses */
    public function addresses(Request $r): void
    {
        Response::ok(array_map([self::class, 'formatAddress'], Database::fetchAll(
            'SELECT * FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC', [$r->user['id']]
        )));
    }

    /** POST /api/users/me/addresses */
    public function storeAddress(Request $r): void
    {
        $data = Validator::make($r->body(), self::ADDRESS_RULES, ['zip_code' => 'ZIP code', 'address_line1' => 'Address']);
        $uid = (int) $r->user['id'];
        if ((int) Database::value('SELECT COUNT(*) FROM user_addresses WHERE user_id = ?', [$uid]) >= 20) {
            throw HttpException::conflict('You can save up to 20 addresses.');
        }
        $first = !Database::value('SELECT COUNT(*) FROM user_addresses WHERE user_id = ?', [$uid]);
        $data['is_default'] = (int) (($data['is_default'] ?? false) || $first);
        $data['country'] = $data['country'] ?? 'United States';
        $data['user_id'] = $uid;
        $id = Database::transaction(function () use ($data, $uid) {
            if ($data['is_default']) {
                Database::query('UPDATE user_addresses SET is_default = 0 WHERE user_id = ?', [$uid]);
            }
            return Database::insert('user_addresses', $data);
        });
        Response::created(self::formatAddress(Database::fetch('SELECT * FROM user_addresses WHERE id = ?', [$id])), 'Address saved.');
    }

    /** PUT /api/users/me/addresses/{id} */
    public function updateAddress(Request $r): void
    {
        $address = $this->findAddress($r);
        $data = Validator::make($r->body(), self::ADDRESS_RULES, ['zip_code' => 'ZIP code', 'address_line1' => 'Address']);
        $data['is_default'] = (int) ($data['is_default'] ?? $address['is_default']);
        Database::transaction(function () use ($data, $address) {
            if ($data['is_default']) {
                Database::query('UPDATE user_addresses SET is_default = 0 WHERE user_id = ?', [$address['user_id']]);
            }
            Database::update('user_addresses', (int) $address['id'], $data);
        });
        Response::ok(self::formatAddress(Database::fetch('SELECT * FROM user_addresses WHERE id = ?', [$address['id']])), 'Address updated.');
    }

    /** DELETE /api/users/me/addresses/{id} */
    public function deleteAddress(Request $r): void
    {
        $address = $this->findAddress($r);
        Database::query('DELETE FROM user_addresses WHERE id = ?', [$address['id']]);
        if ($address['is_default']) {
            Database::query('UPDATE user_addresses SET is_default = 1 WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$address['user_id']]);
        }
        Response::ok(null, 'Address deleted.');
    }

    // ---- Admin: customers ---------------------------------------------------------------

    /** GET /api/users  ?q= ?role= ?status= */
    public function index(Request $r): void
    {
        [$page, $perPage, $offset] = Helpers::pagination($r, 25, 100);
        $where = [];
        $params = [];
        if ($q = trim((string) $r->queryParam('q', ''))) {
            $where[] = '(u.name LIKE :q1 OR u.email LIKE :q2 OR u.mobile LIKE :q3)';
            $params['q1'] = $params['q2'] = $params['q3'] = Helpers::like($q);
        }
        if (in_array($role = $r->queryParam('role'), ['user', 'dealer', 'vendor', 'admin'], true)) {
            $where[] = 'u.role = :role';
            $params['role'] = $role;
        }
        if (in_array($status = $r->queryParam('status'), ['active', 'blocked'], true)) {
            $where[] = 'u.status = :status';
            $params['status'] = $status;
        }
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::value("SELECT COUNT(*) FROM users u $w", $params);
        $rows = Database::fetchAll(
            "SELECT u.*, COUNT(o.id) AS order_count,
                    COALESCE(SUM(CASE WHEN o.status NOT IN ('cancelled','refunded') THEN o.grand_total END), 0) AS total_spent,
                    MAX(o.created_at) AS last_order_at
             FROM users u LEFT JOIN orders o ON o.user_id = u.id
             $w GROUP BY u.id ORDER BY u.created_at DESC LIMIT $perPage OFFSET $offset",
            $params
        );
        Response::ok(array_map([self::class, 'formatCustomer'], $rows), null, Helpers::meta($total, $page, $perPage));
    }

    /** GET /api/users/{id} */
    public function show(Request $r): void
    {
        $u = Database::fetch(
            "SELECT u.*, COUNT(o.id) AS order_count,
                    COALESCE(SUM(CASE WHEN o.status NOT IN ('cancelled','refunded') THEN o.grand_total END), 0) AS total_spent,
                    MAX(o.created_at) AS last_order_at
             FROM users u LEFT JOIN orders o ON o.user_id = u.id WHERE u.id = ? GROUP BY u.id",
            [(int) $r->param('id')]
        );
        if (!$u) {
            throw HttpException::notFound('Customer not found.');
        }
        $out = self::formatCustomer($u);
        $out['addresses'] = array_map([self::class, 'formatAddress'], Database::fetchAll('SELECT * FROM user_addresses WHERE user_id = ?', [$u['id']]));
        Response::ok($out);
    }

    /** PUT /api/users/{id}  {name, mobile, role, status} */
    public function update(Request $r): void
    {
        $id = (int) $r->param('id');
        $user = Database::fetch('SELECT * FROM users WHERE id = ?', [$id]);
        if (!$user) {
            throw HttpException::notFound('Customer not found.');
        }
        $data = Validator::make($r->body(), [
            'name'   => 'string|min:2|max:120',
            'mobile' => 'string|max:20',
            'role'   => 'in:user,dealer,vendor,admin',
            'status' => 'in:active,blocked',
        ]);
        if ($id === (int) $r->user['id'] && (($data['role'] ?? 'admin') !== 'admin' || ($data['status'] ?? 'active') !== 'active')) {
            throw HttpException::conflict('You cannot remove your own admin access.');
        }
        $data = array_filter($data, fn ($v) => $v !== null);
        if (($data['status'] ?? null) === 'blocked' || (isset($data['role']) && $data['role'] !== $user['role'])) {
            Database::query('UPDATE users SET token_version = token_version + 1 WHERE id = ?', [$id]); // force re-login
        }
        Database::update('users', $id, $data);
        Response::ok(self::formatCustomer(Database::fetch('SELECT * FROM users WHERE id = ?', [$id])), 'Customer updated.');
    }

    // ------------------------------------------------------------------------------
    private function findAddress(Request $r): array
    {
        $a = Database::fetch('SELECT * FROM user_addresses WHERE id = ? AND user_id = ?', [(int) $r->param('id'), $r->user['id']]);
        if (!$a) {
            throw HttpException::notFound('Address not found.');
        }
        return $a;
    }

    public static function formatAddress(array $a): array
    {
        return [
            'id'            => (int) $a['id'],
            'label'         => $a['label'],
            'full_name'     => $a['full_name'],
            'phone'         => $a['phone'],
            'address_line1' => $a['address_line1'],
            'address_line2' => $a['address_line2'],
            'city'          => $a['city'],
            'state'         => $a['state'],
            'zip_code'      => $a['zip_code'],
            'country'       => $a['country'],
            'is_default'    => (bool) $a['is_default'],
        ];
    }

    private static function formatCustomer(array $u): array
    {
        return Auth::publicUser($u) + [
            'status'        => $u['status'],
            'last_login_at' => $u['last_login_at'],
            'order_count'   => (int) ($u['order_count'] ?? 0),
            'total_spent'   => Helpers::money($u['total_spent'] ?? 0),
            'last_order_at' => $u['last_order_at'] ?? null,
        ];
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Services\OrderService;
use App\Services\Payment\PaymentManager;
use App\Services\Payment\StripeGateway;

final class PaymentController
{
    /** GET /api/payments/methods */
    public function methods(Request $r): void
    {
        Response::ok(array_map(fn ($g) => $g->describe(), PaymentManager::enabled()));
    }

    /** POST /api/payments/{number}/retry  - new Stripe session for an unpaid order */
    public function retry(Request $r): void
    {
        $order = Database::fetch('SELECT * FROM orders WHERE order_number = ?', [(string) $r->param('number')]);
        $key = (string) $r->queryParam('key', '');
        $allowed = $order && (
            ($r->user && (int) $order['user_id'] === (int) $r->user['id']) ||
            Auth::isAdmin($r) ||
            ($key !== '' && hash_equals($order['access_key'], $key))
        );
        if (!$allowed) {
            throw HttpException::notFound('Order not found.');
        }
        if ($order['status'] !== 'pending' || $order['payment_status'] === 'paid') {
            throw HttpException::conflict('This order does not need payment.');
        }
        $gateway = PaymentManager::get($order['payment_method']);
        $items = Database::fetchAll('SELECT * FROM order_items WHERE order_id = ?', [$order['id']]);
        Response::ok($gateway->start($order, $items));
    }

    /** POST /api/payments/stripe/webhook */
    public function stripeWebhook(Request $r): void
    {
        $payload = file_get_contents('php://input') ?: '';
        $event = StripeGateway::verifyWebhook($payload, (string) $r->header('stripe-signature'));
        $session = $event['data']['object'] ?? [];
        $number = $session['metadata']['order_number'] ?? $session['client_reference_id'] ?? null;
        $order = $number ? Database::fetch('SELECT * FROM orders WHERE order_number = ?', [$number]) : null;

        if (!$order) {
            Response::ok(['ignored' => true]); // unknown order - acknowledge so Stripe stops retrying
        }

        Database::query(
            'UPDATE payments SET payload = ? WHERE order_id = ? AND provider_ref = ?',
            [$payload, $order['id'], $session['id'] ?? '']
        );

        switch ($event['type'] ?? '') {
            case 'checkout.session.completed':
            case 'checkout.session.async_payment_succeeded':
                if (($session['payment_status'] ?? '') === 'paid') {
                    Database::query("UPDATE payments SET status = 'succeeded' WHERE provider_ref = ?", [$session['id']]);
                    OrderService::markPaid($order, $session['payment_intent'] ?? $session['id'], null, 'Paid with card (Stripe)');
                }
                break;

            case 'checkout.session.async_payment_failed':
                Database::query("UPDATE payments SET status = 'failed' WHERE provider_ref = ?", [$session['id']]);
                Database::query("UPDATE orders SET payment_status = 'failed' WHERE id = ? AND payment_status <> 'paid'", [$order['id']]);
                break;

            case 'checkout.session.expired':
                Database::query("UPDATE payments SET status = 'cancelled' WHERE provider_ref = ?", [$session['id']]);
                // Release reserved stock only if no other session is still open / paid
                $fresh = Database::fetch('SELECT * FROM orders WHERE id = ?', [$order['id']]);
                $open = (int) Database::value("SELECT COUNT(*) FROM payments WHERE order_id = ? AND status IN ('pending','succeeded')", [$order['id']]);
                if ($fresh['status'] === 'pending' && $fresh['payment_status'] !== 'paid' && $open === 0) {
                    OrderService::changeStatus($fresh, 'cancelled', 'Payment was not completed in time', null);
                }
                break;
        }
        Response::ok(['received' => true]);
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Helpers;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Services\CartService;
use App\Services\CouponService;
use App\Services\OrderService;

final class CouponController
{
    private const RULES = [
        'code'                 => 'required|string|max:40|regex:/^[A-Za-z0-9_\-]+$/',
        'description'          => 'string|max:190',
        'type'                 => 'required|in:percent,fixed,free_shipping',
        'value'                => 'numeric|min:0|max:1000000',
        'min_order_amount'     => 'numeric|min:0',
        'max_discount_amount'  => 'numeric|min:0',
        'usage_limit'          => 'integer|min:1',
        'usage_limit_per_user' => 'integer|min:1',
        'starts_at'            => 'date',
        'expires_at'           => 'date',
        'is_active'            => 'boolean',
    ];

    /** POST /api/coupons/validate  {code, email?}  -> discount + totals for the current cart */
    public function validate(Request $r): void
    {
        $data = Validator::make($r->body(), ['code' => 'required|string|max:40', 'email' => 'email']);
        $summary = CartService::summary(CartService::resolve($r));
        if ($summary['count'] === 0) {
            throw HttpException::badRequest('Your cart is empty.');
        }
        $result = CouponService::apply($data['code'], $summary['subtotal'], $r->user['id'] ?? null, $data['email'] ?? ($r->user['email'] ?? null));
        Response::ok([
            'code'          => $result['coupon']['code'],
            'description'   => $result['coupon']['description'],
            'type'          => $result['coupon']['type'],
            'discount'      => $result['discount'],
            'free_shipping' => $result['free_shipping'],
            'totals'        => OrderService::totals($summary['subtotal'], $result['discount'], $result['free_shipping']),
        ], 'Coupon applied.');
    }

    /** GET /api/coupons (admin) */
    public function index(Request $r): void
    {
        [$page, $perPage, $offset] = Helpers::pagination($r, 50);
        $total = (int) Database::value('SELECT COUNT(*) FROM coupons');
        $rows = Database::fetchAll("SELECT * FROM coupons ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
        Response::ok(array_map([CouponService::class, 'format'], $rows), null, Helpers::meta($total, $page, $perPage));
    }

    /** POST /api/coupons (admin) */
    public function store(Request $r): void
    {
        $data = $this->clean(Validator::make($r->body(), self::RULES));
        if (Database::fetch('SELECT id FROM coupons WHERE code = ?', [$data['code']])) {
            throw HttpException::validation(['code' => 'This code already exists.']);
        }
        $id = Database::insert('coupons', $data);
        Response::created(CouponService::format(Database::fetch('SELECT * FROM coupons WHERE id = ?', [$id])), 'Coupon created.');
    }

    /** PUT /api/coupons/{id} (admin) */
    public function update(Request $r): void
    {
        $coupon = $this->find((int) $r->param('id'));
        $rules = self::RULES;
        $rules['code'] = 'string|max:40|regex:/^[A-Za-z0-9_\-]+$/';
        $rules['type'] = 'in:percent,fixed,free_shipping';
        $data = $this->clean(Validator::make($r->body(), $rules));
        if (!empty($data['code']) && Database::fetch('SELECT id FROM coupons WHERE code = ? AND id <> ?', [$data['code'], $coupon['id']])) {
            throw HttpException::validation(['code' => 'This code already exists.']);
        }
        Database::update('coupons', (int) $coupon['id'], $data);
        Response::ok(CouponService::format(Database::fetch('SELECT * FROM coupons WHERE id = ?', [$coupon['id']])), 'Coupon updated.');
    }

    /** DELETE /api/coupons/{id} (admin) */
    public function destroy(Request $r): void
    {
        $coupon = $this->find((int) $r->param('id'));
        Database::query('DELETE FROM coupons WHERE id = ?', [$coupon['id']]);
        Response::ok(null, 'Coupon deleted.');
    }

    private function find(int $id): array
    {
        $c = Database::fetch('SELECT * FROM coupons WHERE id = ?', [$id]);
        if (!$c) {
            throw HttpException::notFound('Coupon not found.');
        }
        return $c;
    }

    private function clean(array $data): array
    {
        if (isset($data['code'])) {
            $data['code'] = strtoupper($data['code']);
        }
        if (($data['type'] ?? null) === 'percent' && ($data['value'] ?? 0) > 100) {
            throw HttpException::validation(['value' => 'A percentage discount cannot be more than 100.']);
        }
        foreach (['starts_at', 'expires_at'] as $k) {
            if (!empty($data[$k])) {
                $data[$k] = gmdate('Y-m-d H:i:s', strtotime($data[$k]));
            }
        }
        if (array_key_exists('is_active', $data)) {
            $data['is_active'] = (int) $data['is_active'];
        }
        return $data;
    }
}

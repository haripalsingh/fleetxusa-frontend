<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Helpers;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\Validator;
use App\Services\Inventory;

final class ProductController
{
    private const PRODUCT_RULES = [
        'name'              => 'required|string|max:190',
        'slug'              => 'string|max:210|regex:/^[a-z0-9-]+$/',
        'sku'               => 'required|string|max:64|regex:/^[A-Za-z0-9._\-]+$/',
        'category_id'       => 'integer',
        'brand'             => 'string|max:100',
        'product_type'      => 'string|max:100',
        'short_description' => 'string|max:500',
        'description'       => 'string|max:20000',
        'warranty'          => 'string|max:5000',
        'specifications'    => 'array|max:50',
        'video_url'         => 'string|max:255',
        'status'            => 'in:draft,active,archived',
        'is_featured'       => 'boolean',
        'weight_lbs'        => 'numeric|min:0',
        'meta_title'        => 'string|max:190',
        'meta_description'  => 'string|max:300',
        'variants'          => 'array|max:100',
        'images'            => 'array|max:20',
        // shortcut for single-variant products
        'price'             => 'numeric|min:0|max:1000000',
        'compare_at_price'  => 'numeric|min:0|max:1000000',
        'stock'             => 'integer|min:0',
    ];

    private const VARIANT_RULES = [
        'id'                  => 'integer',
        'sku'                 => 'required|string|max:64|regex:/^[A-Za-z0-9._\-]+$/',
        'name'                => 'required|string|max:120',
        'size'                => 'string|max:60',
        'color'               => 'string|max:60',
        'price'               => 'required|numeric|min:0|max:1000000',
        'compare_at_price'    => 'numeric|min:0|max:1000000',
        'stock'               => 'integer|min:0|max:1000000',
        'low_stock_threshold' => 'integer|min:0',
        'is_active'           => 'boolean',
        'sort_order'          => 'integer',
    ];

    private const SORTS = [
        'best'       => 'p.is_featured DESC, p.id ASC',
        'newest'     => 'p.created_at DESC, p.id DESC',
        'price-asc'  => 'v.min_price ASC, p.id ASC',
        'price-desc' => 'v.min_price DESC, p.id ASC',
        'name'       => 'p.name ASC',
    ];

    // =============================================================================
    // Listing: GET /api/products
    //   ?category=slug|id  ?categories=slug,slug  ?q=  ?type=a,b  ?color=a,b  ?brand=a,b  ?min_price= ?max_price=
    //   ?sort=best|newest|price-asc|price-desc|name  ?page= ?per_page=  ?featured=1 ?ids=1,2
    //   admin only: ?status=draft|active|archived|all
    // Returns data[], meta{pagination}, facets{categories,types,colors,brands,price}
    // =============================================================================
    public function index(Request $r): void
    {
        [$page, $perPage, $offset] = Helpers::pagination($r, 24, 100);
        $isAdmin = Auth::isAdmin($r);

        // ---- base scope (drives facets) ----
        $where = [];
        $params = [];

        $status = $isAdmin ? (string) $r->queryParam('status', 'active') : 'active';
        if ($status !== 'all') {
            $where[] = 'p.status = :status';
            $params['status'] = in_array($status, ['draft', 'active', 'archived'], true) ? $status : 'active';
        }
        if (!$isAdmin) {
            $where[] = '(c.id IS NULL OR c.is_active = 1)';
        }

        $category = null;
        if ($catParam = trim((string) $r->queryParam('category', ''))) {
            $category = ctype_digit($catParam)
                ? Database::fetch('SELECT * FROM categories WHERE id = ?', [(int) $catParam])
                : Database::fetch('SELECT * FROM categories WHERE slug = ?', [$catParam]);
            if (!$category) {
                throw HttpException::notFound('Category not found.');
            }
            // include direct sub-categories
            $ids = array_merge([(int) $category['id']], array_map('intval', array_column(
                Database::fetchAll('SELECT id FROM categories WHERE parent_id = ?', [$category['id']]), 'id'
            )));
            $where[] = 'p.category_id IN ' . Database::in('cat', $ids, $params);
        }

        if ($q = trim((string) $r->queryParam('q', ''))) {
            $where[] = '(p.name LIKE :q1 OR p.sku LIKE :q2 OR p.brand LIKE :q3 OR p.product_type LIKE :q4
                         OR EXISTS (SELECT 1 FROM product_variants sv WHERE sv.product_id = p.id AND sv.sku LIKE :q5))';
            foreach (['q1', 'q2', 'q3', 'q4', 'q5'] as $k) {
                $params[$k] = Helpers::like($q);
            }
        }
        if ($r->queryParam('featured')) {
            $where[] = 'p.is_featured = 1';
        }
        if ($ids = array_filter(array_map('intval', $r->queryList('ids')))) {
            $where[] = 'p.id IN ' . Database::in('pid', $ids, $params);
        }

        $from = "FROM products p
            JOIN (
                SELECT product_id, MIN(price) AS min_price, MAX(price) AS max_price,
                       SUM(GREATEST(stock, 0)) AS total_stock, MIN(compare_at_price) AS compare_at_price
                FROM product_variants WHERE is_active = 1 GROUP BY product_id
            ) v ON v.product_id = p.id
            LEFT JOIN categories c ON c.id = p.category_id";
        $baseWhere = 'WHERE ' . implode(' AND ', $where ?: ['1 = 1']);

        // ---- facets (computed on the base scope, like the storefront filter counts) ----
        $facets = $this->facets($from, $baseWhere, $params);

        // ---- narrowing filters ----
        $fWhere = $where;
        $fParams = $params;
        if ($types = $r->queryList('type')) {
            $fWhere[] = 'p.product_type IN ' . Database::in('type', $types, $fParams);
        }
        if ($catSlugs = $r->queryList('categories')) {
            $fWhere[] = 'c.slug IN ' . Database::in('cats', $catSlugs, $fParams);
        }
        if ($brands = $r->queryList('brand')) {
            $fWhere[] = 'p.brand IN ' . Database::in('brand', $brands, $fParams);
        }
        if ($colors = $r->queryList('color')) {
            $fWhere[] = 'EXISTS (SELECT 1 FROM product_variants cv WHERE cv.product_id = p.id AND cv.is_active = 1 AND cv.color IN '
                . Database::in('color', $colors, $fParams) . ')';
        }
        if (is_numeric($min = $r->queryParam('min_price'))) {
            $fWhere[] = 'v.max_price >= :min_price';
            $fParams['min_price'] = (float) $min;
        }
        if (is_numeric($max = $r->queryParam('max_price'))) {
            $fWhere[] = 'v.min_price <= :max_price';
            $fParams['max_price'] = (float) $max;
        }
        if ($r->queryParam('in_stock')) {
            $fWhere[] = 'v.total_stock > 0';
        }
        $filterWhere = $fWhere ? 'WHERE ' . implode(' AND ', $fWhere) : '';
        $sort = self::SORTS[(string) $r->queryParam('sort', 'best')] ?? self::SORTS['best'];

        $total = (int) Database::value("SELECT COUNT(*) $from $filterWhere", $fParams);
        $rows = Database::fetchAll(
            "SELECT p.*, v.min_price, v.max_price, v.total_stock, v.compare_at_price AS variant_compare_price,
                    c.name AS category_name, c.slug AS category_slug,
                    (SELECT url FROM product_images i WHERE i.product_id = p.id ORDER BY i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS image,
                    (SELECT GROUP_CONCAT(DISTINCT pv.color ORDER BY pv.color SEPARATOR '|') FROM product_variants pv
                        WHERE pv.product_id = p.id AND pv.is_active = 1 AND pv.color IS NOT NULL AND pv.color <> '') AS colors
             $from $filterWhere ORDER BY $sort LIMIT $perPage OFFSET $offset",
            $fParams
        );

        $meta = Helpers::meta($total, $page, $perPage);
        if ($category) {
            $meta['category'] = CategoryController::format($category);
        }
        Response::json([
            'success' => true,
            'data'    => array_map([self::class, 'formatListItem'], $rows),
            'meta'    => $meta,
            'facets'  => $facets,
        ]);
    }

    /** GET /api/products/{id|slug} */
    public function show(Request $r): void
    {
        $product = $this->find((string) $r->param('id'), Auth::isAdmin($r));
        Response::ok($this->detail($product, true));
    }

    /** POST /api/products */
    public function store(Request $r): void
    {
        $data = Validator::make($r->body(), self::PRODUCT_RULES);
        $variants = $this->validateVariants($data, null);
        $this->assertSkuFree($data['sku'], 'products', null);
        $this->checkCategory($data['category_id'] ?? null);

        $id = Database::transaction(function () use ($data, $variants, $r) {
            $row = $this->productColumns($data);
            $row['slug'] = Helpers::uniqueSlug('products', $data['slug'] ?? $data['name']);
            $id = Database::insert('products', $row);
            $this->syncVariants($id, $variants, (int) $r->user['id']);
            $this->syncImageUrls($id, $data['images'] ?? [], $data['name']);
            return $id;
        });

        Response::created($this->detail($this->find((string) $id, true), false), 'Product created.');
    }

    /** PUT /api/products/{id} */
    public function update(Request $r): void
    {
        $product = $this->find((string) $r->param('id'), true);
        $rules = self::PRODUCT_RULES;
        $rules['name'] = 'string|max:190';
        $rules['sku'] = 'string|max:64|regex:/^[A-Za-z0-9._\-]+$/';
        $data = Validator::make($r->body(), $rules);

        if (!empty($data['sku'])) {
            $this->assertSkuFree($data['sku'], 'products', (int) $product['id']);
        }
        if (array_key_exists('category_id', $data)) {
            $this->checkCategory($data['category_id']);
        }
        $variants = array_key_exists('variants', $data) || isset($data['price'])
            ? $this->validateVariants($data + ['sku' => $product['sku']], (int) $product['id'])
            : null;

        Database::transaction(function () use ($product, $data, $variants, $r) {
            $row = $this->productColumns($data, true);
            if (!empty($data['slug'])) {
                $row['slug'] = Helpers::uniqueSlug('products', $data['slug'], (int) $product['id']);
            }
            Database::update('products', (int) $product['id'], $row);
            if ($variants !== null) {
                $this->syncVariants((int) $product['id'], $variants, (int) $r->user['id']);
            }
            if (array_key_exists('images', $data)) {
                $this->syncImageUrls((int) $product['id'], $data['images'] ?? [], $data['name'] ?? $product['name'], true);
            }
        });

        Response::ok($this->detail($this->find((string) $product['id'], true), false), 'Product updated.');
    }

    /** DELETE /api/products/{id}  (?archive=1 just hides it) */
    public function destroy(Request $r): void
    {
        $product = $this->find((string) $r->param('id'), true);
        if ($r->queryParam('archive')) {
            Database::update('products', (int) $product['id'], ['status' => 'archived']);
            Response::ok(null, 'Product archived.');
        }
        $images = Database::fetchAll('SELECT url FROM product_images WHERE product_id = ?', [$product['id']]);
        Database::query('DELETE FROM products WHERE id = ?', [$product['id']]); // variants/images cascade; order history keeps snapshots
        foreach ($images as $img) {
            Uploader::delete($img['url']);
        }
        Response::ok(null, 'Product deleted.');
    }

    // ---- Images -----------------------------------------------------------------

    /** POST /api/products/{id}/images  multipart "images[]" */
    public function uploadImages(Request $r): void
    {
        $product = $this->find((string) $r->param('id'), true);
        $paths = Uploader::images('images', 'products');
        $hasPrimary = (bool) Database::value('SELECT COUNT(*) FROM product_images WHERE product_id = ? AND is_primary = 1', [$product['id']]);
        $sort = (int) Database::value('SELECT COALESCE(MAX(sort_order), -1) FROM product_images WHERE product_id = ?', [$product['id']]);
        foreach ($paths as $i => $path) {
            Database::insert('product_images', [
                'product_id' => $product['id'],
                'url'        => $path,
                'alt'        => $product['name'],
                'sort_order' => $sort + 1 + $i,
                'is_primary' => (!$hasPrimary && $i === 0) ? 1 : 0,
            ]);
        }
        Response::created($this->images((int) $product['id']), count($paths) . ' image(s) uploaded.');
    }

    /** PUT /api/products/{id}/images/{imageId}  {alt, sort_order, is_primary} */
    public function updateImage(Request $r): void
    {
        $product = $this->find((string) $r->param('id'), true);
        $image = $this->findImage((int) $product['id'], (int) $r->param('imageId'));
        $data = Validator::make($r->body(), ['alt' => 'string|max:190', 'sort_order' => 'integer', 'is_primary' => 'boolean']);
        Database::transaction(function () use ($product, $image, $data) {
            if (!empty($data['is_primary'])) {
                Database::query('UPDATE product_images SET is_primary = 0 WHERE product_id = ?', [$product['id']]);
            }
            if (array_key_exists('is_primary', $data)) {
                $data['is_primary'] = (int) $data['is_primary'];
            }
            Database::update('product_images', (int) $image['id'], $data);
        });
        Response::ok($this->images((int) $product['id']), 'Image updated.');
    }

    /** DELETE /api/products/{id}/images/{imageId} */
    public function deleteImage(Request $r): void
    {
        $product = $this->find((string) $r->param('id'), true);
        $image = $this->findImage((int) $product['id'], (int) $r->param('imageId'));
        Database::query('DELETE FROM product_images WHERE id = ?', [$image['id']]);
        Uploader::delete($image['url']);
        if ($image['is_primary']) {
            Database::query('UPDATE product_images SET is_primary = 1 WHERE product_id = ? ORDER BY sort_order, id LIMIT 1', [$product['id']]);
        }
        Response::ok($this->images((int) $product['id']), 'Image deleted.');
    }

    // ---- Variants & inventory ---------------------------------------------------

    /** POST /api/products/{id}/variants */
    public function storeVariant(Request $r): void
    {
        $product = $this->find((string) $r->param('id'), true);
        $v = Validator::make($r->body(), self::VARIANT_RULES);
        $this->assertSkuFree($v['sku'], 'product_variants', null);
        $stock = (int) ($v['stock'] ?? 0);
        $v['stock'] = 0;
        unset($v['id']);
        $v['product_id'] = $product['id'];
        $v['is_active'] = (int) ($v['is_active'] ?? true);
        $id = Database::insert('product_variants', $v);
        if ($stock > 0) {
            Inventory::set($id, $stock, 'manual', (int) $r->user['id'], 'Initial stock');
        }
        Response::created(self::formatVariant(Database::fetch('SELECT * FROM product_variants WHERE id = ?', [$id])), 'Variant added.');
    }

    /** PUT /api/products/variants/{variantId} */
    public function updateVariant(Request $r): void
    {
        $variant = $this->findVariant((int) $r->param('variantId'));
        $rules = self::VARIANT_RULES;
        $rules['sku'] = 'string|max:64|regex:/^[A-Za-z0-9._\-]+$/';
        $rules['name'] = 'string|max:120';
        $rules['price'] = 'numeric|min:0|max:1000000';
        $v = Validator::make($r->body(), $rules);
        if (!empty($v['sku'])) {
            $this->assertSkuFree($v['sku'], 'product_variants', (int) $variant['id']);
        }
        $stock = $v['stock'] ?? null;
        unset($v['id'], $v['stock']);
        if (array_key_exists('is_active', $v)) {
            $v['is_active'] = (int) $v['is_active'];
        }
        Database::transaction(function () use ($variant, $v, $stock, $r) {
            Database::update('product_variants', (int) $variant['id'], $v);
            if ($stock !== null && (int) $stock !== (int) $variant['stock']) {
                Inventory::set((int) $variant['id'], (int) $stock, 'manual', (int) $r->user['id'], 'Edited in admin');
            }
        });
        Response::ok(self::formatVariant(Database::fetch('SELECT * FROM product_variants WHERE id = ?', [$variant['id']])), 'Variant updated.');
    }

    /** DELETE /api/products/variants/{variantId} */
    public function deleteVariant(Request $r): void
    {
        $variant = $this->findVariant((int) $r->param('variantId'));
        $count = (int) Database::value('SELECT COUNT(*) FROM product_variants WHERE product_id = ?', [$variant['product_id']]);
        if ($count <= 1) {
            throw HttpException::conflict('A product needs at least one variant. Delete the product instead.');
        }
        Database::query('DELETE FROM product_variants WHERE id = ?', [$variant['id']]);
        Response::ok(null, 'Variant deleted.');
    }

    /** PATCH /api/products/variants/{variantId}/stock  {mode: set|adjust, quantity, reason, note} */
    public function adjustStock(Request $r): void
    {
        $variant = $this->findVariant((int) $r->param('variantId'));
        $data = Validator::make($r->body(), [
            'mode'     => 'required|in:set,adjust',
            'quantity' => 'required|integer|min:-1000000|max:1000000',
            'reason'   => 'in:manual,restock,return',
            'note'     => 'string|max:255',
        ]);
        $reason = $data['reason'] ?? 'manual';
        $userId = (int) $r->user['id'];
        $newStock = Database::transaction(fn () => $data['mode'] === 'set'
            ? Inventory::set((int) $variant['id'], max(0, $data['quantity']), $reason, $userId, $data['note'] ?? null)
            : Inventory::adjust((int) $variant['id'], $data['quantity'], $reason, null, $userId, $data['note'] ?? null, false));
        Response::ok(['variant_id' => (int) $variant['id'], 'stock' => $newStock], 'Stock updated.');
    }

    /** GET /api/products/variants/{variantId}/stock-history */
    public function stockHistory(Request $r): void
    {
        $variant = $this->findVariant((int) $r->param('variantId'));
        $rows = Database::fetchAll(
            'SELECT sm.*, u.name AS user_name, o.order_number FROM stock_movements sm
             LEFT JOIN users u ON u.id = sm.user_id LEFT JOIN orders o ON o.id = sm.order_id
             WHERE sm.variant_id = ? ORDER BY sm.id DESC LIMIT 100',
            [$variant['id']]
        );
        Response::ok($rows);
    }

    /** GET /api/products/low-stock */
    public function lowStock(Request $r): void
    {
        $rows = Database::fetchAll(
            "SELECT v.*, p.name AS product_name, p.slug AS product_slug, p.id AS product_id
             FROM product_variants v JOIN products p ON p.id = v.product_id
             WHERE v.is_active = 1 AND p.status <> 'archived' AND v.stock <= v.low_stock_threshold
             ORDER BY v.stock ASC, p.name LIMIT 200"
        );
        Response::ok(array_map(fn ($v) => self::formatVariant($v) + [
            'product_id' => (int) $v['product_id'], 'product_name' => $v['product_name'],
        ], $rows));
    }

    // =============================================================================
    // Helpers
    // =============================================================================

    private function facets(string $from, string $where, array $params): array
    {
        $categories = Database::fetchAll(
            "SELECT c.name, c.slug, COUNT(*) AS count $from $where AND c.id IS NOT NULL GROUP BY c.id, c.name, c.slug ORDER BY c.name",
            $params
        );
        $types = Database::fetchAll(
            "SELECT p.product_type AS value, COUNT(*) AS count $from $where AND p.product_type IS NOT NULL AND p.product_type <> ''
             GROUP BY p.product_type ORDER BY p.product_type",
            $params
        );
        $brands = Database::fetchAll(
            "SELECT p.brand AS value, COUNT(*) AS count $from $where AND p.brand IS NOT NULL AND p.brand <> ''
             GROUP BY p.brand ORDER BY p.brand",
            $params
        );
        $colors = Database::fetchAll(
            "SELECT fv.color AS value, COUNT(DISTINCT p.id) AS count $from
             JOIN product_variants fv ON fv.product_id = p.id AND fv.is_active = 1 AND fv.color IS NOT NULL AND fv.color <> ''
             $where GROUP BY fv.color ORDER BY fv.color",
            $params
        );
        $price = Database::fetch("SELECT MIN(v.min_price) AS min, MAX(v.max_price) AS max $from $where", $params);

        return [
            'categories' => array_map(fn ($x) => ['name' => $x['name'], 'slug' => $x['slug'], 'count' => (int) $x['count']], $categories),
            'types'      => array_map(fn ($x) => ['value' => $x['value'], 'count' => (int) $x['count']], $types),
            'brands'     => array_map(fn ($x) => ['value' => $x['value'], 'count' => (int) $x['count']], $brands),
            'colors'     => array_map(fn ($x) => ['value' => $x['value'], 'count' => (int) $x['count']], $colors),
            'price'      => ['min' => Helpers::money($price['min'] ?? 0), 'max' => Helpers::money($price['max'] ?? 0)],
        ];
    }

    private function find(string $idOrSlug, bool $includeHidden): array
    {
        $sql = 'SELECT p.*, c.name AS category_name, c.slug AS category_slug, c.is_active AS category_active
                FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE ';
        $product = ctype_digit($idOrSlug)
            ? Database::fetch($sql . 'p.id = ?', [(int) $idOrSlug])
            : Database::fetch($sql . 'p.slug = ?', [$idOrSlug]);
        if (!$product || (!$includeHidden && ($product['status'] !== 'active' || $product['category_active'] === 0))) {
            throw HttpException::notFound('Product not found.');
        }
        return $product;
    }

    private function findImage(int $productId, int $imageId): array
    {
        $img = Database::fetch('SELECT * FROM product_images WHERE id = ? AND product_id = ?', [$imageId, $productId]);
        if (!$img) {
            throw HttpException::notFound('Image not found.');
        }
        return $img;
    }

    private function findVariant(int $id): array
    {
        $v = Database::fetch('SELECT * FROM product_variants WHERE id = ?', [$id]);
        if (!$v) {
            throw HttpException::notFound('Variant not found.');
        }
        return $v;
    }

    private function checkCategory(?int $id): void
    {
        if ($id && !Database::fetch('SELECT id FROM categories WHERE id = ?', [$id])) {
            throw HttpException::validation(['category_id' => 'Category does not exist.']);
        }
    }

    private function assertSkuFree(string $sku, string $table, ?int $ignoreId): void
    {
        $params = [$sku];
        $sql = "SELECT id FROM `$table` WHERE sku = ?";
        if ($ignoreId) {
            $sql .= ' AND id <> ?';
            $params[] = $ignoreId;
        }
        if (Database::fetch($sql, $params)) {
            throw HttpException::validation(['sku' => "SKU \"$sku\" is already in use."]);
        }
    }

    private function productColumns(array $data, bool $partial = false): array
    {
        $cols = ['category_id', 'name', 'sku', 'brand', 'product_type', 'short_description', 'description', 'warranty',
                 'video_url', 'status', 'is_featured', 'weight_lbs', 'meta_title', 'meta_description'];
        $row = [];
        foreach ($cols as $c) {
            if (array_key_exists($c, $data)) {
                $row[$c] = $data[$c];
            }
        }
        if (array_key_exists('specifications', $data)) {
            $specs = array_values(array_filter(array_map(fn ($s) => [
                'label' => trim((string) ($s['label'] ?? '')),
                'value' => trim((string) ($s['value'] ?? '')),
            ], (array) $data['specifications']), fn ($s) => $s['label'] !== ''));
            $row['specifications'] = json_encode($specs);
        }
        if (isset($row['is_featured'])) {
            $row['is_featured'] = (int) $row['is_featured'];
        }
        if ($partial) {
            $row = array_filter($row, fn ($v, $k) => !($v === null && in_array($k, ['name', 'sku'], true)), ARRAY_FILTER_USE_BOTH);
        }
        return $row;
    }

    /** Validate the variants array (or build a single Default variant from price/stock). */
    private function validateVariants(array $data, ?int $productId): array
    {
        $raw = $data['variants'] ?? null;
        if (!$raw) {
            if (!isset($data['price'])) {
                throw HttpException::validation(['variants' => 'Add at least one variant or a price.']);
            }
            $existing = $productId
                ? Database::fetch('SELECT id FROM product_variants WHERE product_id = ? ORDER BY sort_order, id LIMIT 1', [$productId])
                : null;
            $raw = [[
                'id'               => $existing['id'] ?? null,
                'sku'              => $data['sku'],
                'name'             => 'Default',
                'price'            => $data['price'],
                'compare_at_price' => $data['compare_at_price'] ?? null,
                'stock'            => $data['stock'] ?? 0,
            ]];
        }

        $clean = [];
        $errors = [];
        $skus = [];
        foreach (array_values($raw) as $i => $v) {
            try {
                $row = Validator::make(is_array($v) ? $v : [], self::VARIANT_RULES);
            } catch (HttpException $e) {
                foreach ($e->errors as $f => $m) {
                    $errors["variants.$i.$f"] = $m;
                }
                continue;
            }
            $key = strtolower($row['sku']);
            if (isset($skus[$key])) {
                $errors["variants.$i.sku"] = 'Each variant needs a unique SKU.';
            }
            $skus[$key] = true;
            if (!empty($row['id']) && $productId &&
                !Database::fetch('SELECT id FROM product_variants WHERE id = ? AND product_id = ?', [$row['id'], $productId])) {
                $errors["variants.$i.id"] = 'Variant does not belong to this product.';
            }
            $dupe = Database::fetch('SELECT id, product_id FROM product_variants WHERE sku = ?', [$row['sku']]);
            if ($dupe && (int) $dupe['id'] !== (int) ($row['id'] ?? 0)) {
                $errors["variants.$i.sku"] = "SKU \"{$row['sku']}\" is already used by another variant.";
            }
            $clean[] = $row;
        }
        if ($errors) {
            throw HttpException::validation($errors);
        }
        return $clean;
    }

    /** Create/update the given variants and delete the ones not included. */
    private function syncVariants(int $productId, array $variants, int $userId): void
    {
        $keep = [];
        foreach ($variants as $i => $v) {
            $stock = (int) ($v['stock'] ?? 0);
            $row = [
                'sku'                 => $v['sku'],
                'name'                => $v['name'],
                'size'                => $v['size'] ?? null,
                'color'               => $v['color'] ?? null,
                'price'               => $v['price'],
                'compare_at_price'    => $v['compare_at_price'] ?? null,
                'low_stock_threshold' => $v['low_stock_threshold'] ?? 5,
                'is_active'           => (int) ($v['is_active'] ?? true),
                'sort_order'          => $v['sort_order'] ?? $i,
            ];
            if (!empty($v['id'])) {
                $current = Database::fetch('SELECT stock FROM product_variants WHERE id = ?', [$v['id']]);
                Database::update('product_variants', (int) $v['id'], $row);
                if (array_key_exists('stock', $v) && $v['stock'] !== null && (int) $current['stock'] !== $stock) {
                    Inventory::set((int) $v['id'], $stock, 'manual', $userId, 'Edited in admin');
                }
                $keep[] = (int) $v['id'];
            } else {
                $row['product_id'] = $productId;
                $row['stock'] = 0;
                $id = Database::insert('product_variants', $row);
                if ($stock > 0) {
                    Inventory::set($id, $stock, 'manual', $userId, 'Initial stock');
                }
                $keep[] = $id;
            }
        }
        $params = [$productId];
        $sql = 'DELETE FROM product_variants WHERE product_id = ?';
        if ($keep) {
            $sql .= ' AND id NOT IN (' . implode(',', array_map('intval', $keep)) . ')';
        }
        Database::query($sql, $params);
    }

    /** Images given as URLs/paths in JSON (uploads use the multipart endpoint). */
    private function syncImageUrls(int $productId, array $urls, string $alt, bool $replace = false): void
    {
        $urls = array_values(array_filter(array_map(fn ($u) => is_array($u) ? ($u['url'] ?? '') : (string) $u, $urls)));
        if ($replace) {
            // remove images that are no longer listed (uploaded files are deleted from disk too)
            foreach (Database::fetchAll('SELECT * FROM product_images WHERE product_id = ?', [$productId]) as $img) {
                if (!in_array(Helpers::mediaUrl($img['url']), $urls, true) && !in_array($img['url'], $urls, true)) {
                    Database::query('DELETE FROM product_images WHERE id = ?', [$img['id']]);
                    Uploader::delete($img['url']);
                }
            }
        }
        $existing = array_column(Database::fetchAll('SELECT url FROM product_images WHERE product_id = ?', [$productId]), 'url');
        $existingFull = array_map([Helpers::class, 'mediaUrl'], $existing);
        foreach ($urls as $i => $url) {
            if (in_array($url, $existing, true) || in_array($url, $existingFull, true)) {
                continue;
            }
            if (!preg_match('#^(https?://|/)#', $url)) {
                continue;
            }
            Database::insert('product_images', [
                'product_id' => $productId, 'url' => $url, 'alt' => $alt, 'sort_order' => $i, 'is_primary' => 0,
            ]);
        }
        // exactly one primary image
        if (!Database::value('SELECT COUNT(*) FROM product_images WHERE product_id = ? AND is_primary = 1', [$productId])) {
            Database::query('UPDATE product_images SET is_primary = 1 WHERE product_id = ? ORDER BY sort_order, id LIMIT 1', [$productId]);
        }
    }

    private function images(int $productId): array
    {
        return array_map(fn ($i) => [
            'id'         => (int) $i['id'],
            'url'        => Helpers::mediaUrl($i['url']),
            'alt'        => $i['alt'],
            'sort_order' => (int) $i['sort_order'],
            'is_primary' => (bool) $i['is_primary'],
        ], Database::fetchAll('SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order, id', [$productId]));
    }

    private function detail(array $p, bool $withRelated): array
    {
        $variants = array_map([self::class, 'formatVariant'], Database::fetchAll(
            'SELECT * FROM product_variants WHERE product_id = ? ORDER BY sort_order, id', [$p['id']]
        ));
        $active = array_values(array_filter($variants, fn ($v) => $v['is_active']));
        $prices = array_column($active ?: $variants, 'price');
        $images = $this->images((int) $p['id']);
        $stock = array_sum(array_map(fn ($v) => max(0, $v['stock']), $active));

        $out = [
            'id'                => (int) $p['id'],
            'name'              => $p['name'],
            'slug'              => $p['slug'],
            'sku'               => $p['sku'],
            'brand'             => $p['brand'],
            'product_type'      => $p['product_type'],
            'category'          => $p['category_id'] ? ['id' => (int) $p['category_id'], 'name' => $p['category_name'], 'slug' => $p['category_slug']] : null,
            'short_description' => $p['short_description'],
            'description'       => $p['description'],
            'warranty'          => $p['warranty'],
            'specifications'    => $p['specifications'] ? (json_decode($p['specifications'], true) ?: []) : [],
            'video_url'         => $p['video_url'],
            'status'            => $p['status'],
            'is_featured'       => (bool) $p['is_featured'],
            'weight_lbs'        => $p['weight_lbs'] !== null ? (float) $p['weight_lbs'] : null,
            'meta_title'        => $p['meta_title'],
            'meta_description'  => $p['meta_description'],
            'price_min'         => $prices ? Helpers::money(min($prices)) : 0.0,
            'price_max'         => $prices ? Helpers::money(max($prices)) : 0.0,
            'in_stock'          => $stock > 0,
            'stock'             => $stock,
            'image_url'         => $images[0]['url'] ?? null,
            'images'            => $images,
            'variants'          => $variants,
            'colors'            => array_values(array_unique(array_filter(array_column($active, 'color')))),
            'created_at'        => $p['created_at'],
            'updated_at'        => $p['updated_at'],
        ];

        if ($withRelated && $p['category_id']) {
            $rows = Database::fetchAll(
                "SELECT p.*, v.min_price, v.max_price, v.total_stock, NULL AS variant_compare_price, c.name AS category_name, c.slug AS category_slug,
                        (SELECT url FROM product_images i WHERE i.product_id = p.id ORDER BY i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS image,
                        NULL AS colors
                 FROM products p
                 JOIN (SELECT product_id, MIN(price) min_price, MAX(price) max_price, SUM(GREATEST(stock,0)) total_stock
                       FROM product_variants WHERE is_active = 1 GROUP BY product_id) v ON v.product_id = p.id
                 LEFT JOIN categories c ON c.id = p.category_id
                 WHERE p.category_id = ? AND p.id <> ? AND p.status = 'active'
                 ORDER BY (p.product_type <=> ?) DESC, p.is_featured DESC, p.id LIMIT 4",
                [$p['category_id'], $p['id'], $p['product_type']]
            );
            $out['related'] = array_map([self::class, 'formatListItem'], $rows);
        }
        return $out;
    }

    public static function formatListItem(array $p): array
    {
        return [
            'id'               => (int) $p['id'],
            'name'             => $p['name'],
            'slug'             => $p['slug'],
            'sku'              => $p['sku'],
            'brand'            => $p['brand'],
            'product_type'     => $p['product_type'],
            'category'         => $p['category_id'] ? ['id' => (int) $p['category_id'], 'name' => $p['category_name'], 'slug' => $p['category_slug']] : null,
            'price_min'        => Helpers::money($p['min_price']),
            'price_max'        => Helpers::money($p['max_price']),
            'compare_at_price' => $p['variant_compare_price'] !== null ? Helpers::money($p['variant_compare_price']) : null,
            'in_stock'         => (int) $p['total_stock'] > 0,
            'stock'            => (int) $p['total_stock'],
            'image_url'        => Helpers::mediaUrl($p['image']),
            'colors'           => $p['colors'] ? explode('|', $p['colors']) : [],
            'is_featured'      => (bool) $p['is_featured'],
            'status'           => $p['status'],
        ];
    }

    public static function formatVariant(array $v): array
    {
        return [
            'id'                  => (int) $v['id'],
            'sku'                 => $v['sku'],
            'name'                => $v['name'],
            'size'                => $v['size'],
            'color'               => $v['color'],
            'price'               => Helpers::money($v['price']),
            'compare_at_price'    => $v['compare_at_price'] !== null ? Helpers::money($v['compare_at_price']) : null,
            'stock'               => (int) $v['stock'],
            'in_stock'            => (int) $v['stock'] > 0,
            'low_stock_threshold' => (int) $v['low_stock_threshold'],
            'is_active'           => (bool) $v['is_active'],
            'sort_order'          => (int) $v['sort_order'],
        ];
    }
}

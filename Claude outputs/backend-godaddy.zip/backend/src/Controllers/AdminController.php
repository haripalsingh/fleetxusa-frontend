<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Env;
use App\Core\Helpers;
use App\Core\Request;
use App\Core\Response;
use App\Services\OrderService;

final class AdminController
{
    /** GET /api  - health check */
    public function health(Request $r): void
    {
        $db = 'ok';
        try {
            Database::value('SELECT 1');
        } catch (\Throwable) {
            $db = 'unavailable';
        }
        Response::ok(['name' => Env::get('APP_NAME', 'Fleet X Parts') . ' API', 'version' => '1.0', 'database' => $db, 'time' => gmdate('c'), 'frontend_url' => Env::get('FRONTEND_URL', 'http://localhost:3000'), 'currency' => Env::get('CURRENCY', 'USD')]);
    }

    /** GET /api/admin/dashboard */
    public function dashboard(Request $r): void
    {
        $sales = fn (string $since) => Database::fetch(
            "SELECT COUNT(*) AS orders, COALESCE(SUM(grand_total), 0) AS revenue
             FROM orders WHERE status NOT IN ('cancelled','refunded') AND created_at >= ?",
            [$since]
        );
        $today = $sales(gmdate('Y-m-d 00:00:00'));
        $month = $sales(gmdate('Y-m-01 00:00:00'));
        $all = $sales('1970-01-01');

        $daily = Database::fetchAll(
            "SELECT DATE(created_at) AS day, COUNT(*) AS orders, COALESCE(SUM(grand_total), 0) AS revenue
             FROM orders WHERE status NOT IN ('cancelled','refunded') AND created_at >= ?
             GROUP BY DATE(created_at) ORDER BY day",
            [gmdate('Y-m-d 00:00:00', strtotime('-29 days'))]
        );

        $recent = Database::fetchAll(
            'SELECT o.*, u.name AS customer_name, (SELECT COALESCE(SUM(quantity),0) FROM order_items oi WHERE oi.order_id = o.id) AS item_count
             FROM orders o LEFT JOIN users u ON u.id = o.user_id ORDER BY o.id DESC LIMIT 8'
        );
        $top = Database::fetchAll(
            "SELECT oi.product_id, oi.product_name, SUM(oi.quantity) AS qty, SUM(oi.line_total) AS revenue
             FROM order_items oi JOIN orders o ON o.id = oi.order_id
             WHERE o.status NOT IN ('cancelled','refunded')
             GROUP BY oi.product_id, oi.product_name ORDER BY qty DESC LIMIT 5"
        );

        Response::ok([
            'today'       => ['orders' => (int) $today['orders'], 'revenue' => Helpers::money($today['revenue'])],
            'month'       => ['orders' => (int) $month['orders'], 'revenue' => Helpers::money($month['revenue'])],
            'all_time'    => ['orders' => (int) $all['orders'], 'revenue' => Helpers::money($all['revenue'])],
            'pending_orders' => (int) Database::value("SELECT COUNT(*) FROM orders WHERE status = 'pending'"),
            'processing_orders' => (int) Database::value("SELECT COUNT(*) FROM orders WHERE status = 'processing'"),
            'customers'   => (int) Database::value("SELECT COUNT(*) FROM users WHERE role <> 'admin'"),
            'products'    => (int) Database::value("SELECT COUNT(*) FROM products WHERE status = 'active'"),
            'low_stock'   => (int) Database::value(
                "SELECT COUNT(*) FROM product_variants v JOIN products p ON p.id = v.product_id
                 WHERE v.is_active = 1 AND p.status = 'active' AND v.stock <= v.low_stock_threshold"
            ),
            'daily'       => array_map(fn ($d) => ['day' => $d['day'], 'orders' => (int) $d['orders'], 'revenue' => Helpers::money($d['revenue'])], $daily),
            'recent_orders' => array_map(fn ($o) => OrderService::format($o, false), $recent),
            'top_products'  => array_map(fn ($t) => [
                'product_id' => $t['product_id'] !== null ? (int) $t['product_id'] : null,
                'name' => $t['product_name'], 'quantity' => (int) $t['qty'], 'revenue' => Helpers::money($t['revenue']),
            ], $top),
        ]);
    }
}

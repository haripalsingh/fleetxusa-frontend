<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Env;
use App\Core\HttpException;
use App\Core\Mailer;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;

final class AuthController
{
    /** POST /api/auth/register */
    public function register(Request $r): void
    {
        RateLimiter::hit('register:' . $r->ip(), 10, 3600);

        $data = Validator::make($r->body(), [
            'name'     => 'required|string|min:2|max:120',
            'email'    => 'required|email|max:190',
            'mobile'   => 'required|string|regex:/^[0-9+\-\s()]{10,20}$/',
            'password' => 'required|password|max:72|confirmed',
            'role'     => 'in:user,dealer,vendor',
            'newsletter' => 'boolean',
        ], ['mobile' => 'Mobile number']);

        $email = strtolower($data['email']);
        if (Database::fetch('SELECT id FROM users WHERE email = ?', [$email])) {
            throw HttpException::validation(['email' => 'An account with this email already exists.']);
        }

        $id = Database::insert('users', [
            'name'          => $data['name'],
            'email'         => $email,
            'mobile'        => $data['mobile'],
            'password_hash' => password_hash($data['password'], PASSWORD_DEFAULT),
            'role'          => $data['role'] ?? 'user',
            'newsletter'    => (int) ($data['newsletter'] ?? false),
        ]);

        $user = Database::fetch('SELECT * FROM users WHERE id = ?', [$id]);
        Mailer::send($email, 'Welcome to ' . Env::get('APP_NAME', 'Fleet X Parts'),
            '<p>Hi ' . htmlspecialchars($data['name']) . ',</p><p>Your account has been created. You can now log in, track orders and check out faster.</p>');

        Response::created([
            'token' => Auth::issueToken($user),
            'user'  => Auth::publicUser($user),
        ], 'Account created successfully.');
    }

    /** POST /api/auth/login */
    public function login(Request $r): void
    {
        $data = Validator::make($r->body(), [
            'email'    => 'required|email',
            'password' => 'required|string|max:200',
        ]);
        $email = strtolower($data['email']);
        RateLimiter::hit('login:' . $r->ip(), 30, 900);
        RateLimiter::hit('login:' . $email, 8, 900);

        $user = Database::fetch('SELECT * FROM users WHERE email = ?', [$email]);
        if (!$user || !password_verify($data['password'], $user['password_hash'])) {
            throw HttpException::unauthorized('Invalid email or password.');
        }
        if ($user['status'] !== 'active') {
            throw HttpException::forbidden('This account has been disabled. Please contact support.');
        }
        RateLimiter::clear('login:' . $email);

        if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
            Database::update('users', (int) $user['id'], ['password_hash' => password_hash($data['password'], PASSWORD_DEFAULT)]);
        }

        if (Env::bool('AUTH_REQUIRE_OTP')) {
            $this->sendOtp($user);
            Response::ok(['requires_otp' => true, 'email' => $email], 'We sent a 6-digit code to your email.');
        }

        $this->completeLogin($user);
    }

    /** POST /api/auth/verify-otp */
    public function verifyOtp(Request $r): void
    {
        $data = Validator::make($r->body(), [
            'email' => 'required|email',
            'code'  => 'required|regex:/^\d{6}$/',
        ], ['code' => 'Code']);
        $email = strtolower($data['email']);
        RateLimiter::hit('otp:' . $email, 10, 900);

        $user = Database::fetch('SELECT * FROM users WHERE email = ?', [$email]);
        $otp = $user ? Database::fetch(
            'SELECT * FROM otp_codes WHERE user_id = ? AND expires_at > UTC_TIMESTAMP() ORDER BY id DESC LIMIT 1',
            [$user['id']]
        ) : null;

        if (!$otp || $otp['attempts'] >= 5) {
            throw HttpException::badRequest('This code has expired. Please request a new one.');
        }
        if (!password_verify($data['code'], $otp['code_hash'])) {
            Database::query('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?', [$otp['id']]);
            throw HttpException::badRequest('Invalid code. Please try again.');
        }
        Database::query('DELETE FROM otp_codes WHERE user_id = ?', [$user['id']]);
        if (!$user['email_verified_at']) {
            Database::query('UPDATE users SET email_verified_at = UTC_TIMESTAMP() WHERE id = ?', [$user['id']]);
        }
        $this->completeLogin($user);
    }

    /** POST /api/auth/resend-otp */
    public function resendOtp(Request $r): void
    {
        $data = Validator::make($r->body(), ['email' => 'required|email']);
        $email = strtolower($data['email']);
        RateLimiter::hit('otp-resend:' . $email, 5, 900);
        $user = Database::fetch("SELECT * FROM users WHERE email = ? AND status = 'active'", [$email]);
        if ($user) {
            $this->sendOtp($user);
        }
        Response::ok(null, 'A new code has been sent to your email.');
    }

    /** POST /api/auth/forgot-password */
    public function forgotPassword(Request $r): void
    {
        $data = Validator::make($r->body(), ['email' => 'required|email']);
        $email = strtolower($data['email']);
        RateLimiter::hit('forgot:' . $r->ip(), 10, 3600);

        $user = Database::fetch("SELECT * FROM users WHERE email = ? AND status = 'active'", [$email]);
        if ($user) {
            $token = bin2hex(random_bytes(32));
            Database::query('DELETE FROM password_resets WHERE user_id = ?', [$user['id']]);
            Database::insert('password_resets', [
                'user_id'    => $user['id'],
                'token_hash' => hash('sha256', $token),
                'expires_at' => gmdate('Y-m-d H:i:s', time() + 3600),
            ]);
            $link = rtrim((string) Env::get('FRONTEND_URL', 'http://localhost:3000'), '/') . '/reset-password?token=' . $token . '&email=' . urlencode($email);
            Mailer::send($email, 'Reset your password',
                '<p>We received a request to reset your password.</p><p><a href="' . htmlspecialchars($link) . '" style="background:#00a550;color:#fff;padding:10px 18px;text-decoration:none">Reset password</a></p><p>This link expires in 1 hour. If you did not request it, you can ignore this email.</p>');
        }
        // Same answer either way so the endpoint can't be used to discover accounts
        Response::ok(null, 'If an account exists for that email, a reset link has been sent.');
    }

    /** POST /api/auth/reset-password */
    public function resetPassword(Request $r): void
    {
        $data = Validator::make($r->body(), [
            'email'    => 'required|email',
            'token'    => 'required|string|max:128',
            'password' => 'required|password|max:72|confirmed',
        ]);
        RateLimiter::hit('reset:' . $r->ip(), 10, 3600);

        $row = Database::fetch(
            'SELECT pr.*, u.email FROM password_resets pr JOIN users u ON u.id = pr.user_id
             WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > UTC_TIMESTAMP()',
            [hash('sha256', $data['token'])]
        );
        if (!$row || strtolower($row['email']) !== strtolower($data['email'])) {
            throw HttpException::badRequest('This reset link is invalid or has expired.');
        }
        Database::transaction(function () use ($row, $data) {
            Database::query(
                'UPDATE users SET password_hash = ?, token_version = token_version + 1 WHERE id = ?',
                [password_hash($data['password'], PASSWORD_DEFAULT), $row['user_id']]
            );
            Database::query('UPDATE password_resets SET used_at = UTC_TIMESTAMP() WHERE id = ?', [$row['id']]);
        });
        Response::ok(null, 'Your password has been reset. You can now log in.');
    }

    /** GET /api/auth/me */
    public function me(Request $r): void
    {
        Response::ok(Auth::publicUser($r->user));
    }

    /** POST /api/auth/logout  (?all=1 revokes every token for this user) */
    public function logout(Request $r): void
    {
        if ($r->queryParam('all')) {
            Database::query('UPDATE users SET token_version = token_version + 1 WHERE id = ?', [$r->user['id']]);
        }
        Response::ok(null, 'Logged out.');
    }

    // ------------------------------------------------------------------------------
    private function completeLogin(array $user): never
    {
        Database::query('UPDATE users SET last_login_at = UTC_TIMESTAMP() WHERE id = ?', [$user['id']]);
        Response::ok([
            'token' => Auth::issueToken($user),
            'user'  => Auth::publicUser($user),
        ], 'Logged in successfully.');
    }

    private function sendOtp(array $user): void
    {
        $code = (string) random_int(100000, 999999);
        Database::query('DELETE FROM otp_codes WHERE user_id = ?', [$user['id']]);
        Database::insert('otp_codes', [
            'user_id'    => $user['id'],
            'code_hash'  => password_hash($code, PASSWORD_DEFAULT),
            'expires_at' => gmdate('Y-m-d H:i:s', time() + 600),
        ]);
        Mailer::send($user['email'], 'Your login code: ' . $code,
            '<p>Your Fleet X Parts login code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:6px">' . $code . '</p><p>It expires in 10 minutes.</p>');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Helpers;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\Validator;

final class CategoryController
{
    private const RULES = [
        'name'             => 'required|string|max:120',
        'slug'             => 'string|max:140|regex:/^[a-z0-9-]+$/',
        'parent_id'        => 'integer',
        'description'      => 'string|max:5000',
        'image_url'        => 'string|max:255',
        'sort_order'       => 'integer',
        'is_active'        => 'boolean',
        'meta_title'       => 'string|max:190',
        'meta_description' => 'string|max:300',
    ];

    /** GET /api/categories  (?all=1 for admins includes inactive) */
    public function index(Request $r): void
    {
        $showAll = Auth::isAdmin($r) && $r->queryParam('all');
        $rows = Database::fetchAll(
            "SELECT c.*,
                (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.status = 'active') AS product_count
             FROM categories c " . ($showAll ? '' : 'WHERE c.is_active = 1 ') .
            'ORDER BY c.sort_order, c.name'
        );
        Response::ok(array_map([self::class, 'format'], $rows));
    }

    /** GET /api/categories/{id|slug} */
    public function show(Request $r): void
    {
        $cat = $this->find((string) $r->param('id'), Auth::isAdmin($r));
        $cat['product_count'] = (int) Database::value(
            "SELECT COUNT(*) FROM products WHERE category_id = ? AND status = 'active'", [$cat['id']]
        );
        $out = self::format($cat);
        $out['children'] = array_map([self::class, 'format'], Database::fetchAll(
            'SELECT * FROM categories WHERE parent_id = ? AND is_active = 1 ORDER BY sort_order, name', [$cat['id']]
        ));
        Response::ok($out);
    }

    /** POST /api/categories */
    public function store(Request $r): void
    {
        $data = Validator::make($r->body(), self::RULES);
        $data['slug'] = Helpers::uniqueSlug('categories', $data['slug'] ?? $data['name']);
        $this->checkParent($data['parent_id'] ?? null, null);
        if (array_key_exists('is_active', $data)) {
            $data['is_active'] = (int) $data['is_active'];
        }
        $id = Database::insert('categories', $data);
        Response::created(self::format(Database::fetch('SELECT * FROM categories WHERE id = ?', [$id])), 'Category created.');
    }

    /** PUT /api/categories/{id} */
    public function update(Request $r): void
    {
        $cat = $this->find((string) $r->param('id'), true);
        $rules = self::RULES;
        $rules['name'] = 'string|max:120';
        $data = Validator::make($r->body(), $rules);
        if (!empty($data['slug'])) {
            $data['slug'] = Helpers::uniqueSlug('categories', $data['slug'], (int) $cat['id']);
        } else {
            unset($data['slug']); // keep the existing slug when only the name changes (URLs stay stable)
        }
        if (array_key_exists('name', $data) && !$data['name']) {
            unset($data['name']);
        }
        if (array_key_exists('parent_id', $data)) {
            $this->checkParent($data['parent_id'], (int) $cat['id']);
        }
        if (array_key_exists('is_active', $data)) {
            $data['is_active'] = (int) $data['is_active'];
        }
        Database::update('categories', (int) $cat['id'], $data);
        Response::ok(self::format(Database::fetch('SELECT * FROM categories WHERE id = ?', [$cat['id']])), 'Category updated.');
    }

    /** DELETE /api/categories/{id} */
    public function destroy(Request $r): void
    {
        $cat = $this->find((string) $r->param('id'), true);
        $count = (int) Database::value('SELECT COUNT(*) FROM products WHERE category_id = ?', [$cat['id']]);
        if ($count > 0) {
            throw HttpException::conflict("This category still has $count product(s). Move or delete them first.");
        }
        Database::query('DELETE FROM categories WHERE id = ?', [$cat['id']]);
        Uploader::delete($cat['image_url']);
        Response::ok(null, 'Category deleted.');
    }

    /** POST /api/categories/{id}/image  (multipart field "image") */
    public function uploadImage(Request $r): void
    {
        $cat = $this->find((string) $r->param('id'), true);
        [$path] = Uploader::images('image', 'categories');
        Uploader::delete($cat['image_url']);
        Database::update('categories', (int) $cat['id'], ['image_url' => $path]);
        Response::ok(self::format(Database::fetch('SELECT * FROM categories WHERE id = ?', [$cat['id']])), 'Image uploaded.');
    }

    // ------------------------------------------------------------------------------
    private function find(string $idOrSlug, bool $includeInactive): array
    {
        $cat = ctype_digit($idOrSlug)
            ? Database::fetch('SELECT * FROM categories WHERE id = ?', [(int) $idOrSlug])
            : Database::fetch('SELECT * FROM categories WHERE slug = ?', [$idOrSlug]);
        if (!$cat || (!$includeInactive && !$cat['is_active'])) {
            throw HttpException::notFound('Category not found.');
        }
        return $cat;
    }

    private function checkParent(?int $parentId, ?int $selfId): void
    {
        if (!$parentId) {
            return;
        }
        if ($parentId === $selfId) {
            throw HttpException::validation(['parent_id' => 'A category cannot be its own parent.']);
        }
        if (!Database::fetch('SELECT id FROM categories WHERE id = ?', [$parentId])) {
            throw HttpException::validation(['parent_id' => 'Parent category does not exist.']);
        }
    }

    public static function format(array $c): array
    {
        return [
            'id'               => (int) $c['id'],
            'parent_id'        => $c['parent_id'] !== null ? (int) $c['parent_id'] : null,
            'name'             => $c['name'],
            'slug'             => $c['slug'],
            'description'      => $c['description'],
            'image_url'        => Helpers::mediaUrl($c['image_url']),
            'sort_order'       => (int) $c['sort_order'],
            'is_active'        => (bool) $c['is_active'],
            'meta_title'       => $c['meta_title'],
            'meta_description' => $c['meta_description'],
            'product_count'    => isset($c['product_count']) ? (int) $c['product_count'] : null,
        ];
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Helpers;
use App\Core\HttpException;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Services\CartService;
use App\Services\OrderService;
use App\Services\Payment\PaymentManager;

final class OrderController
{
    private const ADDRESS_RULES = [
        'full_name'     => 'required|string|max:120',
        'phone'         => 'required|string|regex:/^[0-9+\-\s().]{7,20}$/',
        'address_line1' => 'required|string|max:190',
        'address_line2' => 'string|max:190',
        'city'          => 'required|string|max:100',
        'state'         => 'required|string|max:100',
        'zip_code'      => 'required|string|regex:/^[A-Za-z0-9\-\s]{3,10}$/',
        'country'       => 'string|max:100',
    ];

    /**
     * POST /api/orders  (checkout)
     * { email, shipping_address{}, billing_same_as_shipping, billing_address{}, payment_method,
     *   coupon_code?, customer_note?, newsletter? }
     */
    public function store(Request $r): void
    {
        RateLimiter::hit('checkout:' . $r->ip(), 20, 600);

        $body = $r->body();
        $data = Validator::make($body, [
            'email'                    => 'required|email|max:190',
            'shipping_address'         => 'required|array',
            'billing_same_as_shipping' => 'boolean',
            'billing_address'          => 'array',
            'payment_method'           => 'required|string|max:30',
            'coupon_code'              => 'string|max:40',
            'customer_note'            => 'string|max:1000',
            'newsletter'               => 'boolean',
        ]);
        $data['shipping_address'] = $this->address($body['shipping_address'] ?? [], 'shipping_address');
        $data['billing_address'] = ($data['billing_same_as_shipping'] ?? true)
            ? $data['shipping_address']
            : $this->address($body['billing_address'] ?? [], 'billing_address');
        $gateway = PaymentManager::get($data['payment_method']);

        $cart = CartService::resolve($r);
        if (!$cart) {
            throw HttpException::badRequest('Your cart is empty.');
        }

        $order = OrderService::place($cart, $data, $r->user);

        $payment = [];
        $paymentError = null;
        try {
            $items = Database::fetchAll('SELECT * FROM order_items WHERE order_id = ?', [$order['id']]);
            $payment = $gateway->start($order, $items);
        } catch (\Throwable $e) {
            // The order exists and stock is reserved; the customer can retry payment from the order page.
            error_log('[Payment] ' . $e->getMessage());
            $paymentError = $e instanceof HttpException ? $e->getMessage() : 'We could not start the payment. You can retry from your order page.';
        }

        Response::created([
            'order'         => OrderService::format(Database::fetch('SELECT * FROM orders WHERE id = ?', [$order['id']]), true, true),
            'payment'       => $payment,
            'payment_error' => $paymentError,
        ], 'Order placed successfully.');
    }

    /** GET /api/orders - own orders (customers) or all orders (admin, with filters) */
    public function index(Request $r): void
    {
        [$page, $perPage, $offset] = Helpers::pagination($r, 20, 100);
        $where = [];
        $params = [];
        $admin = Auth::isAdmin($r) && $r->queryParam('scope') !== 'mine';

        if (!$admin) {
            $where[] = 'o.user_id = :uid';
            $params['uid'] = (int) $r->user['id'];
        } else {
            if ($s = $r->queryParam('status')) {
                $where[] = 'o.status = :status';
                $params['status'] = (string) $s;
            }
            if ($ps = $r->queryParam('payment_status')) {
                $where[] = 'o.payment_status = :ps';
                $params['ps'] = (string) $ps;
            }
            if ($uid = $r->queryParam('user_id')) {
                $where[] = 'o.user_id = :fuid';
                $params['fuid'] = (int) $uid;
            }
            if ($q = trim((string) $r->queryParam('q', ''))) {
                $where[] = '(o.order_number LIKE :q1 OR o.email LIKE :q2 OR u.name LIKE :q3)';
                $params['q1'] = $params['q2'] = $params['q3'] = Helpers::like($q);
            }
            if ($from = $r->queryParam('from')) {
                $where[] = 'o.created_at >= :from';
                $params['from'] = gmdate('Y-m-d 00:00:00', strtotime((string) $from));
            }
            if ($to = $r->queryParam('to')) {
                $where[] = 'o.created_at <= :to';
                $params['to'] = gmdate('Y-m-d 23:59:59', strtotime((string) $to));
            }
        }
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::value("SELECT COUNT(*) FROM orders o LEFT JOIN users u ON u.id = o.user_id $w", $params);
        $rows = Database::fetchAll(
            "SELECT o.*, u.name AS customer_name,
                (SELECT COALESCE(SUM(quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS item_count
             FROM orders o LEFT JOIN users u ON u.id = o.user_id $w
             ORDER BY o.created_at DESC, o.id DESC LIMIT $perPage OFFSET $offset",
            $params
        );
        Response::ok(array_map(fn ($o) => OrderService::format($o, false), $rows), null, Helpers::meta($total, $page, $perPage));
    }

    /** GET /api/orders/{number}  (owner, admin, or guest with ?key=access_key) */
    public function show(Request $r): void
    {
        $order = $this->findAuthorized($r);
        Response::ok(OrderService::format($order, true, $this->isGuestAccess($r, $order)));
    }

    /** POST /api/orders/{number}/cancel  (customer, pending + unpaid only) */
    public function cancel(Request $r): void
    {
        $order = $this->findAuthorized($r);
        if ($order['status'] !== 'pending' || $order['payment_status'] === 'paid') {
            throw HttpException::conflict('This order can no longer be cancelled online. Please contact support.');
        }
        $order = OrderService::changeStatus($order, 'cancelled', 'Cancelled by customer', $r->user['id'] ?? null);
        Response::ok(OrderService::format($order), 'Your order has been cancelled.');
    }

    /** PATCH /api/orders/{id}/status  {status, note?, tracking_number?, carrier?} (admin) */
    public function updateStatus(Request $r): void
    {
        $order = $this->findById((int) $r->param('id'));
        $data = Validator::make($r->body(), [
            'status'          => 'required|in:pending,processing,shipped,delivered,cancelled,refunded',
            'note'            => 'string|max:500',
            'tracking_number' => 'string|max:100',
            'carrier'         => 'string|max:60',
        ]);
        $extra = array_intersect_key($data, array_flip(['tracking_number', 'carrier']));
        $order = OrderService::changeStatus($order, $data['status'], $data['note'] ?? null, (int) $r->user['id'], $extra);
        Response::ok(OrderService::format($order), 'Order updated.');
    }

    /** PATCH /api/orders/{id}/payment  {payment_status, reference?} (admin, e.g. mark invoice paid) */
    public function updatePayment(Request $r): void
    {
        $order = $this->findById((int) $r->param('id'));
        $data = Validator::make($r->body(), [
            'payment_status' => 'required|in:unpaid,paid,failed,refunded',
            'reference'      => 'string|max:190',
        ]);
        if ($data['payment_status'] === 'paid') {
            OrderService::markPaid($order, $data['reference'] ?? null, (int) $r->user['id'], 'Marked as paid by admin');
        } else {
            Database::query('UPDATE orders SET payment_status = ? WHERE id = ?', [$data['payment_status'], $order['id']]);
            OrderService::history((int) $order['id'], $order['status'], 'Payment status: ' . $data['payment_status'], (int) $r->user['id']);
        }
        Response::ok(OrderService::format($this->findById((int) $order['id'])), 'Payment status updated.');
    }

    // ------------------------------------------------------------------------------
    private function address(mixed $raw, string $prefix): array
    {
        try {
            $a = Validator::make(is_array($raw) ? $raw : [], self::ADDRESS_RULES, ['zip_code' => 'ZIP code', 'address_line1' => 'Address']);
        } catch (HttpException $e) {
            $errors = [];
            foreach ($e->errors as $k => $m) {
                $errors["$prefix.$k"] = $m;
            }
            throw HttpException::validation($errors);
        }
        $a['country'] = $a['country'] ?? 'United States';
        $a['address_line2'] = $a['address_line2'] ?? '';
        return $a;
    }

    private function findById(int $id): array
    {
        $o = Database::fetch('SELECT * FROM orders WHERE id = ?', [$id]);
        if (!$o) {
            throw HttpException::notFound('Order not found.');
        }
        return $o;
    }

    private function isGuestAccess(Request $r, array $order): bool
    {
        $key = (string) $r->queryParam('key', '');
        return $key !== '' && hash_equals($order['access_key'], $key);
    }

    private function findAuthorized(Request $r): array
    {
        $o = Database::fetch('SELECT * FROM orders WHERE order_number = ?', [(string) $r->param('number')]);
        if (!$o) {
            throw HttpException::notFound('Order not found.');
        }
        $isOwner = $r->user && $o['user_id'] !== null && (int) $o['user_id'] === (int) $r->user['id'];
        if ($isOwner || Auth::isAdmin($r) || $this->isGuestAccess($r, $o)) {
            return $o;
        }
        if (!$r->user) {
            throw HttpException::unauthorized('Please log in to view this order.');
        }
        throw HttpException::notFound('Order not found.');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Services\CartService;
use App\Services\OrderService;

final class CartController
{
    /** GET /api/cart */
    public function show(Request $r): void
    {
        $this->respond(CartService::resolve($r));
    }

    /** POST /api/cart/items  {variant_id, quantity} */
    public function add(Request $r): void
    {
        $data = Validator::make($r->body(), [
            'variant_id' => 'required|integer|min:1',
            'quantity'   => 'integer|min:1|max:' . CartService::MAX_QTY,
        ]);
        $cart = CartService::resolve($r, true);
        CartService::addItem((int) $cart['id'], $data['variant_id'], $data['quantity'] ?? 1);
        $this->respond($cart, 'Added to cart.');
    }

    /** PATCH /api/cart/items/{id}  {quantity} */
    public function update(Request $r): void
    {
        $data = Validator::make($r->body(), ['quantity' => 'required|integer|min:1|max:' . CartService::MAX_QTY]);
        [$cart, $item] = $this->item($r);
        $variant = Database::fetch('SELECT * FROM product_variants WHERE id = ?', [$item['variant_id']]);
        CartService::assertStock($variant, $data['quantity']);
        Database::query('UPDATE cart_items SET quantity = ? WHERE id = ?', [$data['quantity'], $item['id']]);
        $this->respond($cart, 'Cart updated.');
    }

    /** DELETE /api/cart/items/{id} */
    public function remove(Request $r): void
    {
        [$cart, $item] = $this->item($r);
        Database::query('DELETE FROM cart_items WHERE id = ?', [$item['id']]);
        $this->respond($cart, 'Item removed.');
    }

    /** DELETE /api/cart */
    public function clear(Request $r): void
    {
        $cart = CartService::resolve($r);
        if ($cart) {
            Database::query('DELETE FROM cart_items WHERE cart_id = ?', [$cart['id']]);
        }
        $this->respond($cart, 'Cart cleared.');
    }

    /** POST /api/cart/merge  (header X-Cart-Token = guest cart) - call right after login */
    public function merge(Request $r): void
    {
        $token = CartService::guestToken($r) ?? (is_string($r->input('token')) ? $r->input('token') : null);
        if ($token && preg_match('/^[a-f0-9]{64}$/', $token)) {
            CartService::merge($token, (int) $r->user['id']);
        }
        $this->respond(CartService::resolve($r));
    }

    // ------------------------------------------------------------------------------
    private function item(Request $r): array
    {
        $cart = CartService::resolve($r);
        $item = $cart ? Database::fetch('SELECT * FROM cart_items WHERE id = ? AND cart_id = ?', [(int) $r->param('id'), $cart['id']]) : null;
        if (!$item) {
            throw HttpException::notFound('Cart item not found.');
        }
        return [$cart, $item];
    }

    private function respond(?array $cart, ?string $message = null): never
    {
        $summary = CartService::summary($cart);
        $summary['totals'] = OrderService::totals($summary['subtotal'], 0.0, false, $summary['count'] > 0);
        if ($summary['token']) {
            header('X-Cart-Token: ' . $summary['token']);
        }
        Response::ok($summary, $message);
    }
}

<?php
declare(strict_types=1);

/**
 * Front controller - every /api/* request lands here (see api/.htaccess).
 */

require dirname(__DIR__) . '/bootstrap.php';

use App\Core\Env;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Router;

// ---- Security headers --------------------------------------------------------
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header_remove('X-Powered-By');

// ---- CORS ------------------------------------------------------------------
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = array_filter(array_map('trim', explode(',', (string) Env::get('CORS_ALLOWED_ORIGINS', 'http://localhost:3000,http://127.0.0.1:3000'))));
if ($origin && (in_array($origin, $allowed, true) || in_array('*', $allowed, true))) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Cart-Token, Accept');
    header('Access-Control-Expose-Headers: X-Cart-Token');
    header('Access-Control-Max-Age: 86400');
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---- Dispatch ----------------------------------------------------------------
try {
    $router = new Router();
    require BASE_PATH . '/src/routes.php';
    $router->dispatch(Request::capture());
    Response::ok(null); // controllers normally exit via Response::*
} catch (HttpException $e) {
    Response::error($e->getMessage(), $e->status, $e->errors);
} catch (PDOException $e) {
    error_log('[DB] ' . $e->getMessage() . "\n" . $e->getTraceAsString());
    Response::error(Env::bool('APP_DEBUG') ? 'Database error: ' . $e->getMessage() : 'A database error occurred.', 500);
} catch (Throwable $e) {
    error_log('[API] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() . "\n" . $e->getTraceAsString());
    Response::error(Env::bool('APP_DEBUG') ? $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')' : 'Something went wrong. Please try again.', 500);
}

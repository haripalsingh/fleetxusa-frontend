<?php
/**
 * Router for PHP's built-in server (no Apache needed):
 *   php -S localhost:8000 dev-router.php
 * API:   http://localhost:8000/api/products
 * Admin: http://localhost:8000/admin/
 */
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (preg_match('#^/api(/|$)#', $path)) {
    require __DIR__ . '/api/index.php';
    return true;
}
if (preg_match('#^/(src|config|database|storage|scripts)(/|$)|/\.#', $path)) {
    http_response_code(403);
    echo 'Forbidden';
    return true;
}
if ($path === '/admin' ) {
    header('Location: /admin/');
    return true;
}
if (str_starts_with($path, '/uploads/') && preg_match('/\.php/i', $path)) {
    http_response_code(403);
    return true;
}
return false; // let the built-in server serve static files (admin/, uploads/)

/* Fleet X Parts - Admin panel (vanilla JS, talks to ../api) */
(() => {
  'use strict';

  const API = new URL('../api', window.location.href).href.replace(/\/$/, '');
  const TOKEN_KEY = 'fx_admin_token';
  let token = null;
  try { token = localStorage.getItem(TOKEN_KEY); } catch { /* storage blocked */ }
  let me = null;
  let frontendUrl = '';
  let categoriesCache = null;

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const view = $('#view');

  // ---------------------------------------------------------------- utilities
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => Number(n || 0).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  const date = (s) => (s ? new Date(s.replace(' ', 'T') + 'Z').toLocaleString() : '—');
  const badge = (s) => `<span class="badge ${esc(s)}">${esc(String(s).replace('_', ' '))}</span>`;
  const img = (url) => (!url ? '' : url.startsWith('/') ? frontendUrl + url : url);
  const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  function toast(msg, isError = false) {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (isError ? ' error' : '');
    el.hidden = false;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (el.hidden = true), 3500);
  }

  class ApiError extends Error {
    constructor(message, status, errors) { super(message); this.status = status; this.errors = errors || {}; }
  }

  async function api(path, { method = 'GET', body, form } = {}) {
    const headers = { Accept: 'application/json' };
    if (token) headers.Authorization = 'Bearer ' + token;
    let payload;
    if (form) payload = form;
    else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
    const res = await fetch(API + path, { method, headers, body: payload });
    let json = null;
    try { json = await res.json(); } catch { /* non-JSON */ }
    if (res.status === 401 && path !== '/auth/login') { logout(); throw new ApiError('Session expired', 401); }
    if (!res.ok || !json || json.success === false) {
      throw new ApiError(json?.message || `Request failed (${res.status})`, res.status, json?.errors);
    }
    return json;
  }

  function qs(params) {
    const u = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== '' && v != null) u.set(k, v); });
    const s = u.toString();
    return s ? '?' + s : '';
  }

  function showErrors(form, err) {
    $$('.field-error', form).forEach((e) => e.remove());
    const general = $('.form-alert', form);
    if (general) { general.hidden = false; general.textContent = err.message; }
    Object.entries(err.errors || {}).forEach(([field, msg]) => {
      const input = form.querySelector(`[name="${CSS.escape(field)}"]`);
      if (input) input.insertAdjacentHTML('afterend', `<span class="field-error">${esc(msg)}</span>`);
    });
    if (!general) toast(err.message, true);
  }

  function formData(form) {
    const out = {};
    $$('input, select, textarea', form).forEach((el) => {
      if (!el.name || el.dataset.skip !== undefined) return;
      if (el.type === 'checkbox') out[el.name] = el.checked;
      else if (el.type === 'number') out[el.name] = el.value === '' ? null : Number(el.value);
      else out[el.name] = el.value.trim() === '' ? null : el.value.trim();
    });
    return out;
  }

  function openModal(title, html) {
    $('#modal-title').textContent = title;
    $('#modal-body').innerHTML = html;
    $('#modal').hidden = false;
    return $('#modal-body');
  }
  function closeModal() { $('#modal').hidden = true; $('#modal-body').innerHTML = ''; }
  $('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal' || e.target.closest('[data-close]')) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  function pager(meta, onPage) {
    const wrap = document.createElement('div');
    wrap.className = 'pager';
    wrap.innerHTML = `<span class="muted">${meta.total} result${meta.total === 1 ? '' : 's'} · page ${meta.page} of ${meta.total_pages}</span>
      <span><button class="btn small" data-p="prev" ${meta.page <= 1 ? 'disabled' : ''}>Prev</button>
      <button class="btn small" data-p="next" ${meta.page >= meta.total_pages ? 'disabled' : ''}>Next</button></span>`;
    wrap.addEventListener('click', (e) => {
      const b = e.target.closest('[data-p]');
      if (b) onPage(meta.page + (b.dataset.p === 'next' ? 1 : -1));
    });
    return wrap;
  }

  async function getCategories(force = false) {
    if (!categoriesCache || force) categoriesCache = (await api('/categories?all=1')).data;
    return categoriesCache;
  }

  function setTitle(title, actions = '') {
    $('#page-title').textContent = title;
    $('#page-actions').innerHTML = actions;
    document.title = `${title} · Fleet X Admin`;
  }

  // ---------------------------------------------------------------- auth
  function showLogin() { $('#app-view').hidden = true; $('#login-view').hidden = false; }
  function logout() {
    token = null;
    try { localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
    showLogin();
  }
  $('#logout').addEventListener('click', logout);

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const errBox = $('#login-error');
    errBox.hidden = true;
    const email = f.email.value.trim();
    try {
      let res;
      if (!$('#otp-row').hidden) {
        res = await api('/auth/verify-otp', { method: 'POST', body: { email, code: f.code.value.trim() } });
      } else {
        res = await api('/auth/login', { method: 'POST', body: { email, password: f.password.value } });
        if (res.data.requires_otp) { $('#otp-row').hidden = false; errBox.className = 'alert info'; errBox.textContent = res.message; errBox.hidden = false; return; }
      }
      if (res.data.user.role !== 'admin') throw new ApiError('This account does not have admin access.', 403);
      token = res.data.token;
      try { localStorage.setItem(TOKEN_KEY, token); } catch { /* ignore */ }
      $('#otp-row').hidden = true;
      boot();
    } catch (err) {
      errBox.className = 'alert error';
      errBox.textContent = err.message;
      errBox.hidden = false;
    }
  });

  $('#menu-toggle').addEventListener('click', () => $('#sidebar').classList.toggle('open'));

  // ---------------------------------------------------------------- router
  const routes = {};
  function route() {
    const [name, ...rest] = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/');
    $$('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.route === name));
    $('#sidebar').classList.remove('open');
    view.onclick = null;
    closeModal();
    (routes[name] || routes.dashboard)(...rest).catch((err) => {
      if (err.status !== 401) view.innerHTML = `<div class="alert error">${esc(err.message)}</div>`;
    });
  }
  window.addEventListener('hashchange', route);

  // ================================================================= DASHBOARD
  routes.dashboard = async () => {
    setTitle('Dashboard');
    view.innerHTML = '<p class="muted">Loading…</p>';
    const d = (await api('/admin/dashboard')).data;
    const max = Math.max(1, ...d.daily.map((x) => x.revenue));
    view.innerHTML = `
      <div class="stats">
        ${[
          ['Revenue today', money(d.today.revenue), `${d.today.orders} orders`],
          ['Revenue this month', money(d.month.revenue), `${d.month.orders} orders`],
          ['All-time revenue', money(d.all_time.revenue), `${d.all_time.orders} orders`],
          ['Pending orders', d.pending_orders, `${d.processing_orders} processing`],
          ['Customers', d.customers, ''],
          ['Active products', d.products, `<a href="#/inventory">${d.low_stock} low / out of stock</a>`],
        ].map(([l, v, s]) => `<div class="card stat"><div class="label">${l}</div><div class="value">${v}</div><div class="muted small">${s}</div></div>`).join('')}
      </div>
      <div class="grid-2">
        <div class="card"><h3>Revenue · last 30 days</h3>
          ${d.daily.length ? `<div class="bars">${d.daily.map((x) => `<div style="height:${(x.revenue / max) * 100}%" title="${esc(x.day)}: ${money(x.revenue)} (${x.orders} orders)"></div>`).join('')}</div>` : '<p class="muted">No sales yet.</p>'}
        </div>
        <div class="card"><h3>Top products</h3>
          ${d.top_products.length ? `<table><tbody>${d.top_products.map((p) => `<tr><td>${esc(p.name)}</td><td class="right">${p.quantity} sold</td><td class="right">${money(p.revenue)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">No sales yet.</p>'}
        </div>
      </div>
      <div class="card"><h3>Recent orders</h3>${ordersTable(d.recent_orders)}</div>`;
    bindOrderRows(view);
  };

  // ================================================================= ORDERS
  const ORDER_STATUSES = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'];

  function ordersTable(orders) {
    if (!orders.length) return '<p class="muted">No orders found.</p>';
    return `<div class="table-wrap"><table><thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Payment</th></tr></thead><tbody>
      ${orders.map((o) => `<tr class="clickable" data-order="${esc(o.order_number)}">
        <td><strong>${esc(o.order_number)}</strong></td><td class="nowrap">${date(o.created_at)}</td>
        <td>${esc(o.customer_name || o.shipping_address?.full_name || '')}<div class="muted small">${esc(o.email)}</div></td>
        <td>${o.item_count ?? ''}</td><td>${money(o.grand_total)}</td><td>${badge(o.status)}</td>
        <td>${badge(o.payment_status)}<div class="muted small">${esc(o.payment_method)}</div></td></tr>`).join('')}
    </tbody></table></div>`;
  }
  function bindOrderRows(root) {
    $$('[data-order]', root).forEach((tr) => tr.addEventListener('click', () => showOrder(tr.dataset.order)));
  }

  routes.orders = async () => {
    setTitle('Orders');
    const state = { page: 1, q: '', status: '', payment_status: '' };
    view.innerHTML = `<div class="toolbar">
        <input class="grow" type="search" placeholder="Search order #, email or name" data-f="q" />
        <select data-f="status"><option value="">All statuses</option>${ORDER_STATUSES.map((s) => `<option>${s}</option>`).join('')}</select>
        <select data-f="payment_status"><option value="">All payments</option>${['unpaid', 'paid', 'failed', 'refunded'].map((s) => `<option>${s}</option>`).join('')}</select>
      </div><div id="list"></div>`;
    const load = async () => {
      const res = await api('/orders' + qs({ ...state, per_page: 25 }));
      const list = $('#list');
      list.innerHTML = ordersTable(res.data);
      bindOrderRows(list);
      list.appendChild(pager(res.meta, (p) => { state.page = p; load(); }));
    };
    $$('[data-f]', view).forEach((el) => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', debounce(() => { state[el.dataset.f] = el.value; state.page = 1; load(); })));
    await load();
  };

  async function showOrder(number) {
    const o = (await api('/orders/' + encodeURIComponent(number))).data;
    const addr = (a) => a ? `${esc(a.full_name)}<br>${esc(a.address_line1)}${a.address_line2 ? ', ' + esc(a.address_line2) : ''}<br>${esc(a.city)}, ${esc(a.state)} ${esc(a.zip_code)}<br>${esc(a.country)}<br>${esc(a.phone)}` : '—';
    const body = openModal(`Order ${o.order_number}`, `
      <div class="grid-3">
        <div><div class="muted small">Status</div>${badge(o.status)}</div>
        <div><div class="muted small">Payment</div>${badge(o.payment_status)} <span class="muted small">${esc(o.payment_method)}</span></div>
        <div><div class="muted small">Placed</div>${date(o.created_at)}</div>
      </div>
      <div class="grid-3" style="margin-top:16px">
        <div class="card"><h3>Customer</h3>${esc(o.email)}${o.user_id ? `<div class="small"><a href="#/customers/${o.user_id}" data-close>View customer</a></div>` : '<div class="muted small">Guest checkout</div>'}</div>
        <div class="card"><h3>Shipping</h3><div class="small">${addr(o.shipping_address)}</div></div>
        <div class="card"><h3>Billing</h3><div class="small">${addr(o.billing_address)}</div></div>
      </div>
      <div class="table-wrap" style="margin-top:16px"><table><thead><tr><th></th><th>Item</th><th>SKU</th><th>Price</th><th>Qty</th><th class="right">Total</th></tr></thead><tbody>
        ${o.items.map((i) => `<tr><td>${i.image_url ? `<img class="thumb" src="${esc(img(i.image_url))}" alt="">` : ''}</td><td>${esc(i.name)}${i.option ? `<div class="muted small">${esc(i.option)}</div>` : ''}</td><td>${esc(i.sku)}</td><td>${money(i.unit_price)}</td><td>${i.quantity}</td><td class="right">${money(i.line_total)}</td></tr>`).join('')}
        <tr><td colspan="5" class="right">Subtotal</td><td class="right">${money(o.subtotal)}</td></tr>
        ${o.discount_total > 0 ? `<tr><td colspan="5" class="right">Discount ${o.coupon_code ? `(${esc(o.coupon_code)})` : ''}</td><td class="right">−${money(o.discount_total)}</td></tr>` : ''}
        <tr><td colspan="5" class="right">Shipping</td><td class="right">${money(o.shipping_total)}</td></tr>
        <tr><td colspan="5" class="right">Tax</td><td class="right">${money(o.tax_total)}</td></tr>
        <tr><td colspan="5" class="right"><strong>Total</strong></td><td class="right"><strong>${money(o.grand_total)}</strong></td></tr>
      </tbody></table></div>
      ${o.customer_note ? `<div class="alert info" style="margin-top:12px"><strong>Customer note:</strong> ${esc(o.customer_note)}</div>` : ''}
      <div class="grid-2" style="margin-top:16px">
        <form class="card" id="status-form"><h3>Update status</h3>
          <div class="alert error form-alert" hidden></div>
          <label>Status<select name="status">${ORDER_STATUSES.map((s) => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
          <div class="grid-2" style="margin-top:10px"><label>Carrier<input name="carrier" value="${esc(o.carrier || '')}" placeholder="UPS, FedEx…"></label>
          <label>Tracking #<input name="tracking_number" value="${esc(o.tracking_number || '')}"></label></div>
          <label style="margin-top:10px">Note (emailed to customer)<textarea name="note" rows="2"></textarea></label>
          <div class="form-actions"><button class="btn primary">Save</button></div>
        </form>
        <div class="card"><h3>Payment</h3>
          <p>${badge(o.payment_status)} ${o.paid_at ? `<span class="muted small">paid ${date(o.paid_at)}</span>` : ''}</p>
          ${o.payment_status !== 'paid' ? '<button class="btn" id="mark-paid">Mark as paid</button>' : ''}
          <h3 style="margin-top:18px">History</h3>
          <ul class="timeline">${o.history.map((h) => `<li>${badge(h.status)} <span class="muted small">${date(h.created_at)}</span>${h.note ? `<div class="small">${esc(h.note)}</div>` : ''}</li>`).join('')}</ul>
        </div>
      </div>`);

    $('#status-form', body).addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await api(`/orders/${o.id}/status`, { method: 'PATCH', body: formData(e.target) });
        toast('Order updated');
        closeModal();
        route();
      } catch (err) { showErrors(e.target, err); }
    });
    $('#mark-paid', body)?.addEventListener('click', async () => {
      const ref = prompt('Payment reference (optional, e.g. check # or transaction id):', '');
      if (ref === null) return;
      try {
        await api(`/orders/${o.id}/payment`, { method: 'PATCH', body: { payment_status: 'paid', reference: ref || null } });
        toast('Marked as paid');
        closeModal();
        route();
      } catch (err) { toast(err.message, true); }
    });
  }

  // ================================================================= PRODUCTS
  routes.products = async (id) => {
    if (id) return productForm(id === 'new' ? null : id);
    setTitle('Products', '<a class="btn primary" href="#/products/new">+ Add product</a>');
    const cats = await getCategories();
    const state = { page: 1, q: '', category: '', status: 'all', sort: 'newest' };
    view.innerHTML = `<div class="toolbar">
      <input class="grow" type="search" placeholder="Search name, SKU, brand…" data-f="q">
      <select data-f="category"><option value="">All categories</option>${cats.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select>
      <select data-f="status"><option value="all">Any status</option><option>active</option><option>draft</option><option>archived</option></select>
      <select data-f="sort"><option value="newest">Newest</option><option value="name">Name</option><option value="price-asc">Price ↑</option><option value="price-desc">Price ↓</option></select>
    </div><div id="list"></div>`;
    $('[data-f="status"]').value = 'all';
    const load = async () => {
      const res = await api('/products' + qs({ ...state, per_page: 25 }));
      const list = $('#list');
      list.innerHTML = res.data.length ? `<div class="table-wrap"><table><thead><tr><th></th><th>Product</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th></tr></thead><tbody>
        ${res.data.map((p) => `<tr class="clickable" data-id="${p.id}"><td>${p.image_url ? `<img class="thumb" src="${esc(img(p.image_url))}" alt="">` : ''}</td>
          <td><strong>${esc(p.name)}</strong><div class="muted small">${esc(p.brand || '')} · ${esc(p.product_type || '')}</div></td>
          <td>${esc(p.sku)}</td><td>${esc(p.category?.name || '—')}</td>
          <td class="nowrap">${p.price_max > p.price_min ? `${money(p.price_min)} – ${money(p.price_max)}` : money(p.price_min)}</td>
          <td class="${p.stock === 0 ? 'stock-out' : p.stock <= 5 ? 'stock-low' : ''}">${p.stock}</td><td>${badge(p.status)}${p.is_featured ? ' <span class="badge">featured</span>' : ''}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">No products found.</p>';
      $$('[data-id]', list).forEach((tr) => tr.addEventListener('click', () => (location.hash = '#/products/' + tr.dataset.id)));
      list.appendChild(pager(res.meta, (p) => { state.page = p; load(); }));
    };
    $$('[data-f]', view).forEach((el) => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', debounce(() => { state[el.dataset.f] = el.value; state.page = 1; load(); })));
    await load();
  };

  const variantRow = (v = {}) => `<tr>
    <td><input type="hidden" name="v_id" value="${v.id || ''}"><input name="v_name" value="${esc(v.name || 'Default')}" placeholder="Standard Fit"></td>
    <td><input name="v_sku" value="${esc(v.sku || '')}" placeholder="SKU-001"></td>
    <td><input name="v_size" value="${esc(v.size || '')}"></td>
    <td><input name="v_color" value="${esc(v.color || '')}"></td>
    <td><input name="v_price" type="number" step="0.01" min="0" value="${v.price ?? ''}"></td>
    <td><input name="v_compare" type="number" step="0.01" min="0" value="${v.compare_at_price ?? ''}"></td>
    <td><input name="v_stock" type="number" min="0" value="${v.stock ?? 0}"></td>
    <td><input name="v_low" type="number" min="0" value="${v.low_stock_threshold ?? 5}"></td>
    <td><input name="v_active" type="checkbox" ${v.is_active === false ? '' : 'checked'}></td>
    <td><button type="button" class="btn danger small" data-remove-row>✕</button></td></tr>`;
  const specRow = (s = {}) => `<div class="grid-2 spec-row" style="margin-bottom:6px;grid-template-columns:1fr 2fr auto">
    <input name="s_label" value="${esc(s.label || '')}" placeholder="Label (e.g. Fitment)"><input name="s_value" value="${esc(s.value || '')}" placeholder="Value">
    <button type="button" class="btn danger small" data-remove-row>✕</button></div>`;

  async function productForm(id) {
    const cats = await getCategories();
    const p = id ? (await api('/products/' + id)).data : { status: 'active', variants: [{}], specifications: [], images: [] };
    setTitle(id ? `Edit: ${p.name}` : 'New product', '<a class="btn" href="#/products">← Back</a>');
    view.innerHTML = `<form id="pform" novalidate>
      <div class="alert error form-alert" hidden></div>
      <div class="card"><h3>Details</h3><div class="form-grid">
        <label class="span-2">Name *<input name="name" value="${esc(p.name || '')}" required></label>
        <label>SKU *<input name="sku" value="${esc(p.sku || '')}" required></label>
        <label>URL slug<input name="slug" value="${esc(p.slug || '')}" placeholder="auto from name"></label>
        <label>Category<select name="category_id"><option value="">— None —</option>${cats.map((c) => `<option value="${c.id}" ${p.category?.id === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
        <label>Product type<input name="product_type" value="${esc(p.product_type || '')}" placeholder="e.g. Radiators" list="types"></label>
        <label>Brand<input name="brand" value="${esc(p.brand || '')}"></label>
        <label>Status<select name="status">${['active', 'draft', 'archived'].map((s) => `<option ${p.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
        <label class="span-2">Short description<input name="short_description" value="${esc(p.short_description || '')}" maxlength="500"></label>
        <label class="span-2">Description<textarea name="description" rows="5">${esc(p.description || '')}</textarea></label>
        <label class="span-2">Warranty information<textarea name="warranty" rows="3">${esc(p.warranty || '')}</textarea></label>
        <label>Video URL<input name="video_url" value="${esc(p.video_url || '')}" placeholder="https://www.youtube.com/embed/…"></label>
        <label>Weight (lbs)<input name="weight_lbs" type="number" step="0.01" min="0" value="${p.weight_lbs ?? ''}"></label>
        <label class="check"><input type="checkbox" name="is_featured" ${p.is_featured ? 'checked' : ''}> Featured product</label>
      </div></div>

      <div class="card"><h3>Variants, pricing & stock</h3>
        <p class="muted small">Every product needs at least one variant. Use one "Default" row for products without options.</p>
        <div class="table-wrap"><table class="variant-table"><thead><tr><th>Option name</th><th>SKU</th><th>Size</th><th>Color</th><th>Price</th><th>Compare at</th><th>Stock</th><th>Low alert</th><th>Active</th><th></th></tr></thead>
          <tbody id="variants">${(p.variants.length ? p.variants : [{}]).map(variantRow).join('')}</tbody></table></div>
        <button type="button" class="btn small" id="add-variant" style="margin-top:10px">+ Add variant</button>
      </div>

      <div class="card"><h3>Specifications</h3><div id="specs">${(p.specifications || []).map(specRow).join('')}</div>
        <button type="button" class="btn small" id="add-spec">+ Add row</button></div>

      <div class="card"><h3>SEO</h3><div class="form-grid">
        <label>Meta title<input name="meta_title" value="${esc(p.meta_title || '')}" maxlength="190"></label>
        <label>Meta description<input name="meta_description" value="${esc(p.meta_description || '')}" maxlength="300"></label>
      </div></div>

      <div class="card"><h3>Images</h3>
        ${id ? `<div class="images" id="images"></div>
          <label style="margin-top:12px">Upload images (JPG, PNG, WEBP · first one becomes the main image)<input type="file" id="img-input" accept="image/*" multiple data-skip></label>`
        : '<p class="muted">Save the product first, then upload images.</p>'}
      </div>

      <div class="form-actions">
        ${id ? '<button type="button" class="btn danger" id="delete-product">Delete</button>' : ''}
        <a class="btn" href="#/products">Cancel</a><button class="btn primary" type="submit">${id ? 'Save changes' : 'Create product'}</button>
      </div></form>`;

    const form = $('#pform');
    form.addEventListener('click', (e) => { if (e.target.closest('[data-remove-row]')) e.target.closest('tr, .spec-row').remove(); });
    $('#add-variant').addEventListener('click', () => $('#variants').insertAdjacentHTML('beforeend', variantRow({ name: '' })));
    $('#add-spec').addEventListener('click', () => $('#specs').insertAdjacentHTML('beforeend', specRow()));

    const renderImages = (images) => {
      const box = $('#images');
      if (!box) return;
      box.innerHTML = images.length ? images.map((i) => `<div class="image-tile ${i.is_primary ? 'primary' : ''}"><img src="${esc(img(i.url))}" alt="">
        <div class="row">${i.is_primary ? '<span class="badge active">Main</span>' : `<button type="button" class="btn small" data-primary="${i.id}">Main</button>`}
        <button type="button" class="btn danger small" data-del-img="${i.id}">✕</button></div></div>`).join('') : '<p class="muted">No images yet.</p>';
    };
    renderImages(p.images || []);
    $('#images')?.addEventListener('click', async (e) => {
      const prim = e.target.closest('[data-primary]');
      const del = e.target.closest('[data-del-img]');
      try {
        if (prim) renderImages((await api(`/products/${id}/images/${prim.dataset.primary}`, { method: 'PUT', body: { is_primary: true } })).data);
        if (del && confirm('Delete this image?')) renderImages((await api(`/products/${id}/images/${del.dataset.delImg}`, { method: 'DELETE' })).data);
      } catch (err) { toast(err.message, true); }
    });
    $('#img-input')?.addEventListener('change', async (e) => {
      const fd = new FormData();
      [...e.target.files].forEach((f) => fd.append('images[]', f));
      try {
        renderImages((await api(`/products/${id}/images`, { method: 'POST', form: fd })).data);
        toast('Images uploaded');
      } catch (err) { toast(Object.values(err.errors)[0] || err.message, true); }
      e.target.value = '';
    });
    $('#delete-product')?.addEventListener('click', async () => {
      if (!confirm('Delete this product permanently? Past orders keep their copy of the item.')) return;
      try { await api('/products/' + id, { method: 'DELETE' }); toast('Product deleted'); location.hash = '#/products'; } catch (err) { toast(err.message, true); }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const d = {};
      ['name', 'sku', 'slug', 'product_type', 'brand', 'status', 'short_description', 'description', 'warranty', 'video_url', 'meta_title', 'meta_description']
        .forEach((k) => { const v = form.elements[k].value.trim(); d[k] = v === '' ? null : v; });
      if (!d.slug) delete d.slug;
      d.category_id = form.elements.category_id.value ? Number(form.elements.category_id.value) : null;
      d.weight_lbs = form.elements.weight_lbs.value === '' ? null : Number(form.elements.weight_lbs.value);
      d.is_featured = form.elements.is_featured.checked;
      d.variants = $$('#variants tr').map((tr, i) => {
        const g = (n) => tr.querySelector(`[name="${n}"]`);
        const num = (n) => (g(n).value === '' ? null : Number(g(n).value));
        return {
          ...(g('v_id').value ? { id: Number(g('v_id').value) } : {}),
          name: g('v_name').value.trim() || 'Default', sku: g('v_sku').value.trim(), size: g('v_size').value.trim() || null,
          color: g('v_color').value.trim() || null, price: num('v_price'), compare_at_price: num('v_compare'),
          stock: num('v_stock') ?? 0, low_stock_threshold: num('v_low') ?? 5, is_active: g('v_active').checked, sort_order: i,
        };
      });
      d.specifications = $$('#specs .spec-row').map((r) => ({ label: r.querySelector('[name="s_label"]').value.trim(), value: r.querySelector('[name="s_value"]').value.trim() })).filter((s) => s.label);
      try {
        const res = await api(id ? '/products/' + id : '/products', { method: id ? 'PUT' : 'POST', body: d });
        toast(res.message);
        if (!id) location.hash = '#/products/' + res.data.id;
        else productForm(id);
      } catch (err) {
        showErrors(form, err);
        const box = $('.form-alert', form);
        if (Object.keys(err.errors).length) box.innerHTML = esc(err.message) + '<ul>' + Object.values(err.errors).map((m) => `<li>${esc(m)}</li>`).join('') + '</ul>';
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  }

  // ================================================================= CATEGORIES
  routes.categories = async () => {
    setTitle('Categories', '<button class="btn primary" id="new-cat">+ Add category</button>');
    const cats = await getCategories(true);
    const byId = Object.fromEntries(cats.map((c) => [c.id, c]));
    view.innerHTML = cats.length ? `<div class="table-wrap"><table><thead><tr><th></th><th>Name</th><th>Slug</th><th>Parent</th><th>Products</th><th>Order</th><th>Status</th></tr></thead><tbody>
      ${cats.map((c) => `<tr class="clickable" data-id="${c.id}"><td>${c.image_url ? `<img class="thumb" src="${esc(img(c.image_url))}" alt="">` : ''}</td><td><strong>${esc(c.name)}</strong></td>
      <td>${esc(c.slug)}</td><td>${esc(byId[c.parent_id]?.name || '—')}</td><td>${c.product_count}</td><td>${c.sort_order}</td><td>${badge(c.is_active ? 'active' : 'draft')}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">No categories yet.</p>';
    $$('[data-id]', view).forEach((tr) => tr.addEventListener('click', () => categoryForm(byId[tr.dataset.id], cats)));
    $('#new-cat').addEventListener('click', () => categoryForm(null, cats));
  };

  function categoryForm(c, cats) {
    const body = openModal(c ? `Edit category: ${c.name}` : 'New category', `<form id="cform" novalidate>
      <div class="alert error form-alert" hidden></div>
      <div class="form-grid">
        <label>Name *<input name="name" value="${esc(c?.name || '')}"></label>
        <label>URL slug<input name="slug" value="${esc(c?.slug || '')}" placeholder="auto from name"></label>
        <label>Parent<select name="parent_id"><option value="">— None —</option>${cats.filter((x) => x.id !== c?.id).map((x) => `<option value="${x.id}" ${c?.parent_id === x.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
        <label>Sort order<input name="sort_order" type="number" value="${c?.sort_order ?? 0}"></label>
        <label class="span-2">Description<textarea name="description">${esc(c?.description || '')}</textarea></label>
        <label>Image URL / path<input name="image_url" value="${esc(c?.image_url || '')}" placeholder="/images/… or upload below"></label>
        ${c ? '<label>Upload image<input type="file" id="cat-img" accept="image/*" data-skip></label>' : '<span></span>'}
        <label>Meta title<input name="meta_title" value="${esc(c?.meta_title || '')}"></label>
        <label>Meta description<input name="meta_description" value="${esc(c?.meta_description || '')}"></label>
        <label class="check"><input type="checkbox" name="is_active" ${c?.is_active === false ? '' : 'checked'}> Visible on the site</label>
      </div>
      <div class="form-actions">${c ? '<button type="button" class="btn danger" id="del-cat">Delete</button>' : ''}<button class="btn primary">Save</button></div></form>`);
    const form = $('#cform', body);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const d = formData(form);
      d.parent_id = d.parent_id ? Number(d.parent_id) : null;
      if (!d.slug) delete d.slug;
      try {
        await api(c ? '/categories/' + c.id : '/categories', { method: c ? 'PUT' : 'POST', body: d });
        toast('Category saved'); closeModal(); routes.categories();
      } catch (err) { showErrors(form, err); }
    });
    $('#cat-img', body)?.addEventListener('change', async (e) => {
      const fd = new FormData();
      fd.append('image', e.target.files[0]);
      try { await api(`/categories/${c.id}/image`, { method: 'POST', form: fd }); toast('Image uploaded'); closeModal(); routes.categories(); } catch (err) { toast(Object.values(err.errors)[0] || err.message, true); }
    });
    $('#del-cat', body)?.addEventListener('click', async () => {
      if (!confirm('Delete this category?')) return;
      try { await api('/categories/' + c.id, { method: 'DELETE' }); toast('Category deleted'); closeModal(); routes.categories(); } catch (err) { toast(err.message, true); }
    });
  }

  // ================================================================= INVENTORY
  routes.inventory = async () => {
    setTitle('Inventory · low & out of stock');
    const rows = (await api('/products/low-stock')).data;
    view.innerHTML = rows.length ? `<p class="muted">Variants at or below their low-stock alert level. Adjust stock inline or open the product.</p>
      <div class="table-wrap"><table><thead><tr><th>Product</th><th>Variant</th><th>SKU</th><th>Stock</th><th>Alert at</th><th>Adjust</th></tr></thead><tbody>
      ${rows.map((v) => `<tr><td><a href="#/products/${v.product_id}">${esc(v.product_name)}</a></td><td>${esc(v.name)}</td><td>${esc(v.sku)}</td>
        <td class="${v.stock === 0 ? 'stock-out' : 'stock-low'}" data-stock="${v.id}">${v.stock}</td><td>${v.low_stock_threshold}</td>
        <td class="nowrap"><input type="number" style="width:90px" placeholder="+qty" data-qty="${v.id}"> <button class="btn small" data-add="${v.id}">Add stock</button> <button class="btn ghost small" data-hist="${v.id}">History</button></td></tr>`).join('')}
      </tbody></table></div>` : '<div class="card">🎉 Everything is well stocked.</div>';
    view.onclick = async (e) => {
      const add = e.target.closest('[data-add]');
      const hist = e.target.closest('[data-hist]');
      if (add) {
        const id = add.dataset.add;
        const qty = Number($(`[data-qty="${id}"]`).value);
        if (!qty) return toast('Enter a quantity', true);
        try {
          const res = await api(`/products/variants/${id}/stock`, { method: 'PATCH', body: { mode: 'adjust', quantity: qty, reason: 'restock' } });
          $(`[data-stock="${id}"]`).textContent = res.data.stock;
          $(`[data-qty="${id}"]`).value = '';
          toast('Stock updated');
        } catch (err) { toast(err.message, true); }
      }
      if (hist) {
        const h = (await api(`/products/variants/${hist.dataset.hist}/stock-history`)).data;
        openModal('Stock history', h.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Change</th><th>After</th><th>Reason</th><th>By / order</th><th>Note</th></tr></thead><tbody>
          ${h.map((m) => `<tr><td>${date(m.created_at)}</td><td>${m.change_qty > 0 ? '+' : ''}${m.change_qty}</td><td>${m.stock_after}</td><td>${esc(m.reason)}</td><td>${esc(m.order_number || m.user_name || '—')}</td><td>${esc(m.note || '')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No movements yet.</p>');
      }
    };
  };

  // ================================================================= CUSTOMERS
  routes.customers = async (id) => {
    if (id) return customerDetail(id);
    setTitle('Customers');
    const state = { page: 1, q: '', role: '', status: '' };
    view.innerHTML = `<div class="toolbar"><input class="grow" type="search" placeholder="Search name, email, phone" data-f="q">
      <select data-f="role"><option value="">All roles</option><option>user</option><option>dealer</option><option>vendor</option><option>admin</option></select>
      <select data-f="status"><option value="">Any status</option><option>active</option><option>blocked</option></select></div><div id="list"></div>`;
    const load = async () => {
      const res = await api('/users' + qs({ ...state, per_page: 25 }));
      const list = $('#list');
      list.innerHTML = res.data.length ? `<div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Orders</th><th>Spent</th><th>Joined</th><th>Status</th></tr></thead><tbody>
        ${res.data.map((u) => `<tr class="clickable" data-id="${u.id}"><td><strong>${esc(u.name)}</strong></td><td>${esc(u.email)}</td><td>${esc(u.mobile || '')}</td><td>${badge(u.role)}</td><td>${u.order_count}</td><td>${money(u.total_spent)}</td><td class="nowrap">${date(u.created_at)}</td><td>${badge(u.status)}</td></tr>`).join('')}
        </tbody></table></div>` : '<p class="muted">No customers found.</p>';
      $$('[data-id]', list).forEach((tr) => tr.addEventListener('click', () => (location.hash = '#/customers/' + tr.dataset.id)));
      list.appendChild(pager(res.meta, (p) => { state.page = p; load(); }));
    };
    $$('[data-f]', view).forEach((el) => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', debounce(() => { state[el.dataset.f] = el.value; state.page = 1; load(); })));
    await load();
  };

  async function customerDetail(id) {
    const [u, orders] = await Promise.all([api('/users/' + id), api('/orders' + qs({ user_id: id, per_page: 50 }))]);
    const c = u.data;
    setTitle(c.name, '<a class="btn" href="#/customers">← Back</a>');
    view.innerHTML = `<div class="grid-2">
      <div class="card"><h3>Profile</h3><dl class="kv"><dt>Email</dt><dd>${esc(c.email)}</dd><dt>Phone</dt><dd>${esc(c.mobile || '—')}</dd>
        <dt>Joined</dt><dd>${date(c.created_at)}</dd><dt>Last login</dt><dd>${date(c.last_login_at)}</dd><dt>Orders</dt><dd>${c.order_count}</dd><dt>Total spent</dt><dd>${money(c.total_spent)}</dd>
        <dt>Newsletter</dt><dd>${c.newsletter ? 'Yes' : 'No'}</dd></dl></div>
      <form class="card" id="uform"><h3>Access</h3><div class="alert error form-alert" hidden></div>
        <label>Role<select name="role">${['user', 'dealer', 'vendor', 'admin'].map((r) => `<option ${c.role === r ? 'selected' : ''}>${r}</option>`).join('')}</select></label>
        <label style="margin-top:10px">Status<select name="status">${['active', 'blocked'].map((r) => `<option ${c.status === r ? 'selected' : ''}>${r}</option>`).join('')}</select></label>
        <div class="form-actions"><button class="btn primary">Save</button></div></form></div>
      <div class="card"><h3>Addresses</h3>${c.addresses.length ? c.addresses.map((a) => `<p class="small">${a.is_default ? badge('default') + ' ' : ''}${esc(a.full_name)}, ${esc(a.address_line1)}, ${esc(a.city)}, ${esc(a.state)} ${esc(a.zip_code)} · ${esc(a.phone)}</p>`).join('') : '<p class="muted">None saved.</p>'}</div>
      <div class="card"><h3>Orders</h3>${ordersTable(orders.data)}</div>`;
    bindOrderRows(view);
    $('#uform').addEventListener('submit', async (e) => {
      e.preventDefault();
      try { await api('/users/' + id, { method: 'PUT', body: formData(e.target) }); toast('Customer updated'); } catch (err) { showErrors(e.target, err); }
    });
  }

  // ================================================================= COUPONS
  routes.coupons = async () => {
    setTitle('Coupons', '<button class="btn primary" id="new-coupon">+ Add coupon</button>');
    const res = await api('/coupons?per_page=100');
    const describe = (c) => (c.type === 'percent' ? `${c.value}% off` : c.type === 'fixed' ? `${money(c.value)} off` : 'Free shipping');
    view.innerHTML = res.data.length ? `<div class="table-wrap"><table><thead><tr><th>Code</th><th>Discount</th><th>Min order</th><th>Used</th><th>Valid</th><th>Status</th></tr></thead><tbody>
      ${res.data.map((c) => `<tr class="clickable" data-id="${c.id}"><td><strong>${esc(c.code)}</strong><div class="muted small">${esc(c.description || '')}</div></td><td>${describe(c)}</td>
        <td>${c.min_order_amount ? money(c.min_order_amount) : '—'}</td><td>${c.used_count}${c.usage_limit ? ' / ' + c.usage_limit : ''}</td>
        <td class="small">${c.starts_at ? date(c.starts_at) : 'now'} → ${c.expires_at ? date(c.expires_at) : 'no expiry'}</td><td>${badge(c.is_active ? 'active' : 'draft')}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">No coupons yet.</p>';
    const byId = Object.fromEntries(res.data.map((c) => [c.id, c]));
    $$('[data-id]', view).forEach((tr) => tr.addEventListener('click', () => couponForm(byId[tr.dataset.id])));
    $('#new-coupon').addEventListener('click', () => couponForm(null));
  };

  function couponForm(c) {
    const dt = (s) => (s ? s.replace(' ', 'T').slice(0, 16) : '');
    const body = openModal(c ? `Edit coupon ${c.code}` : 'New coupon', `<form id="kform" novalidate><div class="alert error form-alert" hidden></div>
      <div class="form-grid">
        <label>Code *<input name="code" value="${esc(c?.code || '')}" style="text-transform:uppercase"></label>
        <label>Type<select name="type">${[['percent', 'Percent off'], ['fixed', 'Fixed amount off'], ['free_shipping', 'Free shipping']].map(([v, l]) => `<option value="${v}" ${c?.type === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        <label>Value<input name="value" type="number" step="0.01" min="0" value="${c?.value ?? ''}"></label>
        <label>Description<input name="description" value="${esc(c?.description || '')}"></label>
        <label>Minimum order ($)<input name="min_order_amount" type="number" step="0.01" min="0" value="${c?.min_order_amount ?? ''}"></label>
        <label>Max discount ($)<input name="max_discount_amount" type="number" step="0.01" min="0" value="${c?.max_discount_amount ?? ''}"></label>
        <label>Total uses allowed<input name="usage_limit" type="number" min="1" value="${c?.usage_limit ?? ''}" placeholder="unlimited"></label>
        <label>Uses per customer<input name="usage_limit_per_user" type="number" min="1" value="${c?.usage_limit_per_user ?? ''}" placeholder="unlimited"></label>
        <label>Starts (UTC)<input name="starts_at" type="datetime-local" value="${dt(c?.starts_at)}"></label>
        <label>Expires (UTC)<input name="expires_at" type="datetime-local" value="${dt(c?.expires_at)}"></label>
        <label class="check"><input type="checkbox" name="is_active" ${c?.is_active === false ? '' : 'checked'}> Active</label>
      </div>
      <div class="form-actions">${c ? '<button type="button" class="btn danger" id="del-coupon">Delete</button>' : ''}<button class="btn primary">Save</button></div></form>`);
    const form = $('#kform', body);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const d = formData(form);
      d.value = d.value ?? 0;
      try { await api(c ? '/coupons/' + c.id : '/coupons', { method: c ? 'PUT' : 'POST', body: d }); toast('Coupon saved'); closeModal(); routes.coupons(); } catch (err) { showErrors(form, err); }
    });
    $('#del-coupon', body)?.addEventListener('click', async () => {
      if (!confirm('Delete this coupon?')) return;
      try { await api('/coupons/' + c.id, { method: 'DELETE' }); toast('Coupon deleted'); closeModal(); routes.coupons(); } catch (err) { toast(err.message, true); }
    });
  }

  // ---------------------------------------------------------------- boot
  async function boot() {
    if (!token) return showLogin();
    try {
      const [meRes, health] = await Promise.all([api('/auth/me'), api('/')]);
      me = meRes.data;
      frontendUrl = (health.data.frontend_url || '').replace(/\/$/, '');
      if (me.role !== 'admin') return logout();
    } catch {
      return showLogin();
    }
    $('#me').textContent = `${me.name} · ${me.email}`;
    $('#login-view').hidden = true;
    $('#app-view').hidden = false;
    route();
  }
  boot();
})();

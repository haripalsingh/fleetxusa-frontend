<?php
declare(strict_types=1);

/**
 * Generates demo data (the same catalog the Next.js site showed as dummy data)
 * + an admin user + sample coupons.
 *
 *   php scripts/seed.php            -> writes database/seed.sql (import it with phpMyAdmin)
 *   php scripts/seed.php --run      -> inserts straight into the database from .env
 *
 * Admin login after seeding:  admin@fleetxparts.com / Admin@12345   (change it!)
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('CLI only');
}

require dirname(__DIR__) . '/bootstrap.php';

use App\Core\Database;
use App\Core\Helpers;

$categories = [
    ['cooling-systems', 'Cooling System', '/images/cooling-systems.jpg',
        ['Radiators', 'Fan Clutches', 'Water Pumps', 'Thermostats', 'Hoses & Clamps', 'Charge Air Coolers', 'Coolant Reservoirs', 'Air Conditioner'],
        ['Black', 'Silver', 'Aluminum', 'Blue']],
    ['steering-system', 'Steering System', '/images/categories/steering-system.jpg',
        ['Steering Wheels', 'Steering Columns', 'Tie Rods', 'Drag Links', 'Steering Gearboxes', 'Pitman Arms', 'Power Steering Pumps', 'Steering Knuckles'],
        ['Black', 'Chrome', 'Wood Grain', 'Blue']],
    ['body-and-cabin', 'Body and Cabin', '/images/categories/body-and-cabin.jpg',
        ['Mirrors', 'Grilles', 'Hoods', 'Fenders', 'Bumpers', 'Door Handles', 'Cab Panels', 'Seat Covers'],
        ['Black', 'White', 'Chrome', 'Gray']],
    ['air-spring-shocks', 'Air Spring & Shocks', '/images/categories/air-spring-shocks.jpg',
        ['Air Springs', 'Shock Absorbers', 'Leaf Springs', 'Bushings', 'Suspension Kits', 'Height Control Valves', 'Torque Rods', 'Spring Hangers'],
        ['Black', 'Silver', 'Red']],
    ['air-brake-wheel', 'Air Brake & Wheel', '/images/categories/air-brake-wheel.jpg',
        ['Brake Drums', 'Brake Pads', 'Brake Rotors', 'Brake Chambers', 'Slack Adjusters', 'Wheel Hubs', 'Air Dryers', 'Wheel Seals'],
        ['Black', 'Silver', 'Green', 'Gray']],
    ['chrome-stainless', 'Chrome & Stainless', '/images/categories/chrome-stainless.jpg',
        ['Lug Nut Covers', 'Bumpers', 'Exhaust Stacks', 'Grille Guards', 'Fender Guards', 'Light Bars', 'Trim & Accents', 'Air Cleaner Covers'],
        ['Chrome', 'Stainless Steel', 'Polished', 'Black']],
];
$brands = ['FleetX', 'Aftermarket', 'Roadmaster', 'Highway Pro', 'Ironclad', 'Prime Heavy Duty'];
$grades = ['Heavy-Duty', 'Premium', 'OEM-Style', 'Fleet-Grade', 'Standard', 'Extended Life'];
$perType = 6;

$singular = function (string $label): string {
    if (str_contains($label, '&')) {
        return $label;
    }
    return preg_replace_callback('/(\w+)$/', function ($m) {
        $w = $m[1];
        foreach ([['/ches$/', 'ch'], ['/xes$/', 'x'], ['/ies$/', 'y'], ['/s$/', '']] as [$re, $rep]) {
            if (preg_match($re, $w)) {
                return preg_replace($re, $rep, $w);
            }
        }
        return $w;
    }, $label);
};

// ---- build the catalog (mirrors lib/dummyProducts.ts) --------------------------------
$lists = [];
foreach ($categories as $ci => [$slug, $name, $image, $types, $colors]) {
    $n = 0;
    $list = [];
    foreach ($types as $ti => $type) {
        for ($i = 0; $i < $perType; $i++) {
            $seed = $ti * 13 + $i * 7 + strlen($slug);
            $grade = $grades[$seed % count($grades)];
            $brand = $brands[($seed + $i) % count($brands)];
            $color = $colors[($seed + $ti) % count($colors)];
            $priceMin = round(24 + (($seed * 53) % 380) + $i * 11, 2) - 0.05;
            $hasRange = ($seed + $i) % 4 === 0;
            $priceMax = $hasRange ? round($priceMin + 40 + (($seed * 29) % 220), 2) : $priceMin;
            $prefix = substr(strtoupper(explode(' ', $name)[0]), 0, 2);
            $pname = sprintf('%s %s %s%d', $grade, $singular($type), $prefix, 1000 + $n * 7);
            $sku = (string) (134000 + $ci * 100 + $n);
            $stock = ($seed * 7 + $i * 3) % 40;
            if ($stock < 3) {
                $stock = 0; // a few out-of-stock items for testing
            }

            $variants = $hasRange
                ? [
                    ['Standard Fit', $priceMin, $sku . '-STD', $stock],
                    ['With Hardware Kit', round(($priceMin + $priceMax) / 2, 2), $sku . '-HWK', max(0, $stock - 4)],
                    ['With Mounting Straps', $priceMax, $sku . '-MS', max(0, $stock - 8)],
                ]
                : [['Default', $priceMin, $sku, $stock]];

            $list[] = [
                'category_slug' => $slug,
                'name' => $pname, 'sku' => $sku, 'brand' => $brand, 'type' => $type, 'color' => $color,
                'image' => $image, 'variants' => $variants, 'featured' => ($i === 0 && $ti < 2) ? 1 : 0,
                'description' => "$brand " . strtolower($type) . ' designed for heavy-duty trucks and fleet duty cycles. '
                    . 'Built to hold up to long hauls, heat and vibration, so your trucks spend more time on the road and less time in the shop.',
                'specs' => [
                    ['label' => 'Category', 'value' => $name],
                    ['label' => 'Product type', 'value' => $type],
                    ['label' => 'Finish / color', 'value' => $color],
                    ['label' => 'Fitment', 'value' => 'Direct-fit design for common Class 8 applications - verify with your VIN before ordering'],
                ],
            ];
            $n++;
        }
    }
    $lists[] = $list;
}
// interleave so "Best Match" mixes categories (same as getAllDummyProducts)
$products = [];
for ($i = 0, $max = max(array_map('count', $lists)); $i < $max; $i++) {
    foreach ($lists as $l) {
        if (isset($l[$i])) {
            $products[] = $l[$i];
        }
    }
}

// ---- SQL ---------------------------------------------------------------------------
$q = fn ($v) => $v === null ? 'NULL' : (is_int($v) || is_float($v) ? (string) $v : "'" . str_replace(["\\", "'"], ["\\\\", "''"], (string) $v) . "'");
$sql = [];
$sql[] = "-- Demo data for Fleet X Parts. Generated by scripts/seed.php on " . gmdate('Y-m-d H:i') . " UTC";
$sql[] = 'SET NAMES utf8mb4;';
$sql[] = 'SET FOREIGN_KEY_CHECKS = 0;';
foreach (['stock_movements', 'product_images', 'product_variants', 'products', 'categories', 'coupons'] as $t) {
    $sql[] = "DELETE FROM $t;";
    $sql[] = "ALTER TABLE $t AUTO_INCREMENT = 1;";
}
$sql[] = 'SET FOREIGN_KEY_CHECKS = 1;';
$sql[] = '';

foreach ($categories as $ci => [$slug, $name, $image]) {
    $sql[] = sprintf(
        'INSERT INTO categories (id, name, slug, description, image_url, sort_order, is_active) VALUES (%d, %s, %s, %s, %s, %d, 1);',
        $ci + 1, $q($name), $q($slug), $q("Shop $name parts for heavy-duty trucks at Fleet X Parts."), $q($image), $ci
    );
}
$sql[] = '';

$catIds = array_flip(array_column($categories, 0));
$variantId = 1;
foreach ($products as $pi => $p) {
    $pid = $pi + 1;
    $sql[] = sprintf(
        'INSERT INTO products (id, category_id, name, slug, sku, brand, product_type, short_description, description, warranty, specifications, status, is_featured) VALUES (%d, %d, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %d);',
        $pid, $catIds[$p['category_slug']] + 1, $q($p['name']), $q(Helpers::slugify($p['name'])), $q($p['sku']), $q($p['brand']), $q($p['type']),
        $q("{$p['brand']} {$p['type']} for Class 8 trucks."), $q($p['description']),
        $q("This product is backed by the manufacturer's warranty against defects in material and workmanship. Contact our support team with your order number for warranty assistance."),
        $q(json_encode($p['specs'])), $q('active'), $p['featured']
    );
    $sql[] = sprintf('INSERT INTO product_images (product_id, url, alt, sort_order, is_primary) VALUES (%d, %s, %s, 0, 1);', $pid, $q($p['image']), $q($p['name']));
    foreach ($p['variants'] as $vi => [$vname, $price, $vsku, $stock]) {
        $sql[] = sprintf(
            'INSERT INTO product_variants (id, product_id, sku, name, color, price, stock, low_stock_threshold, sort_order) VALUES (%d, %d, %s, %s, %s, %.2f, %d, 5, %d);',
            $variantId, $pid, $q($vsku), $q($vname), $q($p['color']), $price, $stock, $vi
        );
        if ($stock > 0) {
            $sql[] = sprintf("INSERT INTO stock_movements (variant_id, change_qty, stock_after, reason, note) VALUES (%d, %d, %d, 'restock', 'Initial stock');", $variantId, $stock, $stock);
        }
        $variantId++;
    }
}
$sql[] = '';

// coupons
$sql[] = "INSERT INTO coupons (code, description, type, value, min_order_amount, max_discount_amount, usage_limit, usage_limit_per_user, is_active) VALUES
  ('WELCOME10', '10% off your first order', 'percent', 10, NULL, 100, NULL, 1, 1),
  ('SAVE25', '\$25 off orders over \$200', 'fixed', 25, 200, NULL, 500, NULL, 1),
  ('FREESHIP', 'Free shipping on orders over \$100', 'free_shipping', 0, 100, NULL, NULL, NULL, 1);";
$sql[] = '';

// admin
$hash = password_hash('Admin@12345', PASSWORD_DEFAULT);
$sql[] = "INSERT INTO users (name, email, mobile, password_hash, role, status, email_verified_at) VALUES ('Store Admin', 'admin@fleetxparts.com', '0000000000', " . $q($hash) . ", 'admin', 'active', UTC_TIMESTAMP())
  ON DUPLICATE KEY UPDATE role = 'admin', status = 'active';";

$out = implode("\n", $sql) . "\n";

if (in_array('--run', $argv, true)) {
    $pdo = Database::pdo();
    $body = preg_replace('/^--.*$/m', '', $out);
    foreach (array_filter(array_map('trim', explode(";\n", $body))) as $stmt) {
        $pdo->exec($stmt);
    }
    echo 'Seeded ' . count($categories) . ' categories, ' . count($products) . " products, 3 coupons and the admin user.\n";
} else {
    file_put_contents(dirname(__DIR__) . '/database/seed.sql', $out);
    echo 'Wrote database/seed.sql (' . count($products) . " products).\n";
}

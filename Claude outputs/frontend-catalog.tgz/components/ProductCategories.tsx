/* eslint-disable @next/next/no-img-element */
import Image from 'next/image';
import Link from 'next/link';
import { getCategories } from '@/lib/catalog';

type Category = {
  title: string;
  slug: string;
  image: string;
};

// Fallback when the API is unreachable (e.g. during a build without the backend running).
const FALLBACK: Category[] = [
  { title: 'Filters', slug: 'filters', image: '/images/filter-cat.jpg' },
  { title: 'Engine Parts', slug: 'engine-parts', image: '/images/banner2.jpg' },
  { title: 'Cooling', slug: 'cooling', image: '/images/cooling-systems.jpg' },
  { title: 'Drivetrain', slug: 'drivetrain', image: '/images/power-train.jpg' },
  { title: 'Air System', slug: 'air-system', image: '/images/categories/air-spring-shocks.jpg' },
  { title: 'Cabin Parts', slug: 'cabin-parts', image: '/images/categories/steering-system.jpg' }
];

const ProductCategories = async () => {
  const fromApi = await getCategories();
  const CATEGORIES: Category[] = fromApi.length
    ? fromApi
        .filter((c) => !c.parent_id)
        .slice(0, 6)
        .map((c) => ({ title: c.name, slug: c.slug, image: c.image_url || '/images/fleet-x-icon.png' }))
    : FALLBACK;

  return (
    <section className="w-full bg-white py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 md:px-0">
        {/* Section heading */}
        <div className="flex items-start justify-between gap-4 mb-10">
          <div>
            <h2 className="text-3xl md:text-4xl font-medium uppercase tracking-tight text-[#2B2A29]">
              Product Categories
            </h2>
            <div className="mt-3 w-20 h-1 bg-gradient-to-r from-[#00a550] to-[#f8ef05]" />
          </div>
          <Link
            href="/products"
            className="whitespace-nowrap text-base md:text-lg font-medium text-[#00a550] hover:opacity-80 transition-opacity"
          >
            View All Products &rarr;
          </Link>
        </div>

        {/* Category cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-12">
          {CATEGORIES.map((category) => (
            <Link
              key={category.slug}
              href={`/products/${category.slug}`}
              className="group block"
            >
              <div className="relative aspect-[16/9] w-full overflow-hidden rounded-xl bg-black">
                {category.image.startsWith('/') ? (
                  <Image
                    src={category.image}
                    alt={category.title}
                    fill
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                ) : (
                  <img
                    src={category.image}
                    alt={category.title}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                )}
              </div>
              <h3 className="mt-6 text-2xl md:text-[28px] font-medium uppercase tracking-tight text-[#2B2A29]">
                {category.title}
              </h3>
              <span className="mt-6 inline-block border-b-2 border-[#2B2A29] pb-0.5 text-sm font-semibold uppercase tracking-[0.15em] text-[#2B2A29] group-hover:text-[#00a550] group-hover:border-[#00a550] transition-colors">
                Explore
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductCategories;
